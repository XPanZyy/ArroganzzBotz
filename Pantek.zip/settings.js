/*

  !- Credits By Skyzopedia
  https://wa.me/6285624297894
  
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6283875773656'
global.versi = "1.0"
global.namaOwner = "XPanzZyy - Official"
global.packname = "Created By Arroganzz - Botz"
global.botname = 'Arroganzz - Botz'
global.botname2 = 'Arroganzz - Botz'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/6283875773656"
global.linkWebsite = "https://restapi.simplebot.my.id"
global.linkGrup = "https://chat.whatsapp.com/Coxha5bBVrqJNRQU5HnaV5"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 5000
global.delayPushkontak = 5000

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029Vb1y0Q8KQuJCu059Il15"
global.idSaluran = "120363411580855607@newsletter"
global.namaSaluran = "XPanzZyy ||• Information"


global.tokenVercel = `1bbJdcBQuY4iIied9H2LIB46` 
global.tokenGithub = `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` // Token github mu (search github token)
global.usnGithub = `XPanZyy` // Nama akun gtihub mu

//~~~~~~~~~ Settings Foto ~~~~~~~~//
global.logo = "https"
global.qriss = "https"

//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.pinH2H = "1111"
global.passwordH2H = "Gajollay11111"
global.merchantIdOrderKuota = "OK2088243"
global.apiOrderKuota = "846854217289281822088243OKCTF5EC133AC4A0C62E4E29B23C43291972"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214621103778158240303UMI51440014ID.CO.QRIS.WWW0215ID20243511142180303UMI5204541153033605802ID5920SKYZOPEDIA OK20882436009SIJUNJUNG61052751162070703A0163042A2F"

//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = "-"
global.apiSimpleBot = "skyzo"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "083875773656"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"

//~~~~~ Settings Api Panel Buy Panel ~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://yilziii.com"
global.apk = "https"
global.apikey = "ptla_2PPsNZy4lJMO6Y3ZMSqNAGpZFoJP5dWFY50QMlPw6A0" //ptla
global.capikey = "ptlc_GwBaiDjsEo4ba8ftfdheJRmM15WJPzb9Gi94tJNWCnE" //ptlc

//~~~~~~~ Settings Api Subdomain ~~~~~~~//
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "d6kmqwlvi0qwCyMxoGuc3EBAYRYvbulhjhR9T0I7"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "fnl7ixlJ-Y-7zxJ7EUGEXitfmfLiPGW985iXobdu"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk owner bot!",
	admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup!",
	botAdmin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	private: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam private chat!",
	prem: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})